import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync, writeFileSync, mkdirSync, unlinkSync, existsSync } from 'node:fs';
export const ROOT = path.dirname(fileURLToPath(import.meta.url));
export const BASE_COMMIT = '56d852d1f2f5d7342b9e02194964d6b998c795c7';
export const REPOS = {
 base: path.resolve(ROOT, '../base52'),
 walk: 'C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-walk',
 site: 'C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-site',
};
export const TARGETS = {
 base: 'https://ppw-designer-2d-git-gpt-olb-fix-round-3-2026-10-27-victor-ppw.vercel.app',
 walk: 'https://ppw-designer-2d-git-gpt-olb-walk-mode-2026-10-27-victor-ppw.vercel.app',
 site: 'https://ppw-designer-2d-git-gpt-olb-site-map-2026-10-27-victor-ppw.vercel.app',
 prod: 'https://onelivebuild.com',
 localwalk: 'http://127.0.0.1:5183', localsite: 'http://127.0.0.1:5184',
};
const configArgument = process.argv.find(a => a.startsWith('--config='));
if (configArgument) {
 const overrides = JSON.parse(readFileSync(path.resolve(configArgument.slice(9)), 'utf8'));
 Object.assign(REPOS, overrides.repos || {}); Object.assign(TARGETS, overrides.targets || {});
}
export const LABEL = process.argv.find(a => a.startsWith('--label='))?.slice(8) || new Date().toISOString().replace(/[:.]/g, '-');
if (!/^[a-zA-Z0-9._-]+$/.test(LABEL)) throw Error('Use a simple --label=name; no paths.');
export const OUTPUT = path.join(ROOT, 'results', LABEL);
const lockPath = path.resolve(ROOT, '../performance-active.json');
let acquired = false;
/** Prevent this harness family from overlapping browsers and controlled builds. */
export function acquireRun(kind) {
 if (acquired) return;
 mkdirSync(path.dirname(lockPath), { recursive: true });
 try { writeFileSync(lockPath, JSON.stringify({ pid: process.pid, kind, label: LABEL, at: new Date().toISOString(), argv: process.argv }, null, 2), { flag: 'wx' }); }
 catch (error) {
  if (existsSync(lockPath)) throw Error('Performance run already locked; inspect owner before removing a stale lock: ' + readFileSync(lockPath, 'utf8'));
  throw error;
 }
 acquired = true;
 process.once('exit', () => { try { const lock = JSON.parse(readFileSync(lockPath, 'utf8')); if (lock.pid === process.pid) unlinkSync(lockPath); } catch {} });
}
