// Scratch-only response transformation. Never use these rows as formal performance proof.
// Prepare only until the root agent grants the exclusive browser/CPU lease.
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { launch, newCtx, watch, save, TARGETS, OUT, wait3d, health, LABEL } from './lib.mjs';

const EXPECTED = '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e';
const runtimePath = '/assets/runtime-DH-0TOIs.js';
const DEPLOYED_SHA256 = '30b23e3c026f10b81a5f94b70b89777f52b2c070d00e7a85a7d3753fe26d36d2';
const originalFile = fileURLToPath(new URL('../results/r3-prepare-diagnostic-v2/runtime-original-deployed.js', import.meta.url));
if (!process.argv.includes(`--expected=${EXPECTED}`)) throw Error('This diagnostic is pinned to the exact reviewed 52fa4088 source; pass its full --expected SHA.');
if (LABEL !== 'r3-prepare-diagnostic-v2') throw Error('This reviewed deployed-response diagnostic requires --label=r3-prepare-diagnostic-v2.');
if (existsSync(path.join(OUT, 'prepare-diagnostic.json'))) throw Error('Refusing to reuse a diagnostic label.');

// This exact expression and implementation were inspected in the retained deployed response.
// The pre-await comma expressions, single await/call, abort check and rejection identity
// are preserved. Recording is guarded so it cannot swallow or replace an app exception.
const beforeAwait = 'this.syncView(0),this.follow.copy(l),this.followReady=w,this.host.scene.updateMatrixWorld(!0),this.camera.updateMatrixWorld(!0),n==null||n(`Preparing ${t.label} for your walk…`)';
const needle = `if(${beforeAwait},await this.prepareScene(),this.disposed||this.abort.signal.aborted)return;`;
const replacement = `${beforeAwait};try{globalThis.__worldFinishPreparationRecord("start")}catch{}try{await this.prepareScene();try{globalThis.__worldFinishPreparationRecord("fulfilled")}catch{}}catch(__worldFinishPreparationError){try{globalThis.__worldFinishPreparationRecord("rejected",__worldFinishPreparationError)}catch{}throw __worldFinishPreparationError}if(this.disposed||this.abort.signal.aborted)return;`;
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const original = readFileSync(originalFile), originalText = original.toString('utf8');
const sourceReview = JSON.parse(readFileSync(path.join(OUT, 'runtime-source-review.json'), 'utf8'));
if (sha256(original) !== DEPLOYED_SHA256 || sourceReview.expectedHead !== EXPECTED || !sourceReview.surroundingLoadAndPreparationImplementationEqual || !sourceReview.entireRuntimeEqualExceptRelativeChunkFilenameHashes) throw Error('Deployed source review/hash guard failed.');
const exactCount = (text, fragment) => text.split(fragment).length - 1;
if (exactCount(originalText, needle) !== 1 || exactCount(originalText, 'await this.prepareScene()') !== 1) throw Error('Saved runtime no longer has exactly one reviewed expression and await.');
const transformed = Buffer.from(originalText.replace(needle, replacement));
if (exactCount(transformed.toString(), 'await this.prepareScene()') !== 1) throw Error('Transformation did not preserve exactly one unchanged await/call.');

const report = {
  startedAt: new Date().toISOString(), label: LABEL, expectedHead: EXPECTED,
  diagnosticOnly: true, normalSource: false, responseTransformed: true, sourceInjection: true, styleInjection: false,
  method: 'Two serial cases only: separate fresh Chromium processes and contexts at the existing desktop/phone dimensions, pinned host/D3D11, same read-only request policy. Select the default character, click Start, and capture immediately when the first real rendered status is observed; no post-ready settling, sample retries, FPS run, or extra ready waits. Health is checked outside Chromium before/after each case. Only the exact runtime response is changed after status/body/hash/one-expression guards pass.',
  limitations: [
    'Response interception buffers the runtime and re-fulfills it without original content-encoding, length, or validators. This changes delivery, disables the normal browser cache through routing, and adds filesystem/hash/measurement overhead. All resource and overall entry timings are diagnostic, not comparable formal rows.',
    'The measured interval surrounds the original await this.prepareScene(). It includes the synchronous compileAsync setup, promise waiting/polling, cancellation or rejection, and JavaScript scheduling before await resumes. It is not a pure GPU compile duration and cannot attribute a later 131ms frame stall.',
    'Mutation observation and timing records add work. Progress timestamps are DOM observation times, not physical paint. The first status follows a render submission, not display photons.',
    'One case per device can identify whether the preparation wait is substantial in these runs. It cannot establish causality or justify reverting compile preparation by itself.'
  ],
  bounds: { cases: 2, retries: 0, browserCaseDeadlineMs: 180000, readyWaitTimeoutMs: 60000, routeFetchTimeoutMs: 30000, routeFetchRetries: 0, routeFetchRedirects: 0 },
  source: { originalFile, runtimePath, deployedSha256: DEPLOYED_SHA256, sourceReview: 'runtime-source-review.json', originalBytes: original.length, originalSha256: sha256(original), transformedBytes: transformed.length, transformedSha256: sha256(transformed), needle, replacement, exactReplacementCount: 1, unchangedAwaitCount: 1 },
  cases: []
};
save('prepare-diagnostic.json', report);
writeFileSync(path.join(OUT, 'harness-source.mjs'), readFileSync(fileURLToPath(import.meta.url)), { flag: 'wx' });
const transformedSyntaxFile = path.join(OUT, 'runtime-transform-reviewed.mjs');
writeFileSync(transformedSyntaxFile, transformed, { flag: 'wx' });
const syntax = spawnSync(process.execPath, ['--check', transformedSyntaxFile], { encoding: 'utf8', timeout: 10000, windowsHide: true });
report.source.transformedSyntaxCheck = { exitCode: syntax.status, stdout: syntax.stdout, stderr: syntax.stderr, error: syntax.error ? String(syntax.error) : null };
save('prepare-diagnostic.json', report);
if (syntax.status !== 0) throw Error('Transformed runtime syntax check failed before browser launch.');

async function retainHealth(row, key) {
  try { row[key] = await health('walk'); }
  catch (error) { row[key] = { at: new Date().toISOString(), error: String(error) }; return false; }
  return row[key].status === 200 && row[key].body?.commit === EXPECTED && row[key].body?.env === 'preview';
}

for (const device of ['desktop', 'phone']) {
  const row = { device, expectedHead: EXPECTED, startedAt: new Date().toISOString(), transforms: [], routeErrors: [], blockedWrites: [] };
  report.cases.push(row);
  if (!await retainHealth(row, 'healthBefore')) { row.fatal = 'Exact preview health failed; no browser launched for this case.'; save('prepare-diagnostic.json', report); break; }
  let browser, context, page, watchdog, log;
  const caseDirectory = path.join(OUT, device); mkdirSync(caseDirectory, { recursive: true });
  try {
    browser = await launch();
    watchdog = setTimeout(() => { row.deadlineExpired = true; void browser.close().catch(() => {}); }, 180000);
    ({ context, log } = await newCtx(browser, device));
    await context.route(url => url.origin === new URL(TARGETS.walk).origin && url.pathname === runtimePath, async route => {
      const request = route.request();
      if (request.method() !== 'GET') { row.routeErrors.push('Unexpected method on runtime route: ' + request.method()); await route.abort('blockedbyclient'); return; }
      const item = { url: request.url(), method: request.method(), routeAt: new Date().toISOString() };
      row.transforms.push(item);
      try {
        if (row.transforms.length !== 1) throw Error('Expected exactly one runtime response per fresh context.');
        const response = await route.fetch({ maxRetries: 0, maxRedirects: 0, timeout: 30000 });
        item.fetchedAt = new Date().toISOString(); item.status = response.status(); item.originalHeaders = response.headers();
        const bytes = await response.body(); item.bodyReadAt = new Date().toISOString();
        item.originalBytes = bytes.length; item.originalSha256 = sha256(bytes);
        writeFileSync(path.join(caseDirectory, 'runtime-original.js'), bytes, { flag: 'wx' });
        if (item.status !== 200 || !bytes.equals(original)) throw Error('Delivered runtime does not exactly match the retained current source bytes.');
        if (exactCount(bytes.toString('utf8'), needle) !== 1) throw Error('Delivered runtime lacks the one exact reviewed replacement.');
        writeFileSync(path.join(caseDirectory, 'runtime-transformed.js'), transformed, { flag: 'wx' });
        const headers = { ...item.originalHeaders };
        for (const name of ['content-encoding', 'content-length', 'etag', 'content-md5', 'last-modified']) delete headers[name];
        item.fulfilledHeaders = headers; item.transformedBytes = transformed.length; item.transformedSha256 = sha256(transformed); item.exactReplacementCount = 1;
        await route.fulfill({ status: response.status(), headers, body: transformed }); item.fulfilledAt = new Date().toISOString();
      } catch (error) {
        item.error = String(error); row.routeErrors.push(String(error));
        await route.abort('failed').catch(() => {});
      } finally { save('prepare-diagnostic.json', report); }
    });
    await context.addInitScript(() => {
      const state = globalThis.__worldFinishPreparationDiagnostic = { timeOrigin: performance.timeOrigin, actions: [], progress: [], preparations: [], firstStatus: null, instrumentationErrors: [] };
      globalThis.__worldFinishPreparationRecord = (result, error) => {
        try {
          const now = performance.now();
          if (result === 'start') state.preparations.push({ startAt: now, result: 'pending' });
          else {
            const item = state.preparations[state.preparations.length - 1];
            if (!item || item.result !== 'pending') { state.instrumentationErrors.push('End without one pending start'); return; }
            item.endAt = now; item.durationMs = now - item.startAt; item.result = result;
            if (result === 'rejected') item.error = { type: typeof error, name: typeof error?.name === 'string' ? error.name : null, message: typeof error?.message === 'string' ? error.message : null };
          }
        } catch { state.instrumentationErrors.push('Recording failed'); }
      };
      let started = false, lastProgress = null;
      document.addEventListener('click', event => {
        const button = event.target?.closest?.('button');
        const kind = button?.getAttribute('aria-label') === 'Open Walk mode' ? 'open-chooser' : button?.textContent?.trim() === 'Start walk' ? 'start-walk' : null;
        if (kind) { state.actions.push({ kind, eventAt: event.timeStamp, observedAt: performance.now() }); if (kind === 'start-walk') started = true; }
      }, true);
      const observer = new MutationObserver(() => {
        if (!started) return;
        const walk = document.querySelector('[data-world-walk]');
        const progress = walk?.querySelector('.world-walk-loading[role="status"]')?.textContent?.trim() ?? null;
        if (progress !== lastProgress) { state.progress.push({ at: performance.now(), text: progress }); lastProgress = progress; }
        const status = walk?.getAttribute('data-status');
        if (status && !state.firstStatus) { state.firstStatus = { observedAt: performance.now(), value: JSON.parse(status) }; observer.disconnect(); }
      });
      observer.observe(document, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-status'] });
    });
    page = await context.newPage(); page.setDefaultTimeout(60000); watch(page, row);
    await page.goto(TARGETS.walk + '/demo?view=3d&pitch=1', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await wait3d(page);
    await page.getByRole('button', { name: 'Open Walk mode', exact: true }).click({ noWaitAfter: true });
    await page.getByTestId('walk-chooser').waitFor();
    // Same decoded chooser condition as the retained performance harness, no arbitrary delay.
    await page.waitForFunction(() => {
      const el = document.querySelector('[data-testid="walk-chooser"]'), images = el ? [...el.querySelectorAll('img')] : [];
      return !!el && el.getBoundingClientRect().width > 0 && images.length === 4 && images.every(image => image.complete && image.naturalWidth > 0);
    });
    row.preStartResourceCount = await page.evaluate(() => performance.getEntriesByType('resource').length);
    await page.getByRole('button', { name: 'Start walk', exact: true }).click({ noWaitAfter: true });
    await page.waitForFunction(() => document.querySelector('[data-world-walk]')?.getAttribute('data-status'), {}, { timeout: 60000 });
    row.capture = await page.evaluate(() => ({ capturedAt: performance.now(), ...globalThis.__worldFinishPreparationDiagnostic,
      status: JSON.parse(document.querySelector('[data-world-walk]').getAttribute('data-status')),
      resources: performance.getEntriesByType('resource').map(entry => entry.toJSON()), navigation: performance.getEntriesByType('navigation').map(entry => entry.toJSON()) }));
    const preparations = row.capture.preparations;
    const start = row.capture.actions.find(action => action.kind === 'start-walk');
    const selectedResources = row.capture.resources.filter(resource => /(?:\/runtime-[^/]+\.js|\.glb(?:\?|$)|\/draco\/)/.test(resource.name));
    const lastResponseEnd = selectedResources.length ? Math.max(...selectedResources.map(resource => resource.responseEnd)) : null;
    row.derived = { actionAt: start?.eventAt ?? null, readyObservedAt: row.capture.firstStatus?.observedAt ?? null,
      actionToFirstStatusMs: start && row.capture.firstStatus ? row.capture.firstStatus.observedAt - start.eventAt : null,
      reportedEntryMs: row.capture.status.entryMs, preparationAwaitMs: preparations[0]?.durationMs ?? null,
      preparationEndToFirstStatusMs: preparations[0]?.endAt && row.capture.firstStatus ? row.capture.firstStatus.observedAt - preparations[0].endAt : null,
      lastRelevantResponseEnd: lastResponseEnd, lastResponseToFirstStatusMs: lastResponseEnd !== null && row.capture.firstStatus ? row.capture.firstStatus.observedAt - lastResponseEnd : null,
      selectedResources };
    row.validDiagnostic = row.transforms.length === 1 && !row.transforms[0].error && row.routeErrors.length === 0 && preparations.length === 1 && preparations[0].result === 'fulfilled' && row.capture.instrumentationErrors.length === 0 && !!row.capture.firstStatus;
    if (!row.validDiagnostic) throw Error('Diagnostic instrumentation completeness check failed.');
  } catch (error) {
    row.fatal = String(error);
    if (page && !page.isClosed()) row.partialCapture = await page.evaluate(() => ({ capturedAt: performance.now(), ...globalThis.__worldFinishPreparationDiagnostic, resources: performance.getEntriesByType('resource').map(entry => entry.toJSON()) })).catch(captureError => ({ error: String(captureError) }));
  } finally {
    row.blockedWrites = log?.blockedWrites ?? [];
    if (watchdog) clearTimeout(watchdog);
    if (context) await context.close().catch(error => { row.contextCloseError = String(error); });
    if (browser) await browser.close().catch(error => { row.browserCloseError = String(error); });
    row.browserClosed = browser ? !browser.isConnected() : true;
    row.healthAfterMatches = await retainHealth(row, 'healthAfter');
    row.endedAt = new Date().toISOString();
    save('prepare-diagnostic.json', report);
    console.log(JSON.stringify({ device, validDiagnostic: row.validDiagnostic ?? false, prepareAwaitMs: row.derived?.preparationAwaitMs, reportedEntryMs: row.derived?.reportedEntryMs, healthAfterMatches: row.healthAfterMatches, browserClosed: row.browserClosed, fatal: row.fatal }));
  }
  if (!row.healthAfterMatches) break;
}
report.endedAt = new Date().toISOString();
report.complete = report.cases.length === 2 && report.cases.every(row => row.validDiagnostic && row.healthAfterMatches && row.browserClosed && !row.fatal);
save('prepare-diagnostic.json', report);
if (!report.complete) process.exitCode = 1;
