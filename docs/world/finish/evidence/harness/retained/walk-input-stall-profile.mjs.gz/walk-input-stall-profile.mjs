import { launch, newCtx, watch, save, TARGETS, health, wait3d } from './lib.mjs';
const target = process.argv[2] ?? 'walk';
const expected = process.argv.find(argument => argument.startsWith('--expected='))?.slice(11);
if (!/^[a-f0-9]{40}$/.test(expected ?? '')) throw Error('Pass --expected=<exact published SHA>.');
const report = { startedAt: new Date().toISOString(), harnessVersion: 2, target, expected, device: 'desktop', durationMs: 15000,
  method: 'Separate bounded desktop third-person input-stall diagnostic. Profiler setup precedes navigation; CPU/timeline recording starts at DOMContentLoaded and remains active through15seconds after ready. No added post-ready settling, no screenshot, no pose injection, no source changes. Native event and runtime handler/render times, CPU stacks, trace tasks/GPU metadata, resource times, original-stage snapshot counts and canvas preparation attributes are preserved. Instrumentation affects timing; no diagnostic sample replaces formal input or FPS.',
  healthBefore: await health(target), inputs: [], snapshots: [] };
save('input-stall-profile-summary.json', report);
if (report.healthBefore.status !== 200 || report.healthBefore.body.commit !== expected) throw Error('Unexpected deployed head; no browser launched.');
const browser = await launch(), { context, log } = await newCtx(browser, 'desktop'), page = await context.newPage(), cdp = await context.newCDPSession(page);
page.setDefaultTimeout(60000); watch(page, report);
let tracing = false, profiling = false; const traceEvents = [];
cdp.on('Tracing.dataCollected', event => traceEvents.push(...event.value));
const snapshot = async phase => {
  const data = await page.evaluate(() => {
    const button = document.querySelector('button[aria-label="Open Walk mode"]'); let background = null;
    if (button) {
      button.addEventListener('world-walk-background-result', event => { background = event.detail; }, { once: true });
      button.dispatchEvent(new Event('world-walk-measure-background'));
    }
    return { at: performance.now(), background, canvases: [...document.querySelectorAll('canvas')].map(canvas => ({ testid: canvas.getAttribute('data-testid'), inWalk: !!canvas.closest('[data-world-walk]'), dataset: { ...canvas.dataset } })) };
  });
  report.snapshots.push({ phase, ...data });
};
async function stopTrace(name) {
  if (!tracing) return;
  const complete = new Promise(resolve => cdp.once('Tracing.tracingComplete', resolve));
  await cdp.send('Tracing.end');
  await Promise.race([complete, new Promise((_, reject) => setTimeout(() => reject(Error('Trace completion exceeded10s')), 10000))]);
  tracing = false; save(name, { traceEvents });
}
try {
  await context.addInitScript(() => {
    window.__nativeKeys = [];
    for (const type of ['keydown', 'keyup']) window.addEventListener(type, event => {
      if (['KeyW', 'KeyS'].includes(event.code)) window.__nativeKeys.push({ type, code: event.code, eventAt: event.timeStamp, listenerAt: performance.now() });
    }, true);
  });
  await cdp.send('Performance.enable'); await cdp.send('Debugger.enable'); await cdp.send('Profiler.enable');
  await cdp.send('Profiler.setSamplingInterval', { interval: 1000 });
  await page.goto(TARGETS[target] + '/demo?view=3d&pitch=1', { waitUntil: 'domcontentloaded' });
  await cdp.send('Tracing.start', { categories: 'devtools.timeline,v8.execute,blink.user_timing,input,latencyInfo,gpu,disabled-by-default-devtools.timeline', transferMode: 'ReportEvents' }); tracing = true;
  await cdp.send('Profiler.start'); profiling = true;
  await wait3d(page); await page.getByRole('button', { name: 'Open Walk mode', exact: true }).waitFor(); await snapshot('before-chooser');
  await page.getByRole('button', { name: 'Open Walk mode', exact: true }).click(); await snapshot('chooser-open');
  await page.getByRole('button', { name: 'Start walk', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('[data-world-walk]')?.getAttribute('data-status'));
  await page.evaluate(() => {
    window.__diagnosticFrames = null; window.__diagnosticStart = performance.now();
    const canvas = document.querySelector('[data-world-walk] canvas');
    canvas.addEventListener('world-walk-frame-result', event => { window.__diagnosticFrames = event.detail; }, { once: true });
    canvas.dispatchEvent(new CustomEvent('world-walk-measure-frames', { detail: { durationMs: 15000 } }));
    performance.mark('input-stall-diagnostic-start');
  });
  await snapshot('ready-armed');
  for (let n = 0; n < 15; n++) {
    const key = n % 2 ? 'KeyS' : 'KeyW';
    await page.locator('[data-world-walk] canvas').evaluate((canvas, n) => {
      window.__diagnosticInput = null;
      canvas.addEventListener('world-walk-input-result', event => { window.__diagnosticInput = event.detail; }, { once: true });
      canvas.dispatchEvent(new CustomEvent('world-walk-measure-input'));
      performance.mark('input-stall-arm-' + n);
    }, n);
    await page.keyboard.down(key);
    try {
      await page.waitForFunction(() => window.__diagnosticInput, {}, { timeout: 2500 });
      const value = await page.evaluate(() => window.__diagnosticInput);
      report.inputs.push({ n, key, ...value, delayMs: value.firstMovedRenderedAt - value.inputAt, eventToHandlerMs: value.handlerAt - value.inputAt, handlerToRenderMs: value.firstMovedRenderedAt - value.handlerAt });
    } catch (error) { report.inputs.push({ n, key, failure: String(error) }); }
    finally { await page.keyboard.up(key); }
    if (await page.evaluate(() => !!window.__diagnosticFrames)) break;
    await page.waitForTimeout(150);
  }
  await page.waitForFunction(() => window.__diagnosticFrames, {}, { timeout: 16000 }); await snapshot('window-complete');
  Object.assign(report, await page.evaluate(() => ({ frames: window.__diagnosticFrames, keyCapture: window.__nativeKeys, now: performance.now(), timeOrigin: performance.timeOrigin,
    startMark: performance.getEntriesByName('input-stall-diagnostic-start')[0]?.startTime,
    resources: performance.getEntriesByType('resource').map(r => ({ url: r.name, start: r.startTime, end: r.responseEnd })),
    status: JSON.parse(document.querySelector('[data-world-walk]').dataset.status) })));
  const { metrics } = await cdp.send('Performance.getMetrics'); report.metrics = Object.fromEntries(metrics.map(item => [item.name, item.value]));
  const { profile } = await cdp.send('Profiler.stop'); profiling = false; save('input-stall-cpu-profile.json', profile);
  await stopTrace('input-stall-trace.json');
  const navUs = report.metrics.NavigationStart * 1e6, begin = navUs + report.frames.startedAt * 1000, end = navUs + report.frames.deadlineAt * 1000;
  report.clock = { navigationStartUs: navUs, beginUs: begin, endUs: end, profileStartUs: profile.startTime, profileEndUs: profile.endTime,
    traceStartMarks: traceEvents.filter(event => event.name === 'input-stall-diagnostic-start'), note: 'Use the user-timing mark to validate trace/navigation alignment. CDP request round-trip differences are not clock corrections.' };
  const nodes = new Map(profile.nodes.map(node => [node.id, node])), parents = new Map();
  for (const node of nodes.values()) for (const child of node.children ?? []) parents.set(child, node.id);
  const samples = []; let sampleAt = profile.startTime;
  for (let i = 0; i < profile.samples.length; i++) { const next = sampleAt + profile.timeDeltas[i]; samples.push({ start: sampleAt, end: next, id: profile.samples[i] }); sampleAt = next; }
  const rankWindow = (from, to) => {
    const self = new Map();
    for (const sample of samples) { const weight = Math.max(0, Math.min(sample.end, to) - Math.max(sample.start, from)); if (weight) self.set(sample.id, (self.get(sample.id) ?? 0) + weight); }
    return [...self.entries()].sort((a, b) => b[1] - a[1]).slice(0, 30).map(([id, weight]) => {
      const stack = []; let nodeId = id;
      while (nodes.has(nodeId)) { stack.push(nodes.get(nodeId).callFrame); if (!parents.has(nodeId)) break; nodeId = parents.get(nodeId); }
      return { id, selfMs: weight / 1000, stack };
    });
  };
  report.windowStacks = rankWindow(begin, end);
  report.inputStacks = report.inputs.filter(input => Number.isFinite(input.delayMs)).map(input => ({ n: input.n, delayMs: input.delayMs, stacks: rankWindow(navUs + input.inputAt * 1000, navUs + input.firstMovedRenderedAt * 1000) }));
  report.traceThreads = traceEvents.filter(event => event.ph === 'M' && event.name === 'thread_name');
  report.overlappingLongTasks = traceEvents.filter(event => event.ph === 'X' && event.dur >= 50000 && event.ts < end && event.ts + event.dur > begin).map(event => ({ ...event, navigationRelativeStartMs: (event.ts - navUs) / 1000 }));
  const scripts = new Map(); report.sourceSnippets = [];
  for (const item of [...report.windowStacks.slice(0, 15), ...report.inputStacks.filter(item => item.delayMs >= 50).flatMap(item => item.stacks.slice(0, 15))]) for (const frame of item.stack) {
    if (!frame.url || frame.lineNumber < 0 || !frame.scriptId || report.sourceSnippets.some(existing => existing.frame.scriptId === frame.scriptId && existing.frame.lineNumber === frame.lineNumber && existing.frame.columnNumber === frame.columnNumber)) continue;
    if (!scripts.has(frame.scriptId)) scripts.set(frame.scriptId, (await cdp.send('Debugger.getScriptSource', { scriptId: frame.scriptId })).scriptSource.split('\n'));
    const line = scripts.get(frame.scriptId)[frame.lineNumber] ?? '';
    report.sourceSnippets.push({ frame, text: line.slice(Math.max(0, frame.columnNumber - 30), frame.columnNumber + 750) });
    if (report.sourceSnippets.length >= 100) break;
  }
} catch (error) { report.failure = String(error); }
finally {
  if (profiling) try { save('input-stall-cpu-partial.json', (await cdp.send('Profiler.stop')).profile); } catch (error) { report.profileCleanupError = String(error); }
  if (tracing) try { await stopTrace('input-stall-trace-partial.json'); } catch (error) { report.traceCleanupError = String(error); save('input-stall-trace-retained.json', { traceEvents }); }
  report.blockedWrites = log.blockedWrites; await browser.close(); report.browserClosed = true;
  report.healthAfter = await health(target); report.healthStable = report.healthBefore.body.commit === report.healthAfter.body.commit;
  report.endedAt = new Date().toISOString(); save('input-stall-profile-summary.json', report);
  console.log(JSON.stringify({ inputs: report.inputs.map(input => ({ n: input.n, delayMs: input.delayMs, failure: input.failure })), healthStable: report.healthStable, failure: report.failure, browserClosed: report.browserClosed }));
  if (report.failure || !report.healthStable) process.exitCode = 1;
}
