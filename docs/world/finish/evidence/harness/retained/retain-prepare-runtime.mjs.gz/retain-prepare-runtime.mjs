import https from 'node:https';
import { createHash } from 'node:crypto';
import { writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { health, TARGETS, OUT, LABEL } from './lib.mjs';
const expected = '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e';
if (LABEL !== 'r3-prepare-diagnostic-v2') throw Error('This bounded source capture is only for r3-prepare-diagnostic-v2.');
const destination = path.join(OUT, 'runtime-original-deployed.js');
if (existsSync(destination)) throw Error('Refusing to overwrite retained response.');
const metadata = { at: new Date().toISOString(), method: 'Pinned read-only GET with original host/TLS SNI and Accept-Encoding identity; no browser.', expectedHead: expected, url: TARGETS.walk + '/assets/runtime-DH-0TOIs.js', healthBefore: await health('walk') };
const write = () => writeFileSync(path.join(OUT, 'runtime-fetch-metadata.json'), JSON.stringify(metadata, null, 2) + '\n');
write();
if (metadata.healthBefore.status !== 200 || metadata.healthBefore.body.commit !== expected || metadata.healthBefore.body.env !== 'preview') throw Error('Exact preview health failed before fetch.');
try {
  const result = await new Promise((resolve, reject) => {
    const request = https.get(metadata.url, { headers: { 'Accept-Encoding': 'identity' }, lookup: (_host, options, callback) => options.all ? callback(null, [{ address: '216.198.79.3', family: 4 }]) : callback(null, '216.198.79.3', 4) }, response => {
      const chunks = []; response.on('data', chunk => chunks.push(chunk)); response.on('end', () => resolve({ status: response.statusCode, headers: response.headers, body: Buffer.concat(chunks) })); response.on('error', reject);
    });
    request.setTimeout(30000, () => request.destroy(Error('Runtime GET exceeded 30s.'))); request.on('error', reject);
  });
  metadata.status = result.status; metadata.headers = result.headers; metadata.bytes = result.body.length;
  metadata.sha256 = createHash('sha256').update(result.body).digest('hex');
  writeFileSync(destination, result.body, { flag: 'wx' });
  if (result.status !== 200 || (result.headers['content-encoding'] && result.headers['content-encoding'] !== 'identity')) throw Error('Unexpected response status/encoding; body retained but not approved for transformation.');
  metadata.healthAfter = await health('walk');
  if (metadata.healthAfter.status !== 200 || metadata.healthAfter.body.commit !== expected || metadata.healthAfter.body.env !== 'preview') throw Error('Exact preview health failed after fetch.');
  metadata.sourceRetained = true;
} catch (error) { metadata.error = String(error); throw error; }
finally { write(); }
console.log(JSON.stringify({ status: metadata.status, bytes: metadata.bytes, sha256: metadata.sha256, sourceRetained: metadata.sourceRetained }));
