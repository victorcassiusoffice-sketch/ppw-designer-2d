import { createHash } from 'node:crypto';
import { launch, newCtx, watch, save, TARGETS, OUT, wait3d, health } from './lib.mjs';
const target = process.argv[2] ?? 'walk';
const expected = process.argv.find(argument => argument.startsWith('--expected='))?.slice(11);
if (!/^[a-f0-9]{40}$/.test(expected ?? '')) throw Error('Pass --expected=<exact published SHA>.');
const report = { startedAt: new Date().toISOString(), harnessVersion: 2, target, expected, healthBefore: await health(target),
  method: 'Separate bounded functional diagnostic after retained phone-v1 heading failure. Native single-contact CDP touch and taps only; no keyboard or pose injection. Movement is held until observed displacement or a finite deadline, rather than assuming a140ms pulse produced movement. All native events and failed probe positions/timestamps are saved before assertions. This does not replace formal zero-settle input/FPS samples and is not human or physical-phone evidence.', rows: [] };
save('walk-functional-walk.json', report);
if (report.healthBefore.status !== 200 || report.healthBefore.body.commit !== expected) throw Error('Unexpected deployed head; no browser launched.');
const assert = (value, message) => { if (!value) throw Error(message); };
const distance = (a, b) => Math.hypot(a[0] - b[0], a[2] - b[2]);
const norm = angle => Math.atan2(Math.sin(angle), Math.cos(angle));
const browser = await launch(), { context, log } = await newCtx(browser, 'phone');
await context.addInitScript(() => {
  window.__phoneNative = { events: [], keys: [], maxTouches: 0 };
  for (const type of ['touchstart', 'touchmove', 'touchend', 'touchcancel']) window.addEventListener(type, event => {
    const data = window.__phoneNative;
    data.maxTouches = Math.max(data.maxTouches, event.touches.length);
    data.events.push({ type, eventAt: event.timeStamp, listenerAt: performance.now(), touches: [...event.touches].map(t => ({ id: t.identifier, x: t.clientX, y: t.clientY })) });
  }, true);
  for (const type of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel']) window.addEventListener(type, event => {
    if (event.pointerType === 'touch') window.__phoneNative.events.push({ type, eventAt: event.timeStamp, listenerAt: performance.now(), id: event.pointerId, x: event.clientX, y: event.clientY, target: event.target.className });
  }, true);
  window.addEventListener('keydown', event => window.__phoneNative.keys.push({ code: event.code, at: event.timeStamp }), true);
});
const page = await context.newPage(), cdp = await context.newCDPSession(page);
page.setDefaultTimeout(30000);
const row = { device: 'phone', checks: [], door: [], escape: [], navigation: [] }; report.rows.push(row); watch(page, row);
const status = async () => JSON.parse(await page.getByTestId('world-walk').getAttribute('data-status'));
const capture = async () => {
  const value = await page.evaluate(() => ({ saved: localStorage.getItem('ppw_property_v2'), camera: document.querySelector('[data-testid="wallpaint-3d-canvas"]')?.getAttribute('data-camera'), rendered: document.querySelector('[data-testid="wallpaint-3d-canvas"]')?.getAttribute('data-render-camera') }));
  assert(value.saved && JSON.parse(value.saved).state?.property?.rooms?.length, 'Non-null saved design required');
  assert(value.camera && value.camera !== 'null' && value.rendered && value.rendered !== 'null', 'Non-null cameras required');
  return { savedSha256: createHash('sha256').update(value.saved).digest('hex'), savedBytes: Buffer.byteLength(value.saved), cameraJson: value.camera, renderedCameraJson: value.rendered };
};
const compare = async () => { const after = await capture(); const unchanged = Object.keys(row.before).every(key => row.before[key] === after[key]); assert(unchanged, 'Saved design or cameras changed'); return { after, unchanged }; };
const start = async () => {
  await page.getByRole('button', { name: 'Open Walk mode', exact: true }).tap();
  await page.getByRole('button', { name: 'Start walk', exact: true }).tap();
  await page.waitForFunction(() => document.querySelector('[data-world-walk]')?.getAttribute('data-status'));
};
const exit = async () => {
  if (await page.getByTestId('world-walk').isVisible()) { await page.getByRole('button', { name: 'Exit walk', exact: true }).tap(); await page.getByTestId('world-walk').waitFor({ state: 'hidden' }); }
  await page.waitForTimeout(300);
};
const checkpoint = () => save('walk-functional-walk.json', report);
const check = async (name, fn) => {
  const item = { name }; row.checks.push(item);
  try { item.evidence = await fn(); item.passed = true; }
  catch (error) { item.failure = String(error); await page.screenshot({ path: OUT + `walk-phone-${name}-failure.jpg`, type: 'jpeg', quality: 65 }).catch(() => {}); }
  checkpoint();
};
async function moveUntil(metres, kind, limitMs = 3000) {
  const before = await status(), box = await page.locator('.world-walk-stick').boundingBox();
  assert(box, 'Missing native touch pad');
  const evidence = { kind, targetDistanceM: metres, limitMs, before, startedAt: await page.evaluate(() => performance.now()) }; row.navigation.push(evidence); checkpoint();
  await page.locator('[data-world-walk] canvas').evaluate(canvas => {
    window.__probeInput = null;
    canvas.addEventListener('world-walk-input-result', event => { window.__probeInput = event.detail; }, { once: true });
    canvas.dispatchEvent(new CustomEvent('world-walk-measure-input'));
  });
  try {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: box.x + box.width / 2, y: box.y + box.height / 2 - 40, id: 1 }] });
    await page.waitForFunction(({ start, metres }) => {
      const current = JSON.parse(document.querySelector('[data-world-walk]').dataset.status);
      return Math.hypot(current.position[0] - start[0], current.position[2] - start[2]) >= metres;
    }, { start: before.position, metres }, { timeout: limitMs });
    evidence.observedTarget = true;
  } catch (error) { evidence.failure = String(error); }
  finally {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    Object.assign(evidence, await page.evaluate(() => ({ after: JSON.parse(document.querySelector('[data-world-walk]').dataset.status), endedAt: performance.now(), input: window.__probeInput, nativeEvents: window.__phoneNative.events.slice(-20) })));
    evidence.displacementM = distance(before.position, evidence.after.position); checkpoint();
  }
  assert(evidence.observedTarget, `Native touch movement did not attain ${metres}m within ${limitMs}ms; complete no-displacement evidence retained`);
  return evidence;
}
try {
  await page.goto(TARGETS[target] + '/demo?view=3d&pitch=1', { waitUntil: 'domcontentloaded' }); await wait3d(page); row.before = await capture();
  await start(); row.initial = await status();
  await check('single-touch-movement-stop-restore', async () => {
    const moved = await moveUntil(.5, 'native-initial-move');
    await page.waitForTimeout(250); const released = await status(); await page.waitForTimeout(350); const stopped = await status();
    assert(distance(released.position, stopped.position) < .025, 'Movement continued after touch release');
    await exit(); return { moved, released, stopped, ...await compare() };
  });
  await exit(); await start();
  await check('single-touch-controls', async () => {
    await page.getByRole('button', { name: 'Controls', exact: true }).tap(); await page.getByRole('button', { name: 'Got it', exact: true }).waitFor();
    const help = await page.locator('.world-walk-help').innerText(); await page.getByRole('button', { name: 'Got it', exact: true }).tap();
    await page.getByRole('button', { name: 'Walk / run', exact: true }).tap(); await page.getByRole('button', { name: 'Running', exact: true }).waitFor();
    const running = await moveUntil(.4, 'native-run');
    assert(running.after.animation === 'run', 'Run toggle did not produce running animation while moving');
    await page.getByRole('button', { name: 'Running', exact: true }).tap();
    await page.getByRole('button', { name: 'First person', exact: true }).tap(); await page.waitForFunction(() => JSON.parse(document.querySelector('[data-world-walk]').dataset.status).mode === 'first');
    await page.getByRole('button', { name: 'Third person', exact: true }).tap(); await page.waitForFunction(() => JSON.parse(document.querySelector('[data-world-walk]').dataset.status).mode === 'third');
    await exit(); return { help, running, ...await compare() };
  });
  await exit(); await start();
  await check('single-touch-doors-both-views', async () => {
    const probe = await moveUntil(.10, 'native-heading-probe');
    let heading = Math.atan2(probe.before.position[0] - probe.after.position[0], probe.before.position[2] - probe.after.position[2]);
    const turn = async desired => {
      let remaining = -norm(desired - heading) / .004;
      for (let segment = 0; segment < 16 && Math.abs(remaining) > .1; segment++) {
        const part = Math.sign(remaining) * Math.min(80, Math.abs(remaining));
        const count = await page.evaluate(() => window.__phoneNative.events.length);
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: 230, y: 400, id: 1 }] });
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: 230 + part, y: 400, id: 1 }] });
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
        const events = await page.evaluate(count => window.__phoneNative.events.slice(count), count);
        const down = events.find(event => event.type === 'pointerdown'), move = events.findLast(event => event.type === 'pointermove');
        const actual = down && move ? move.x - down.x : 0;
        row.navigation.push({ kind: 'native-look-turn', desired, heading, commandPx: part, actualPx: actual, events }); checkpoint();
        assert(Math.abs(actual) > .01 && Math.abs(actual - part) < 1, 'Native touch drag did not deliver the intended look delta');
        heading = norm(heading - actual * .004); remaining -= actual;
      }
      assert(Math.abs(remaining) <= .1, 'Native look did not finish within16 bounded segments');
    };
    const destination = [2.4, 3.1];
    for (let step = 0; step < 8; step++) {
      const current = await status(), d = Math.hypot(destination[0] - current.position[0], destination[1] - current.position[2]);
      if (d < .2) break;
      await turn(Math.atan2(current.position[0] - destination[0], current.position[2] - destination[1]));
      await moveUntil(Math.min(.65, Math.max(.05, d - .1)), `native-door-approach-${step}`);
    }
    const stand = await status(); assert(Math.hypot(stand.position[0] - 2.4, stand.position[2] - 3.1) < .4, 'Door approach failed to reach safe standing area');
    await turn(Math.atan2(stand.position[0] - 2.4, stand.position[2] - 4.5));
    for (const mode of ['third', 'first']) {
      if (mode === 'first') await page.getByRole('button', { name: 'First person', exact: true }).tap();
      await page.getByRole('button', { name: /^Open door/ }).waitFor(); const evidence = { mode, before: await status() }; row.door.push(evidence);
      await page.getByRole('button', { name: /^Open door/ }).tap(); await page.getByRole('button', { name: /^Close door/ }).waitFor(); await page.waitForTimeout(1300);
      evidence.afterSwing = await status(); evidence.retainedClosePrompt = await page.getByRole('button', { name: /^Close door/ }).isVisible();
      assert(evidence.retainedClosePrompt && !evidence.afterSwing.blocked, 'Close prompt not safely retained');
      await page.screenshot({ path: OUT + `walk-phone-${mode}-door-open.jpg`, type: 'jpeg', quality: 65 });
      await page.getByRole('button', { name: /^Close door/ }).tap(); await page.getByRole('button', { name: /^Open door/ }).waitFor(); await page.waitForTimeout(1100);
      evidence.closed = await status(); assert(evidence.closed.door === 'Open door' && !evidence.closed.blocked, 'Door failed to close safely'); evidence.passed = true; checkpoint();
    }
    await exit(); return { door: row.door, ...await compare() };
  });
  await exit(); await check('native-exit', async () => { await start(); await exit(); return compare(); });
  row.final = await capture();
} catch (error) { row.fatal = String(error); }
finally {
  row.native = await page.evaluate(() => window.__phoneNative).catch(() => null);
  row.singlePointerOnly = row.native?.maxTouches === 1 && row.native.keys.length === 0;
  row.blockedWrites = log.blockedWrites;
  row.passed = !row.fatal && row.checks.length === 4 && row.checks.every(item => item.passed) && row.singlePointerOnly && !row.pageErrors.length && !row.consoleErrors.length && !row.httpErrors.length && !row.blockedWrites.length;
  await browser.close(); row.browserClosed = true;
  report.healthAfter = await health(target); report.healthStable = report.healthBefore.body.commit === report.healthAfter.body.commit;
  report.passed = row.passed && report.healthStable; report.endedAt = new Date().toISOString(); checkpoint();
  console.log(JSON.stringify({ passed: report.passed, checks: row.checks.map(check => ({ name: check.name, passed: check.passed, failure: check.failure })), singlePointerOnly: row.singlePointerOnly, browserClosed: row.browserClosed }));
  if (!report.passed) process.exitCode = 1;
}
