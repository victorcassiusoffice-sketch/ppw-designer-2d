import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const out = new URL('../results/r3-prepare-diagnostic-v2/', import.meta.url);
const deployed = readFileSync(new URL('runtime-original-deployed.js', out), 'utf8');
const local = readFileSync(new URL('../builds/r3-final-v5/walk/assets/runtime-C0xgD9TB.js', import.meta.url), 'utf8');
const relativeChunks = /(["'])(\.\/[^"']+-)[A-Za-z0-9_-]{8}\.(js|css)\1/g;
const normalize = text => text.replace(relativeChunks, (_all, quote, stem, ext) => quote + stem + '<HASH>.' + ext + quote);
const around = text => { const at = text.indexOf('await this.prepareScene()'); return text.slice(at - 600, at + 1000); };
const record = { reviewedAt: new Date().toISOString(), expectedHead: '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e',
  exactAwaitCount: deployed.split('await this.prepareScene()').length - 1,
  surroundingLoadAndPreparationImplementationEqual: around(deployed) === around(local),
  entireRuntimeEqualExceptRelativeChunkFilenameHashes: normalize(deployed) === normalize(local),
  normalizationRegex: relativeChunks.source,
  deployedRelativeChunkLiterals: [...deployed.matchAll(relativeChunks)].map(match => match[0]),
  localRelativeChunkLiterals: [...local.matchAll(relativeChunks)].map(match => match[0]),
  inspectedExpressionAndImplementation: around(deployed),
  findings: 'The full load/preparation expression and prepareScene implementation match the reviewed source: same once-only await, abort-driven promise rejection, compileAsync(scene,camera), and then callbacks. Relative generated dependency names may vary between cloud and local builds; the transformation must bind to retained deployed bytes, never normalize bytes at execution.' };
writeFileSync(new URL('runtime-source-review.json', out), JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ file: fileURLToPath(new URL('runtime-source-review.json', out)), exactAwaitCount: record.exactAwaitCount, expressionEqual: record.surroundingLoadAndPreparationImplementationEqual, normalizedEntireRuntimeEqual: record.entireRuntimeEqualExceptRelativeChunkFilenameHashes }));
if (!record.surroundingLoadAndPreparationImplementationEqual || !record.entireRuntimeEqualExceptRelativeChunkFilenameHashes || record.exactAwaitCount !== 1) process.exitCode = 1;
