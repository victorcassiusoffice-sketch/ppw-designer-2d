import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import { TARGETS, BASE_COMMIT, LABEL, OUTPUT, acquireRun } from '../run-config.mjs';
export { TARGETS, BASE_COMMIT, LABEL };
const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); }
catch { playwright = createRequire('C:/Users/Victor/Documents/PPW-Code/ppw-tutorial-studio/package.json')('playwright'); }
export const { chromium } = playwright;
export const OUT = OUTPUT + path.sep;
mkdirSync(OUTPUT, { recursive: true });
const PIN = Object.values(TARGETS).filter(u => u.startsWith('https:')).map(u => `MAP ${new URL(u).hostname} 216.198.79.3`).join(',');
export const DEVICES = { desktop: { viewport: { width: 1280, height: 800 } }, phone: { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 } };
export function launch() { acquireRun('browser'); return chromium.launch({ headless: true, args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', `--host-resolver-rules=${PIN}`] }); }
export async function newCtx(browser, device) {
 const context = await browser.newContext(DEVICES[device]), log = { blockedWrites: [] };
 await context.route('**/*', route => { const r = route.request(); if (!['GET', 'HEAD', 'OPTIONS'].includes(r.method())) { log.blockedWrites.push({ method: r.method(), url: r.url() }); return route.abort('blockedbyclient'); } return route.continue(); });
 await context.addInitScript(() => { localStorage.setItem('ppw_designer_coach_v1', '1'); });
 return { context, log };
}
export function watch(page, row) {
 row.pageErrors = []; row.consoleErrors = []; row.httpErrors = [];
 page.on('pageerror', e => row.pageErrors.push(String(e)));
 page.on('console', m => { if (m.type() === 'error') row.consoleErrors.push(m.text().slice(0, 500)); });
 page.on('response', r => { if (r.status() >= 400) row.httpErrors.push({ status: r.status(), url: r.url() }); });
}
const ownedFiles = new Set();
export function save(name, data) {
 const destination = path.join(OUTPUT, name);
 if (!ownedFiles.has(destination) && existsSync(destination)) throw Error('Refusing to overwrite a previous experiment: ' + destination);
 ownedFiles.add(destination); writeFileSync(destination, JSON.stringify(data, null, 2) + '\n');
}
export const wait3d = async page => { await page.waitForFunction(() => Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0, {}, { timeout: 90000 }); };
/** Separate Node HTTPS connection: health verification never warms the measured Chromium profile. */
export function health(target) {
 const url = new URL('/api/healthcheck', TARGETS[target]);
 return new Promise((resolve, reject) => {
  const request = https.get(url, { lookup: (_host, options, callback) => options.all ? callback(null, [{ address: '216.198.79.3', family: 4 }]) : callback(null, '216.198.79.3', 4) }, response => {
   let body = ''; response.on('data', chunk => body += chunk); response.on('end', () => {
    try { resolve({ at: new Date().toISOString(), target, url: url.href, status: response.statusCode, body: JSON.parse(body) }); }
    catch { reject(Error('Health response was not JSON: ' + target + ' ' + response.statusCode)); }
   });
  });
  request.setTimeout(30000, () => request.destroy(Error('Health request timed out: ' + target)));
  request.on('error', reject);
 });
}
