# Published Round 2 diagnostics, 29 October 2026

These diagnostic browser runs are separate from formal timing campaigns. Exact health responses are retained in every report. Walk head: `db092fc2f2b568cdb627a377b349e71dcd711a82`; Site head: `0e55d0d934e4241a173f24784a49031859e6a3a8`; base: `56d852d1f2f5d7342b9e02194964d6b998c795c7`.

## Startup paint

`startup-paint/r2-paint-v1/{walk,site}/report.json` and their numbered frames preserve a CDP screencast, FCP observer state, DOM transitions and exact health. The first content-bearing frame, `*-frame-001.jpg`, was visually reviewed for all four cases: it shows the HTML single-tile Loading 3D panel, before any React children exist. This is pixel evidence beyond DOM visibility alone.

| Branch/device | HTML visible DOM ms | FCP ms | Reviewed painted frame ms | First React child ms |
|---|---:|---:|---:|---:|
| Walk desktop | 407.1 | 532 | 534.2 | 1667.2 |
| Walk phone | 391.5 | 400 | 413.6 | 1610.6 |
| Site desktop | 492.6 | 608 | 624.0 | 1735.8 |
| Site phone | 398.1 | 408 | 409.3 | 1205.9 |

All four had zero page errors and zero attempted writes. Screencast and observers add work: the first-picture timings in these reports must not replace formal pairs or count towards their medians.

## Plumbing matrix

`plumbing/r2-plumbing-v1/{walk,site}/report.json`: each branch passed 6 chapters × 3 themes × 2 viewports, 36 states, with zero overflow, page/console/HTTP errors or attempted writes. The real enquiry form and designer iframe loaded; trailing-slash + PPW brand query + encoded final-chapter hash worked without a hero preload. Both initial entries requested exactly three isolated JS module files and one isolated stylesheet, no primary main JS or FX request. Desktop selected the 672w WebP, phone the 384w WebP. Fonts and decoded images were ready before screenshots.

All 72 chapter captures were visually reviewed using the eight contact sheets listed in `image-review-manifest.json`. This revealed the inherited footer contrast failure below, so this is **not a blanket visual pass**. Preferences screenshots are preserved separately. Current coverage across all chapters/themes: initial CSS 89,881 characters, 26,007 desktop/26,031 phone used; lazy enquiry CSS 48,783 characters, 4,826/5,116 used. These are browser coverage character counts, not transfer or gzip sizes, and unused in this matrix does not authorize deleting global rules.

## Hosting request investigation

`hosting-probe/r2-hosting-v1/report.json` retains actual browser response HTML, request initiators, script DOM, frame URLs and blocked-write lists for base/Walk/Site × desktop/phone × fresh-direct/health-first (12 cases). Fresh-direct health is verified in a different browser context to avoid priming the tested context. All 12 produced zero `vercel.live` requests, references or frames and zero attempted writes. No headers, hosting filters or formal settings were changed.

This **does not explain or invalidate** the automatic blocked POST recorded in `renderer-candidate-walk-v1`. Its raw failure remains. The anomaly was not reproduced under either navigation order; a confirmed causal classification is unavailable.

## Inherited contrast failure and pending fix

`pitch-contrast/r2-footer-v1/report.json` + nine button PNGs prove the same exact failure on base and both candidates: ivory 13.3899:1; Ocean 1.00198:1; Slate 1.02477:1. Theme ink becomes light while the generic sales button retains its ivory background. This predates route isolation.

A scoped footer surface/hover/focus repair and a new browser contrast/navigation regression are prepared in both worktrees. They are not part of the published heads tested above and need their own build/browser verification. Existing screenshots retain the failure.

Follow-up, 10:30 MU: the first Walk full suite after the repair passed 4,429/4,430, failing the existing `olbTheme.test.ts` generated-output reproducibility assertion because I omitted the required generated OLB stylesheet update. The original failure is retained at `verification/walk-warmrestore-20261029T062308Z/full-suite.log`. Ran the existing `node tools/brand/gen-olb-theme.ts` in both repositories. Only `salesPack.olb.generated.css` has a semantic diff: the same three footer theme rules, 12 lines. Pitch and Studio generated files remain content-equivalent. Focused existing theme tests pass 8/8 on each branch and scoped lint of the new browser test passes, logs under `verification/footer-generated-{walk,site}`. The browser contrast regression still awaits the new preview. Lesson: after editing a source listed in `OLB_THEME_OUTPUTS`, run its existing generator and reproducibility test before declaring the concern ready.

## Finalized build attribution

`build-attribution.json`, generated from `builds/r2-final/{base,walk,site}/audit.json`, compares final disk output and pre-minification module render lengths. The 28-file closure is base 2,905,199 raw / 871,303 gzip; Walk 2,907,161 / 871,976 (+1,962 / +673); Site 2,907,675 / 872,238 (+2,476 / +935). Isolated plumbing metadata/entry are late. The secondary build preserved hashes of all 620 Walk / 613 Site original non-HTML assets and emitted no public source maps.

The gzip ceiling passing **does not establish the semantic seam gate**. Walk's early `naturalSceneRenderer.ts` includes +1,217 pre-minification rendered bytes of beauty-shader warm-up implementation. This is not a lazy feature seam, and must be removed or deferred. Root is correcting it; these measured heads and failed attribution remain recorded. Per-module render lengths are not minified gzip contributions and must not be added to infer transfer costs. Site's shared atomic renderer fix is −30 rendered bytes and −11 raw bytes in ThreeStage; its +7 gzip chunk delta is compression/hash context, not source expansion. Other aliases of already-early symbols are listed separately in the audit; they are not new source implementations.

HTML is separate: index raw +3,407 each, gzip +1,245 Walk / +1,244 Site; OLB raw +3,343 and gzip +1,216 each. Finalizer alone contributes +1,900 raw and approximately +571–574 gzip. All early requests still need the independent formal network proof.

## Corrected published build, separate evidence

`builds/r2-final-corrected/{base,walk,site}/audit.json` and `build-attribution-corrected.json` retain the new completed output for Walk `d78064f9f57ed6e060d9782036b4a8b7a7e95451` and Site `b3727b1d20fff6be3ac448dfe8bf11e9261ad500`. Previous evidence above is untouched.

| Build | Early files | Raw bytes | Gzip bytes | Raw delta | Gzip delta |
|---|---:|---:|---:|---:|---:|
| Base52 | 28 | 2,905,199 | 871,303 | 0 | 0 |
| Walk corrected | 28 | 2,906,722 | 871,792 | +1,523 | +489 |
| Site corrected | 28 | 2,907,675 | 872,243 | +2,476 | +940 |

Walk `naturalSceneRenderer.ts` now has no Git source diff from base52 and no rendered-module delta. The isolated plumbing entry/hero/diagnostics stay late. Hash preservation verified 620/613 original non-HTML primary files, and no public source maps exist. The correction removes the identified shader warm-up implementation growth; remaining early additions are the existing World seam adapters and already-early export aliases, listed individually in the JSON. In particular the Walk camera/frame ownership adapter and Site frozen-polygon canvas adapter should be described honestly, rather than calling them only an import statement. Site's atomic renderer source remains −30 rendered bytes; ThreeStage chunk −11 raw / +8 gzip is compression/hash context.

Corrected HTML deltas are separate from the 28 files: Walk index +3,407 raw/+1,242 gzip, OLB +3,343/+1,214; Site index +3,407/+1,246, OLB +3,343/+1,220. Finalizer alone remains +1,900 raw in each document. This run is static proof; the published corrected heads still need their own reserved browser and formal network checks.
