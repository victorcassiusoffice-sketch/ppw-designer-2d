# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-buffer-sizing.spec.ts >> phone >> allocates at final density once, preserves CSS, and resizes only for actual layout/density changes
- Location: tests\e2e\renderer-buffer-sizing.spec.ts:36:3

# Error details

```
Error: apiRequestContext.get: connect ETIMEDOUT 216.198.79.67:443
Call log:
  - → GET https://ppw-designer-2d-git-gpt-olb-fix-round-3-2026-10-27-victor-ppw.vercel.app/api/healthcheck
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br

```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | 
  3   | // A real WebGL regression: intercept the browser's canvas allocations, rather
  4   | // than asserting which helper name appears in ThreeStage's source.
  5   | type Allocation = { axis: 'width' | 'height'; value: number; cssWidth: number; cssHeight: number; at: number };
  6   | type BufferWindow = Window & { __bufferAllocations: Allocation[] };
  7   | test.use({ launchOptions: { args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist'] } });
  8   | const read = (page: Page) => page.getByTestId('wallpaint-3d-gl').evaluate(canvas => {
  9   |   const surface = canvas as HTMLCanvasElement;
  10  |   const rect = surface.getBoundingClientRect();
  11  |   const gl = surface.getContext('webgl2')!;
  12  |   return {
  13  |     width: surface.width, height: surface.height,
  14  |     cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height),
  15  |     css: surface.getAttribute('style'), viewport: Array.from(gl.getParameter(gl.VIEWPORT) as Int32Array),
  16  |     error: gl.getError(), quality: surface.dataset.quality, shading: surface.dataset.shading,
  17  |     writes: (window as BufferWindow).__bufferAllocations,
  18  |   };
  19  | });
  20  | async function assertBuffer(page: Page, ratio: number) {
  21  |   await expect.poll(async () => { const r = await read(page); return [r.width, r.height]; })
  22  |     .toEqual(await page.getByTestId('wallpaint-3d-gl').evaluate((canvas, density) => {
  23  |       const r = canvas.getBoundingClientRect(); return [Math.floor(Math.round(r.width) * density), Math.floor(Math.round(r.height) * density)];
  24  |     }, ratio));
  25  |   const r = await read(page);
  26  |   expect(r.viewport).toEqual([0, 0, r.width, r.height]);
  27  |   expect(r.error).toBe(0);
  28  |   return r;
  29  | }
  30  | 
  31  | for (const device of [
  32  |   { name: 'desktop', viewport: { width: 1280, height: 800 }, scale: 2 },
  33  |   { name: 'phone', viewport: { width: 390, height: 844 }, scale: 3 },
  34  | ]) test.describe(device.name, () => {
  35  |   test.use({ viewport: device.viewport, deviceScaleFactor: device.scale, hasTouch: device.name === 'phone' });
  36  |   test('allocates at final density once, preserves CSS, and resizes only for actual layout/density changes', async ({ page }, info) => {
  37  |     test.setTimeout(120000);
  38  |     const errors: string[] = [], writes: string[] = [];
> 39  |     const health = await page.request.get('/api/healthcheck');
      |                                       ^ Error: apiRequestContext.get: connect ETIMEDOUT 216.198.79.67:443
  40  |     expect(health.ok()).toBe(true);
  41  |     await info.attach('health.json', { body: await health.body(), contentType: 'application/json' });
  42  |     page.on('pageerror', e => errors.push(e.message));
  43  |     await page.route('**/*', route => {
  44  |       if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) {
  45  |         writes.push(route.request().url()); return route.abort();
  46  |       }
  47  |       return route.continue();
  48  |     });
  49  |     await page.addInitScript(() => {
  50  |       localStorage.setItem('ppw_designer_coach_v1', '1');
  51  |       localStorage.setItem('olb-render-quality-v1', JSON.stringify({ state: { choice: 'medium' }, version: 0 }));
  52  |       const records: Allocation[] = (window as BufferWindow).__bufferAllocations = [];
  53  |       for (const axis of ['width', 'height'] as const) {
  54  |         const descriptor = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, axis)!;
  55  |         Object.defineProperty(HTMLCanvasElement.prototype, axis, {
  56  |           ...descriptor,
  57  |           set(this: HTMLCanvasElement, value: number) {
  58  |             if (this.dataset.testid === 'wallpaint-3d-gl') {
  59  |               const rect = this.getBoundingClientRect();
  60  |               records.push({ axis, value, cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height), at: performance.now() });
  61  |             }
  62  |             descriptor.set!.call(this, value);
  63  |           },
  64  |         });
  65  |       }
  66  |     });
  67  |     await page.goto('/demo?view=3d&pitch=1');
  68  |     await page.waitForFunction(() => Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0);
  69  |     const initial = await assertBuffer(page, 1.5);
  70  |     await info.attach('initial-buffer.json', { body: JSON.stringify(initial, null, 2), contentType: 'application/json' });
  71  |     expect(initial.writes.length).toBeGreaterThanOrEqual(2);
  72  |     expect(initial.writes.length % 2).toBe(0);
  73  |     for (let i = 0; i < initial.writes.length; i += 2) {
  74  |       const [width, height] = initial.writes.slice(i, i + 2);
  75  |       expect([width.axis, height.axis]).toEqual(['width', 'height']);
  76  |       expect(width.value).toBe(Math.floor(width.cssWidth * 1.5));
  77  |       expect(height.value).toBe(Math.floor(height.cssHeight * 1.5));
  78  |       if (i > 0) expect([width.value, height.value]).not.toEqual([initial.writes[i - 2].value, initial.writes[i - 1].value]);
  79  |     }
  80  |     await page.getByTestId('house-view-settings').click();
  81  |     const beforeOrbit = (await read(page)).writes.length;
  82  |     await page.getByTestId('wallpaint-3d-rotate-left').click();
  83  |     await page.waitForTimeout(150);
  84  |     expect((await read(page)).writes).toHaveLength(beforeOrbit);
  85  |     for (const [choice, ratio] of [['low', 1], ['high', 2], ['medium', 1.5]] as const) {
  86  |       const before = (await read(page)).writes.length;
  87  |       await page.getByRole('combobox', { name: '3D rendering quality' }).selectOption(choice);
  88  |       const after = await assertBuffer(page, ratio);
  89  |       expect(after.writes).toHaveLength(before + 2);
  90  |       expect(after.css).toBe(initial.css);
  91  |     }
  92  |     const beforeResize = (await read(page)).writes.length;
  93  |     await page.setViewportSize({ width: device.viewport.width - 20, height: device.viewport.height - 30 });
  94  |     const resized = await assertBuffer(page, 1.5);
  95  |     expect(resized.writes.length).toBeGreaterThan(beforeResize);
  96  |     expect(resized.css).toBe(initial.css);
  97  |     await info.attach('final-buffer.json', { body: JSON.stringify(resized, null, 2), contentType: 'application/json' });
  98  |     expect(errors).toEqual([]);
  99  |     expect(writes).toEqual([]);
  100 |   });
  101 | });
  102 | 
```