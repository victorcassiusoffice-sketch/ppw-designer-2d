# Print diagnosis — injected-style experiment, not deployment proof

Source preview remained `0e55d0d934e4241a173f24784a49031859e6a3a8`. This functional experiment overlapped the separately authorized Walk test suite; it makes no timing or performance claim. The browser and all PDF subprocesses closed after the comparison. There were zero attempted writes and zero JavaScript errors.

The initial failure is preserved separately in `../site-print-0e55d0d-20261029/`: both original PDFs and all eight original rendered pages remain untouched.

Actual print-emulated computed styles show the HTML/body and Site ancestors have nonzero heights, static positioning, and no transform, filter, perspective or containment. The fixed footer has a print-emulated rectangle below the 800px viewport, but the exported paginated PDF places it near the page top. **The proposed zero-height containing-block hypothesis is not confirmed.** Treat this as an observed fixed-element pagination mismatch, not a proven underlying browser cause.

Both comparison PDFs were rendered and all eight pages visually inspected:

- `fixed-top.pdf` fails all four page checks. An explicit A4-derived top coordinate still places the disclaimer over terrain/foundation/source content near the top. Retain this failed experiment; it is not the chosen repair.
- `named-margin-box.pdf` passes all four page checks. Native `@bottom-center` puts the complete disclaimer at y793.50–802.50pt on every portrait A4 page. The smallest body-text gap is 17.99mm. All four pages are readable, with no disclaimer overlap or clipping. The same Type 3 glyph/font-bounds warnings are retained; no corresponding missing glyph was visible.

The chosen implementation uses the native named-page margin box with 30mm of reserved bottom margin. `SiteReport` supplies its content from `REPORT_BANNER`, and the ordinary final paragraph remains in document flow for screen and fallback printing. This last flow-preserving variant differs from the diagnostic experiment, which hid the final paragraph: the published implementation must still be exported and inspected at both viewports before the final print gate passes.
