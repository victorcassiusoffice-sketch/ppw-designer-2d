# Round 2 first print attempt — FAILED

Exact preview head: `0e55d0d934e4241a173f24784a49031859e6a3a8`. The untouched harness, raw log, both PDFs and all eight PNG pages are retained in this directory and its adjacent `.log` file.

All four laptop and all four phone pages were opened and visually inspected. The PDFs have the complete disclaimer text on every page, but the repeated fixed element appears near the top instead of the reserved bottom margin. It visibly obscures terrain metric labels on page 2, the foundation label on page 3 and the unavailable-data notice on page 4. Page 1 retains its initial banner. This is a real overlap failure, not a text-extraction false alarm. The print gate remains failed.

The independent per-page PDF oracle also fails all eight pages because no complete disclaimer occupies the reserved footer. Portrait A4 dimensions are correct. Existing Type 3 glyph/font-bounding-box warnings are preserved in `print-check.json`; they do not explain the visible overlay.

Separate screen/network results pass for both viewports: original screen styles restored, two ordinary screen banners, no horizontal overflow, print-button class lifecycle correct, inactive page name `auto`, zero provider requests, zero attempted/blocked writes, and zero JavaScript, console or HTTP errors. Do not infer a print pass from those results.

Browser and PDF extraction/rendering processes completed and closed before this review was saved. Follow-up experiments must use a fresh directory; none of these failed artifacts may be overwritten.
