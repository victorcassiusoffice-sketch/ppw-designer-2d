# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-buffer-sizing.spec.ts >> desktop >> allocates at final density once, preserves CSS, and resizes only for actual layout/density changes
- Location: tests\e2e\renderer-buffer-sizing.spec.ts:36:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1750
Received: 450
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - img [ref=e8]
          - button [ref=e9] [cursor=pointer]:
            - img [ref=e10]
            - generic [ref=e12]:
              - generic [ref=e13]: Demo
              - generic [ref=e14]: · Living room
          - generic [ref=e16]: Demo · no orders
        - generic [ref=e17]:
          - group [ref=e18]:
            - button [pressed] [ref=e19] [cursor=pointer]:
              - img [ref=e20]
              - generic [ref=e23]: Build
            - button [ref=e24] [cursor=pointer]:
              - img [ref=e25]
              - generic [ref=e28]: Finish
            - button [ref=e29] [cursor=pointer]:
              - img [ref=e30]
              - generic [ref=e32]: Arrange
          - group [ref=e33]:
            - button [pressed] [ref=e34] [cursor=pointer]:
              - img [ref=e35]
              - generic [ref=e38]: Select
            - button [ref=e39] [cursor=pointer]:
              - img [ref=e40]
              - generic [ref=e42]: Walls
            - button [ref=e43] [cursor=pointer]:
              - img [ref=e44]
              - generic [ref=e47]: Openings
          - button [ref=e48] [cursor=pointer]:
            - img [ref=e49]
            - generic [ref=e52]: Garden
          - group [ref=e53]:
            - button [pressed] [ref=e54] [cursor=pointer]:
              - img [ref=e55]
              - generic [ref=e57]: Room
            - button [ref=e58] [cursor=pointer]:
              - img [ref=e59]
              - generic [ref=e61]: Custom
        - generic [ref=e63]:
          - link [ref=e64] [cursor=pointer]:
            - /url: /demo
            - img [ref=e65]
          - button [ref=e68] [cursor=pointer]:
            - img [ref=e69]
      - generic [ref=e70]:
        - generic [ref=e71]:
          - button [pressed] [ref=e72] [cursor=pointer]:
            - img [ref=e73]
            - generic [ref=e75]: 2D Plan
          - button [ref=e76] [cursor=pointer]:
            - img [ref=e77]
            - generic [ref=e80]: 3D House
        - button [ref=e82] [cursor=pointer]:
          - img [ref=e83]
          - generic [ref=e85]: Layers
        - button [ref=e86] [cursor=pointer]:
          - img [ref=e87]
          - generic [ref=e89]: Site & tools
      - group [ref=e90]:
        - generic [ref=e91]:
          - img [ref=e92]
          - generic [ref=e94]: Floors
          - combobox [ref=e95]
        - button [ref=e96] [cursor=pointer]:
          - img [ref=e97]
          - generic [ref=e99]: City
        - button [ref=e100] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]: Project hub
        - group [ref=e104]:
          - generic [ref=e105] [cursor=pointer]:
            - img [ref=e106]
            - generic [ref=e110]: EN
        - button [ref=e111] [cursor=pointer]:
          - img [ref=e112]
          - generic [ref=e115]: Materials
        - button [disabled] [ref=e116]:
          - img [ref=e117]
          - generic [ref=e119]: Undo
    - main [ref=e120]:
      - generic [ref=e125]:
        - button [ref=e126] [cursor=pointer]:
          - text: 27 m²
          - generic [ref=e127]: +
        - generic [ref=e128]:
          - generic [ref=e129]:
            - button [ref=e130] [cursor=pointer]:
              - img [ref=e131]
            - button [ref=e132] [cursor=pointer]:
              - img [ref=e133]
            - button [ref=e135] [cursor=pointer]:
              - img [ref=e136]
              - generic [ref=e138]: Fit
            - button [ref=e139] [cursor=pointer]:
              - img [ref=e140]
              - generic [ref=e142]: Share
            - button [ref=e143] [cursor=pointer]:
              - img [ref=e144]
              - generic [ref=e147]: Capture
          - generic:
            - generic:
              - text: 27.0 m² ·
              - generic: 39%
              - text: · 0.5 m
            - generic: "36"
          - button [ref=e148] [cursor=pointer]:
            - meter [ref=e150]
            - generic [ref=e151]: ☀ 0 Wh · ⚡ 26.5 kWh
            - generic [ref=e152]: −26.5 kWh
  - region "3D Mode" [ref=e154]:
    - generic [ref=e155]:
      - generic [ref=e156]:
        - generic "One Live Build" [ref=e157]:
          - img [ref=e159]
          - generic [ref=e162]:
            - strong [ref=e163]: Demo
            - generic "Demo only — orders, payments, quote requests and email submissions are disabled." [ref=e164]: Preview · no orders
        - generic "Design view" [ref=e165]:
          - button "2D Plan" [ref=e166] [cursor=pointer]:
            - img [ref=e167]
            - generic [ref=e169]: 2D Plan
          - button "3D House" [pressed] [ref=e170] [cursor=pointer]:
            - img [ref=e171]
            - generic [ref=e174]: 3D House
        - generic [ref=e175]:
          - button "Project hub" [ref=e176] [cursor=pointer]:
            - img [ref=e177]
            - generic [ref=e180]: Project hub
          - group [ref=e181]:
            - generic "EN — Preferences" [ref=e182] [cursor=pointer]:
              - img [ref=e183]
              - generic [ref=e187]: EN
            - option "English" [selected]
            - option "Français"
            - option "简体中文"
            - option "Español"
            - option "Ivory & sage" [selected]
            - option "Midnight & ocean"
            - option "Slate & sand"
            - option "Warm studio" [selected]
            - option "Sculpted gallery"
            - option "Midnight blueprint"
          - button "AI design" [ref=e188] [cursor=pointer]:
            - generic [ref=e189]: ✧
            - text: AI
          - button "Import plan" [ref=e190] [cursor=pointer]:
            - img [ref=e191]
            - generic [ref=e193]: Import plan
          - button "Clear page" [ref=e195] [cursor=pointer]:
            - img [ref=e196]
            - generic [ref=e198]: Clear
          - button "Undo" [disabled] [ref=e199]:
            - img [ref=e200]
          - button "Redo" [disabled] [ref=e202]:
            - img [ref=e203]
          - button "Products in this design" [ref=e205] [cursor=pointer]:
            - img [ref=e206]
          - button "Save" [ref=e209] [cursor=pointer]
          - button "Project tools" [ref=e210] [cursor=pointer]:
            - img [ref=e211]
      - generic [ref=e212]:
        - navigation "House design tools" [ref=e213]:
          - button "Foundation" [ref=e214] [cursor=pointer]:
            - generic [ref=e215]: ▱
            - text: Foundation
          - button "City Build" [ref=e216] [cursor=pointer]:
            - img [ref=e217]
            - generic [ref=e219]: City
          - button "Build" [pressed] [ref=e220] [cursor=pointer]:
            - img [ref=e221]
            - generic [ref=e224]: Build
          - button "Furnish" [ref=e225] [cursor=pointer]:
            - img [ref=e226]
            - generic [ref=e229]: Furnish
          - button "Paint" [ref=e230] [cursor=pointer]:
            - img [ref=e231]
            - generic [ref=e234]: Paint
          - button "Surfaces" [ref=e235] [cursor=pointer]:
            - img [ref=e236]
            - generic [ref=e238]: Surfaces
          - button "Garden" [ref=e239] [cursor=pointer]:
            - img [ref=e240]
            - generic [ref=e243]: Garden
          - button "Materials" [ref=e244] [cursor=pointer]:
            - img [ref=e245]
            - generic [ref=e248]: Materials
          - button "Solar" [ref=e249] [cursor=pointer]:
            - img [ref=e250]
            - generic [ref=e252]: Solar
        - generic [ref=e253]:
          - generic [ref=e254]:
            - generic [ref=e255]:
              - strong [ref=e257]: Ground
              - combobox "View floor" [ref=e258]:
                - option "Ground floor" [selected]
                - option "Roof"
                - option "＋ Add floor"
                - option "Foundation"
              - button "Plumbing & Electric" [ref=e259] [cursor=pointer]:
                - img [ref=e260]
              - generic [ref=e262]: 91.0 m²
            - generic [ref=e263]:
              - button "Remove" [ref=e264] [cursor=pointer]:
                - img [ref=e265]
                - generic [ref=e267]: Remove
              - button "Select" [pressed] [ref=e268] [cursor=pointer]:
                - img [ref=e269]
                - generic [ref=e272]: Select
              - button "Walls" [ref=e273] [cursor=pointer]:
                - img [ref=e274]
                - generic [ref=e276]: Walls
              - button "Draw room" [ref=e277] [cursor=pointer]:
                - img [ref=e278]
                - generic [ref=e280]: Draw room
              - group "Doors windows and stairs" [ref=e281]:
                - button "Door" [ref=e282] [cursor=pointer]:
                  - img [ref=e283]
                  - generic [ref=e286]: Door
                - button "Window" [ref=e287] [cursor=pointer]:
                  - img [ref=e288]
                  - generic [ref=e291]: Window
                - button "Stairs" [disabled] [ref=e292]:
                  - img [ref=e293]
                  - generic [ref=e295]: Stairs
              - button "Details" [ref=e296] [cursor=pointer]
          - generic [ref=e297]:
            - img "Room view in 3D — 61 parts. Drag to orbit; tap an item to select it, drag it to move it." [ref=e301]
            - group "Camera navigation" [ref=e303]:
              - button "Layers" [ref=e305] [cursor=pointer]:
                - img [ref=e306]
                - generic [ref=e308]: Layers
              - button "House build guide" [ref=e309] [cursor=pointer]:
                - img [ref=e310]
              - button "Move view" [ref=e312] [cursor=pointer]:
                - img [ref=e313]
                - generic [ref=e315]: Move view
              - button "Zoom in" [ref=e316] [cursor=pointer]:
                - img [ref=e317]
              - button "Zoom out" [ref=e319] [cursor=pointer]:
                - img [ref=e320]
              - button "Fit" [ref=e321] [cursor=pointer]:
                - img [ref=e322]
              - button "View" [ref=e324] [cursor=pointer]:
                - img [ref=e325]
                - generic [ref=e327]: View
            - paragraph [ref=e328]: Drag to orbit · two fingers or Shift-drag to pan · pinch to zoom · drag items to move
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | 
  3   | // A real WebGL regression: intercept the browser's canvas allocations, rather
  4   | // than asserting which helper name appears in ThreeStage's source.
  5   | type Allocation = { axis: 'width' | 'height'; value: number; cssWidth: number; cssHeight: number; at: number };
  6   | type BufferWindow = Window & { __bufferAllocations: Allocation[] };
  7   | test.use({ launchOptions: { args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', '--host-resolver-rules=MAP *.vercel.app 216.198.79.3'] } });
  8   | const read = (page: Page) => page.getByTestId('wallpaint-3d-gl').evaluate(canvas => {
  9   |   const surface = canvas as HTMLCanvasElement;
  10  |   const rect = surface.getBoundingClientRect();
  11  |   const gl = surface.getContext('webgl2')!;
  12  |   return {
  13  |     width: surface.width, height: surface.height,
  14  |     cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height),
  15  |     css: surface.getAttribute('style'), viewport: Array.from(gl.getParameter(gl.VIEWPORT) as Int32Array),
  16  |     error: gl.getError(), quality: surface.dataset.quality, shading: surface.dataset.shading,
  17  |     writes: (window as BufferWindow).__bufferAllocations,
  18  |   };
  19  | });
  20  | async function assertBuffer(page: Page, ratio: number) {
  21  |   await expect.poll(async () => {
  22  |     const r = await read(page);
  23  |     return r.width === Math.floor(r.cssWidth * ratio) && r.height === Math.floor(r.cssHeight * ratio);
  24  |   }).toBe(true);
  25  |   const r = await read(page);
  26  |   expect(r.viewport).toEqual([0, 0, r.width, r.height]);
  27  |   expect(r.error).toBe(0);
  28  |   return r;
  29  | }
  30  | 
  31  | for (const device of [
  32  |   { name: 'desktop', viewport: { width: 1280, height: 800 }, scale: 2 },
  33  |   { name: 'phone', viewport: { width: 390, height: 844 }, scale: 3 },
  34  | ]) test.describe(device.name, () => {
  35  |   test.use({ viewport: device.viewport, deviceScaleFactor: device.scale, hasTouch: device.name === 'phone' });
  36  |   test('allocates at final density once, preserves CSS, and resizes only for actual layout/density changes', async ({ page }, info) => {
  37  |     test.setTimeout(120000);
  38  |     const errors: string[] = [], writes: string[] = [];
  39  |     // Browser navigation uses the same pinned host as the application. The
  40  |     // separate Node API request client does not inherit Chromium's resolver.
  41  |     const health = await page.goto('/api/healthcheck');
  42  |     expect(health?.ok()).toBe(true);
  43  |     await info.attach('health.json', { body: await page.locator('body').innerText(), contentType: 'application/json' });
  44  |     page.on('pageerror', e => errors.push(e.message));
  45  |     await page.route('**/*', route => {
  46  |       if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) {
  47  |         writes.push(route.request().url()); return route.abort();
  48  |       }
  49  |       return route.continue();
  50  |     });
  51  |     await page.addInitScript(() => {
  52  |       localStorage.setItem('ppw_designer_coach_v1', '1');
  53  |       localStorage.setItem('olb-render-quality-v1', JSON.stringify({ state: { choice: 'medium' }, version: 0 }));
  54  |       const records: Allocation[] = (window as BufferWindow).__bufferAllocations = [];
  55  |       for (const axis of ['width', 'height'] as const) {
  56  |         const descriptor = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, axis)!;
  57  |         Object.defineProperty(HTMLCanvasElement.prototype, axis, {
  58  |           ...descriptor,
  59  |           set(this: HTMLCanvasElement, value: number) {
  60  |             if (this.dataset.testid === 'wallpaint-3d-gl') {
  61  |               const rect = this.getBoundingClientRect();
  62  |               records.push({ axis, value, cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height), at: performance.now() });
  63  |             }
  64  |             descriptor.set!.call(this, value);
  65  |           },
  66  |         });
  67  |       }
  68  |     });
  69  |     await page.goto('/demo?view=3d&pitch=1');
  70  |     await page.waitForFunction(() => Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0);
  71  |     const initial = await assertBuffer(page, 1.5);
  72  |     await info.attach('initial-buffer.json', { body: JSON.stringify(initial, null, 2), contentType: 'application/json' });
  73  |     expect(initial.writes.length).toBeGreaterThanOrEqual(2);
  74  |     expect(initial.writes.length % 2).toBe(0);
  75  |     for (let i = 0; i < initial.writes.length; i += 2) {
  76  |       const [width, height] = initial.writes.slice(i, i + 2);
  77  |       expect([width.axis, height.axis]).toEqual(['width', 'height']);
> 78  |       expect(width.value).toBe(Math.floor(width.cssWidth * 1.5));
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  79  |       expect(height.value).toBe(Math.floor(height.cssHeight * 1.5));
  80  |       if (i > 0) expect([width.value, height.value]).not.toEqual([initial.writes[i - 2].value, initial.writes[i - 1].value]);
  81  |     }
  82  |     await page.getByTestId('house-view-settings').click();
  83  |     const beforeOrbit = (await read(page)).writes.length;
  84  |     await page.getByTestId('wallpaint-3d-rotate-left').click();
  85  |     await page.waitForTimeout(150);
  86  |     expect((await read(page)).writes).toHaveLength(beforeOrbit);
  87  |     for (const [choice, ratio] of [['low', 1], ['high', 2], ['medium', 1.5]] as const) {
  88  |       const before = (await read(page)).writes.length;
  89  |       await page.getByRole('combobox', { name: '3D rendering quality' }).selectOption(choice);
  90  |       const after = await assertBuffer(page, ratio);
  91  |       expect(after.writes).toHaveLength(before + 2);
  92  |       expect(after.css).toBe(initial.css);
  93  |     }
  94  |     const beforeResize = (await read(page)).writes.length;
  95  |     await page.setViewportSize({ width: device.viewport.width - 20, height: device.viewport.height - 30 });
  96  |     await expect.poll(async () => (await read(page)).writes.length).toBeGreaterThan(beforeResize);
  97  |     const resized = await assertBuffer(page, 1.5);
  98  |     expect(resized.writes.length).toBeGreaterThan(beforeResize);
  99  |     expect(resized.css).toBe(initial.css);
  100 |     await info.attach('final-buffer.json', { body: JSON.stringify(resized, null, 2), contentType: 'application/json' });
  101 |     expect(errors).toEqual([]);
  102 |     expect(writes).toEqual([]);
  103 |   });
  104 | });
  105 | 
```