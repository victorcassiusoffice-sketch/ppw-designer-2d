# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-buffer-sizing.spec.ts >> phone >> allocates at final density once, preserves CSS, and resizes only for actual layout/density changes
- Location: tests\e2e\renderer-buffer-sizing.spec.ts:42:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e7] [cursor=pointer]:
          - img [ref=e8]
        - generic [ref=e10]:
          - group [ref=e11]:
            - button [pressed] [ref=e12] [cursor=pointer]:
              - img [ref=e13]
              - generic [ref=e16]: Build
            - button [ref=e17] [cursor=pointer]:
              - img [ref=e18]
              - generic [ref=e21]: Finish
            - button [ref=e22] [cursor=pointer]:
              - img [ref=e23]
              - generic [ref=e25]: Arrange
          - button [ref=e26] [cursor=pointer]:
            - img [ref=e27]
            - generic [ref=e30]: Select
        - button [ref=e31] [cursor=pointer]:
          - img [ref=e32]
      - generic [ref=e34]:
        - generic [ref=e35]:
          - button [pressed] [ref=e36] [cursor=pointer]:
            - img [ref=e37]
            - generic [ref=e39]: 2D
          - button [ref=e40] [cursor=pointer]:
            - img [ref=e41]
            - generic [ref=e44]: 3D
        - button [ref=e46] [cursor=pointer]:
          - img [ref=e47]
        - button [ref=e49] [cursor=pointer]:
          - img [ref=e50]
      - group [ref=e52]:
        - combobox [ref=e54]
        - button [ref=e55] [cursor=pointer]:
          - img [ref=e56]
          - generic [ref=e58]: City
        - button [ref=e59] [cursor=pointer]:
          - img [ref=e60]
        - group [ref=e62]:
          - generic [ref=e63] [cursor=pointer]:
            - img [ref=e64]
            - generic [ref=e68]: EN
        - button [ref=e69] [cursor=pointer]:
          - img [ref=e70]
          - generic [ref=e73]: Materials
        - button [disabled] [ref=e74]:
          - img [ref=e75]
          - generic [ref=e77]: Undo
    - main [ref=e78]:
      - button [ref=e84] [cursor=pointer]:
        - text: 27 m²
        - generic [ref=e85]: +
  - region "3D Mode" [ref=e87]:
    - generic [ref=e88]:
      - generic [ref=e89]:
        - generic "Design view" [ref=e90]:
          - button "2D Plan" [ref=e91] [cursor=pointer]:
            - generic [ref=e92]: 2D
          - button "3D House" [pressed] [ref=e93] [cursor=pointer]:
            - generic [ref=e94]: 3D
        - generic [ref=e95]:
          - button "Project hub" [ref=e96] [cursor=pointer]:
            - img [ref=e97]
          - group [ref=e100]:
            - generic "EN — Preferences" [ref=e101] [cursor=pointer]:
              - img [ref=e102]
            - option "English" [selected]
            - option "Français"
            - option "简体中文"
            - option "Español"
            - option "Ivory & sage" [selected]
            - option "Midnight & ocean"
            - option "Slate & sand"
            - option "Warm studio" [selected]
            - option "Sculpted gallery"
            - option "Midnight blueprint"
          - button "AI design" [ref=e106] [cursor=pointer]:
            - generic [ref=e107]: ✧
            - text: AI
          - button "Import plan" [ref=e108] [cursor=pointer]:
            - img [ref=e109]
            - generic [ref=e111]: Import plan
          - button "Clear page" [ref=e113] [cursor=pointer]:
            - img [ref=e114]
            - generic [ref=e116]: Clear
          - button "Products in this design" [ref=e117] [cursor=pointer]:
            - img [ref=e118]
          - button "Project tools" [ref=e121] [cursor=pointer]:
            - img [ref=e122]
      - generic [ref=e123]:
        - navigation "House design tools" [ref=e124]:
          - button "Foundation" [ref=e125] [cursor=pointer]:
            - generic [ref=e126]: ▱
            - text: Foundation
          - button "City Build" [ref=e127] [cursor=pointer]:
            - img [ref=e128]
            - generic [ref=e130]: City
          - button "Build" [pressed] [ref=e131] [cursor=pointer]:
            - img [ref=e132]
            - generic [ref=e135]: Build
          - button "Furnish" [ref=e136] [cursor=pointer]:
            - img [ref=e137]
            - generic [ref=e140]: Furnish
          - button "Paint" [ref=e141] [cursor=pointer]:
            - img [ref=e142]
            - generic [ref=e145]: Paint
          - button "Surfaces" [ref=e146] [cursor=pointer]:
            - img [ref=e147]
            - generic [ref=e149]: Surfaces
          - button "Garden" [ref=e150] [cursor=pointer]:
            - img [ref=e151]
            - generic [ref=e154]: Garden
          - button "Materials" [ref=e155] [cursor=pointer]:
            - img [ref=e156]
            - generic [ref=e159]: Materials
          - button "Solar" [ref=e160] [cursor=pointer]:
            - img [ref=e161]
            - generic [ref=e163]: Solar
        - generic [ref=e164]:
          - generic [ref=e165]:
            - generic [ref=e166]:
              - strong [ref=e167]: Ground
              - combobox "View floor" [ref=e168]:
                - option "Ground floor" [selected]
                - option "Roof"
                - option "＋ Add floor"
                - option "Foundation"
              - button "Plumbing & Electric" [ref=e169] [cursor=pointer]:
                - img [ref=e170]
            - generic [ref=e172]:
              - button "Select and move objects" [pressed] [ref=e173] [cursor=pointer]:
                - img [ref=e174]
              - button "Build tools" [ref=e177] [cursor=pointer]:
                - img [ref=e178]
          - generic [ref=e181]:
            - generic [ref=e182]:
              - button "Open Walk mode" [ref=e185] [cursor=pointer]: Walk
              - img "Room view in 3D — 61 parts. Drag to orbit; tap an item to select it, drag it to move it." [ref=e186]
            - generic [ref=e187]:
              - generic [ref=e188]:
                - generic [ref=e189]:
                  - strong [ref=e190]: View & dimensions
                  - button "Close view settings" [ref=e191] [cursor=pointer]: Close ×
                - generic [ref=e192]:
                  - generic [ref=e193]:
                    - text: Camera
                    - combobox "Camera view" [ref=e194]:
                      - option "Custom view" [disabled] [selected]
                      - option "Perspective"
                      - option "Above · perspective"
                      - option "Front · perspective"
                      - option "Axonometric"
                      - option "Top · orthographic"
                      - option "North elevation"
                      - option "East elevation"
                      - option "South elevation"
                      - option "West elevation"
                  - group "Orbit camera" [ref=e195]:
                    - generic [ref=e196]: Orbit camera
                    - button "Orbit camera left" [active] [ref=e197] [cursor=pointer]:
                      - img [ref=e198]
                    - button "Orbit camera right" [ref=e200] [cursor=pointer]:
                      - img [ref=e201]
                  - generic [ref=e203]:
                    - text: Lighting
                    - combobox "Lighting" [ref=e204]:
                      - option "Natural light" [selected]
                      - option "Colour check"
                  - generic [ref=e205]:
                    - generic [ref=e206]: 3D quality
                    - combobox "3D rendering quality" [ref=e207]:
                      - option "Auto · device"
                      - option "Low · fastest"
                      - option "Medium · balanced" [selected]
                      - option "High · detail"
                  - group "Wall view" [ref=e208]:
                    - button "Walls up" [ref=e209] [cursor=pointer]
                    - button "Cutaway" [pressed] [ref=e210] [cursor=pointer]
                    - button "Walls down" [ref=e211] [cursor=pointer]
                  - generic [ref=e212]:
                    - generic [ref=e213]: Wall height
                    - generic [ref=e214]:
                      - button "Lower wall height" [ref=e215] [cursor=pointer]: −
                      - generic "Wall height" [ref=e216]: 2.7 m
                      - button "Raise wall height" [ref=e217] [cursor=pointer]: +
                  - group "Sun" [ref=e218]:
                    - button "☀ Daylight" [ref=e219] [cursor=pointer]
                  - generic [ref=e220]: Natural light is an appearance preview. Colour check uses neutral lighting to compare finishes.
              - group "Camera navigation" [ref=e221]:
                - button "Layers" [ref=e223] [cursor=pointer]:
                  - img [ref=e224]
                - button "House build guide" [ref=e226] [cursor=pointer]:
                  - img [ref=e227]
                - button "Move view" [ref=e229] [cursor=pointer]:
                  - img [ref=e230]
                - button "Zoom in" [ref=e232] [cursor=pointer]:
                  - img [ref=e233]
                - button "Zoom out" [ref=e235] [cursor=pointer]:
                  - img [ref=e236]
                - button "Fit" [ref=e237] [cursor=pointer]:
                  - img [ref=e238]
                - button "View" [expanded] [ref=e240] [cursor=pointer]:
                  - img [ref=e241]
                  - generic [ref=e243]: View
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | 
  3   | // A real WebGL regression: intercept the browser's canvas allocations, rather
  4   | // than asserting which helper name appears in ThreeStage's source.
  5   | type Allocation = { axis: 'width' | 'height'; value: number; cssWidth: number; cssHeight: number; at: number };
  6   | type BufferWindow = Window & { __bufferAllocations: Allocation[] };
  7   | test.use({ launchOptions: { args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', '--host-resolver-rules=MAP *.vercel.app 216.198.79.3'] } });
  8   | const read = (page: Page) => page.getByTestId('wallpaint-3d-gl').evaluate(canvas => {
  9   |   const surface = canvas as HTMLCanvasElement;
  10  |   const rect = surface.getBoundingClientRect();
  11  |   const gl = surface.getContext('webgl2')!;
  12  |   return {
  13  |     width: surface.width, height: surface.height,
  14  |     cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height),
  15  |     css: surface.getAttribute('style'), viewport: Array.from(gl.getParameter(gl.VIEWPORT) as Int32Array),
  16  |     error: gl.getError(), quality: surface.dataset.quality, shading: surface.dataset.shading,
  17  |     writes: (window as BufferWindow).__bufferAllocations,
  18  |   };
  19  | });
  20  | async function assertBuffer(page: Page, ratio: number) {
  21  |   await expect.poll(async () => {
  22  |     const r = await read(page);
  23  |     return r.width === Math.floor(r.cssWidth * ratio) && r.height === Math.floor(r.cssHeight * ratio);
  24  |   }).toBe(true);
  25  |   // setViewport briefly rounds fractional physical pixels; the renderer's
  26  |   // completed render restores the drawing-buffer viewport with floor().
  27  |   await expect.poll(async () => {
  28  |     const r = await read(page);
  29  |     return JSON.stringify(r.viewport) === JSON.stringify([0, 0, r.width, r.height]);
> 30  |   }).toBe(true);
      |      ^ Error: expect(received).toBe(expected) // Object.is equality
  31  |   const r = await read(page);
  32  |   expect(r.viewport).toEqual([0, 0, r.width, r.height]);
  33  |   expect(r.error).toBe(0);
  34  |   return r;
  35  | }
  36  | 
  37  | for (const device of [
  38  |   { name: 'desktop', viewport: { width: 1280, height: 800 }, scale: 2 },
  39  |   { name: 'phone', viewport: { width: 390, height: 844 }, scale: 3 },
  40  | ]) test.describe(device.name, () => {
  41  |   test.use({ viewport: device.viewport, deviceScaleFactor: device.scale, hasTouch: device.name === 'phone' });
  42  |   test('allocates at final density once, preserves CSS, and resizes only for actual layout/density changes', async ({ page }, info) => {
  43  |     test.setTimeout(120000);
  44  |     const errors: string[] = [], writes: string[] = [];
  45  |     // Browser navigation uses the same pinned host as the application. The
  46  |     // separate Node API request client does not inherit Chromium's resolver.
  47  |     const health = await page.goto('/api/healthcheck');
  48  |     expect(health?.ok()).toBe(true);
  49  |     await info.attach('health.json', { body: await page.locator('body').innerText(), contentType: 'application/json' });
  50  |     page.on('pageerror', e => errors.push(e.message));
  51  |     await page.route('**/*', route => {
  52  |       if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) {
  53  |         writes.push(route.request().url()); return route.abort();
  54  |       }
  55  |       return route.continue();
  56  |     });
  57  |     await page.addInitScript(() => {
  58  |       localStorage.setItem('ppw_designer_coach_v1', '1');
  59  |       localStorage.setItem('olb-render-quality-v1', JSON.stringify({ state: { choice: 'medium' }, version: 0 }));
  60  |       const records: Allocation[] = (window as BufferWindow).__bufferAllocations = [];
  61  |       for (const axis of ['width', 'height'] as const) {
  62  |         const descriptor = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, axis)!;
  63  |         Object.defineProperty(HTMLCanvasElement.prototype, axis, {
  64  |           ...descriptor,
  65  |           set(this: HTMLCanvasElement, value: number) {
  66  |             if (this.dataset.testid === 'wallpaint-3d-gl') {
  67  |               const rect = this.getBoundingClientRect();
  68  |               records.push({ axis, value, cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height), at: performance.now() });
  69  |             }
  70  |             descriptor.set!.call(this, value);
  71  |           },
  72  |         });
  73  |       }
  74  |     });
  75  |     await page.goto('/demo?view=3d&pitch=1');
  76  |     await page.waitForFunction(() => Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0);
  77  |     const initial = await assertBuffer(page, 1.5);
  78  |     await info.attach('initial-buffer.json', { body: JSON.stringify(initial, null, 2), contentType: 'application/json' });
  79  |     expect(initial.writes.length).toBeGreaterThanOrEqual(2);
  80  |     expect(initial.writes.length % 2).toBe(0);
  81  |     for (let i = 0; i < initial.writes.length; i += 2) {
  82  |       const [width, height] = initial.writes.slice(i, i + 2);
  83  |       expect([width.axis, height.axis]).toEqual(['width', 'height']);
  84  |       expect(width.value).toBe(Math.floor(width.cssWidth * 1.5));
  85  |       expect(height.value).toBe(Math.floor(height.cssHeight * 1.5));
  86  |       if (i > 0) expect([width.value, height.value]).not.toEqual([initial.writes[i - 2].value, initial.writes[i - 1].value]);
  87  |     }
  88  |     await page.getByTestId('house-view-settings').click();
  89  |     const beforeOrbit = (await read(page)).writes.length;
  90  |     await page.getByTestId('wallpaint-3d-rotate-left').click();
  91  |     await page.waitForTimeout(150);
  92  |     expect((await read(page)).writes).toHaveLength(beforeOrbit);
  93  |     for (const [choice, ratio] of [['low', 1], ['high', 2], ['medium', 1.5]] as const) {
  94  |       const before = (await read(page)).writes.length;
  95  |       await page.getByRole('combobox', { name: '3D rendering quality' }).selectOption(choice);
  96  |       const after = await assertBuffer(page, ratio);
  97  |       expect(after.writes).toHaveLength(before + 2);
  98  |       expect(after.css).toBe(initial.css);
  99  |     }
  100 |     const beforeResize = (await read(page)).writes.length;
  101 |     await page.setViewportSize({ width: device.viewport.width - 20, height: device.viewport.height - 30 });
  102 |     await expect.poll(async () => (await read(page)).writes.length).toBeGreaterThan(beforeResize);
  103 |     const resized = await assertBuffer(page, 1.5);
  104 |     expect(resized.writes.length).toBeGreaterThan(beforeResize);
  105 |     expect(resized.css).toBe(initial.css);
  106 |     await info.attach('final-buffer.json', { body: JSON.stringify(resized, null, 2), contentType: 'application/json' });
  107 |     await info.attach('blocked-writes.json', { body: JSON.stringify(writes, null, 2), contentType: 'application/json' });
  108 |     expect(errors).toEqual([]);
  109 |     // The hosting provider can inject its preview toolbar. Its automatic login
  110 |     // validation is blocked like every write and retained above, never sent.
  111 |     expect(writes.filter(value => {
  112 |       const url = new URL(value);
  113 |       return !(url.origin === 'https://vercel.live' && url.pathname === '/login/validate' && url.searchParams.get('hostname') === new URL(page.url()).hostname);
  114 |     })).toEqual([]);
  115 |   });
  116 | });
  117 | 
```