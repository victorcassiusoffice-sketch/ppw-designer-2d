# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-buffer-sizing.spec.ts >> desktop >> allocates at final density once, preserves CSS, and resizes only for actual layout/density changes
- Location: tests\e2e\renderer-buffer-sizing.spec.ts:36:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
    0,
    0,
-   1720,
+   1721,
    582,
  ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - img [ref=e8]
          - button [ref=e9] [cursor=pointer]:
            - img [ref=e10]
            - generic [ref=e12]:
              - text: Living room
              - generic [ref=e13]: · 5
          - generic [ref=e15]: Demo · no orders
        - generic [ref=e16]:
          - group [ref=e17]:
            - button [pressed] [ref=e18] [cursor=pointer]:
              - img [ref=e19]
              - generic [ref=e22]: Build
            - button [ref=e23] [cursor=pointer]:
              - img [ref=e24]
              - generic [ref=e27]: Finish
            - button [ref=e28] [cursor=pointer]:
              - img [ref=e29]
              - generic [ref=e31]: Arrange
          - group [ref=e32]:
            - button [pressed] [ref=e33] [cursor=pointer]:
              - img [ref=e34]
              - generic [ref=e37]: Select
            - button [ref=e38] [cursor=pointer]:
              - img [ref=e39]
              - generic [ref=e41]: Walls
            - button [ref=e42] [cursor=pointer]:
              - img [ref=e43]
              - generic [ref=e46]: Openings
          - button [ref=e47] [cursor=pointer]:
            - img [ref=e48]
            - generic [ref=e51]: Garden
          - group [ref=e52]:
            - button [pressed] [ref=e53] [cursor=pointer]:
              - img [ref=e54]
              - generic [ref=e56]: Room
            - button [ref=e57] [cursor=pointer]:
              - img [ref=e58]
              - generic [ref=e60]: Custom
        - generic [ref=e62]:
          - link [ref=e63] [cursor=pointer]:
            - /url: /demo
            - img [ref=e64]
          - button [ref=e67] [cursor=pointer]:
            - img [ref=e68]
      - generic [ref=e69]:
        - generic [ref=e70]:
          - button [pressed] [ref=e71] [cursor=pointer]:
            - img [ref=e72]
            - generic [ref=e74]: 2D Plan
          - button [ref=e75] [cursor=pointer]:
            - img [ref=e76]
            - generic [ref=e79]: 3D House
        - button [ref=e81] [cursor=pointer]:
          - img [ref=e82]
          - generic [ref=e84]: Layers
        - button [ref=e85] [cursor=pointer]:
          - img [ref=e86]
          - generic [ref=e88]: Site & tools
      - group [ref=e89]:
        - generic [ref=e90]:
          - img [ref=e91]
          - generic [ref=e93]: Floors
          - combobox [ref=e94]
        - button [ref=e95] [cursor=pointer]:
          - img [ref=e96]
          - generic [ref=e98]: City
        - button [ref=e99] [cursor=pointer]:
          - img [ref=e100]
          - generic [ref=e102]: Project hub
        - group [ref=e103]:
          - generic [ref=e104] [cursor=pointer]:
            - img [ref=e105]
            - generic [ref=e109]: EN
        - button [ref=e110] [cursor=pointer]:
          - img [ref=e111]
          - generic [ref=e114]: Materials
        - button [disabled] [ref=e115]:
          - img [ref=e116]
          - generic [ref=e118]: Undo
    - main [ref=e119]:
      - generic [ref=e124]:
        - button [ref=e125] [cursor=pointer]:
          - text: 27 m²
          - generic [ref=e126]: +
        - generic [ref=e127]:
          - generic [ref=e128]:
            - button [ref=e129] [cursor=pointer]:
              - img [ref=e130]
            - button [ref=e131] [cursor=pointer]:
              - img [ref=e132]
            - button [ref=e134] [cursor=pointer]:
              - img [ref=e135]
              - generic [ref=e137]: Fit
            - button [ref=e138] [cursor=pointer]:
              - img [ref=e139]
              - generic [ref=e141]: Share
            - button [ref=e142] [cursor=pointer]:
              - img [ref=e143]
              - generic [ref=e146]: Capture
          - generic:
            - generic:
              - text: 27.0 m² ·
              - generic: 35%
              - text: · 0.5 m
            - generic: "36"
          - button [ref=e147] [cursor=pointer]:
            - meter [ref=e149]
            - generic [ref=e150]: ☀ 0 Wh · ⚡ 26.5 kWh
            - generic [ref=e151]: −26.5 kWh
  - region "3D Mode" [ref=e153]:
    - generic [ref=e154]:
      - generic [ref=e155]:
        - generic "One Live Build" [ref=e156]:
          - img [ref=e158]
          - generic [ref=e161]:
            - strong [ref=e162]: Demo
            - generic "Demo only — orders, payments, quote requests and email submissions are disabled." [ref=e163]: Preview · no orders
        - generic "Design view" [ref=e164]:
          - button "2D Plan" [ref=e165] [cursor=pointer]:
            - img [ref=e166]
            - generic [ref=e168]: 2D Plan
          - button "3D House" [pressed] [ref=e169] [cursor=pointer]:
            - img [ref=e170]
            - generic [ref=e173]: 3D House
        - generic [ref=e174]:
          - button "Project hub" [ref=e175] [cursor=pointer]:
            - img [ref=e176]
            - generic [ref=e179]: Project hub
          - group [ref=e180]:
            - generic "EN — Preferences" [ref=e181] [cursor=pointer]:
              - img [ref=e182]
              - generic [ref=e186]: EN
            - option "English" [selected]
            - option "Français"
            - option "简体中文"
            - option "Español"
            - option "Ivory & sage" [selected]
            - option "Midnight & ocean"
            - option "Slate & sand"
            - option "Warm studio" [selected]
            - option "Sculpted gallery"
            - option "Midnight blueprint"
          - button "AI design" [ref=e187] [cursor=pointer]:
            - generic [ref=e188]: ✧
            - text: AI
          - button "Import plan" [ref=e189] [cursor=pointer]:
            - img [ref=e190]
            - generic [ref=e192]: Import plan
          - button "Clear page" [ref=e194] [cursor=pointer]:
            - img [ref=e195]
            - generic [ref=e197]: Clear
          - button "Undo" [disabled] [ref=e198]:
            - img [ref=e199]
          - button "Redo" [disabled] [ref=e201]:
            - img [ref=e202]
          - button "Products in this design" [ref=e204] [cursor=pointer]:
            - img [ref=e205]
          - button "Save" [ref=e208] [cursor=pointer]
          - button "Project tools" [ref=e209] [cursor=pointer]:
            - img [ref=e210]
      - generic [ref=e211]:
        - navigation "House design tools" [ref=e212]:
          - button "Foundation" [ref=e213] [cursor=pointer]:
            - generic [ref=e214]: ▱
            - text: Foundation
          - button "City Build" [ref=e215] [cursor=pointer]:
            - img [ref=e216]
            - generic [ref=e218]: City
          - button "Build" [pressed] [ref=e219] [cursor=pointer]:
            - img [ref=e220]
            - generic [ref=e223]: Build
          - button "Furnish" [ref=e224] [cursor=pointer]:
            - img [ref=e225]
            - generic [ref=e228]: Furnish
          - button "Paint" [ref=e229] [cursor=pointer]:
            - img [ref=e230]
            - generic [ref=e233]: Paint
          - button "Surfaces" [ref=e234] [cursor=pointer]:
            - img [ref=e235]
            - generic [ref=e237]: Surfaces
          - button "Garden" [ref=e238] [cursor=pointer]:
            - img [ref=e239]
            - generic [ref=e242]: Garden
          - button "Materials" [ref=e243] [cursor=pointer]:
            - img [ref=e244]
            - generic [ref=e247]: Materials
          - button "Solar" [ref=e248] [cursor=pointer]:
            - img [ref=e249]
            - generic [ref=e251]: Solar
        - generic [ref=e252]:
          - generic [ref=e253]:
            - generic [ref=e254]:
              - strong [ref=e256]: Ground
              - combobox "View floor" [ref=e257]:
                - option "Ground floor" [selected]
                - option "Roof"
                - option "＋ Add floor"
                - option "Foundation"
              - button "Plumbing & Electric" [ref=e258] [cursor=pointer]:
                - img [ref=e259]
              - generic [ref=e261]: 91.0 m²
            - generic [ref=e262]:
              - button "Remove" [ref=e263] [cursor=pointer]:
                - img [ref=e264]
                - generic [ref=e266]: Remove
              - button "Select" [pressed] [ref=e267] [cursor=pointer]:
                - img [ref=e268]
                - generic [ref=e271]: Select
              - button "Walls" [ref=e272] [cursor=pointer]:
                - img [ref=e273]
                - generic [ref=e275]: Walls
              - button "Draw room" [ref=e276] [cursor=pointer]:
                - img [ref=e277]
                - generic [ref=e279]: Draw room
              - group "Doors windows and stairs" [ref=e280]:
                - button "Door" [ref=e281] [cursor=pointer]:
                  - img [ref=e282]
                  - generic [ref=e285]: Door
                - button "Window" [ref=e286] [cursor=pointer]:
                  - img [ref=e287]
                  - generic [ref=e290]: Window
                - button "Stairs" [disabled] [ref=e291]:
                  - img [ref=e292]
                  - generic [ref=e294]: Stairs
              - button "Details" [ref=e295] [cursor=pointer]
          - generic [ref=e296]:
            - generic [ref=e297]:
              - button "Open Walk mode" [ref=e300] [cursor=pointer]: Walk
              - img "Room view in 3D — 61 parts. Drag to orbit; tap an item to select it, drag it to move it." [ref=e301]
            - generic [ref=e302]:
              - generic [ref=e303]:
                - generic [ref=e304]:
                  - strong [ref=e305]: View & dimensions
                  - button "Close view settings" [ref=e306] [cursor=pointer]: Close ×
                - generic [ref=e307]:
                  - generic [ref=e308]:
                    - text: Camera
                    - combobox "Camera view" [ref=e309]:
                      - option "Custom view" [disabled] [selected]
                      - option "Perspective"
                      - option "Above · perspective"
                      - option "Front · perspective"
                      - option "Axonometric"
                      - option "Top · orthographic"
                      - option "North elevation"
                      - option "East elevation"
                      - option "South elevation"
                      - option "West elevation"
                  - group "Orbit camera" [ref=e310]:
                    - generic [ref=e311]: Orbit camera
                    - button "Orbit camera left" [active] [ref=e312] [cursor=pointer]:
                      - img [ref=e313]
                    - button "Orbit camera right" [ref=e315] [cursor=pointer]:
                      - img [ref=e316]
                  - generic [ref=e318]:
                    - text: Lighting
                    - combobox "Lighting" [ref=e319]:
                      - option "Natural light" [selected]
                      - option "Colour check"
                  - generic [ref=e320]:
                    - generic [ref=e321]: 3D quality
                    - combobox "3D rendering quality" [ref=e322]:
                      - option "Auto · device"
                      - option "Low · fastest"
                      - option "Medium · balanced" [selected]
                      - option "High · detail"
                  - group "Wall view" [ref=e323]:
                    - button "Walls up" [ref=e324] [cursor=pointer]
                    - button "Cutaway" [pressed] [ref=e325] [cursor=pointer]
                    - button "Walls down" [ref=e326] [cursor=pointer]
                  - generic [ref=e327]:
                    - generic [ref=e328]: Wall height
                    - generic [ref=e329]:
                      - button "Lower wall height" [ref=e330] [cursor=pointer]: −
                      - generic "Wall height" [ref=e331]: 2.7 m
                      - button "Raise wall height" [ref=e332] [cursor=pointer]: +
                  - group "Sun" [ref=e333]:
                    - button "☀ Daylight" [ref=e334] [cursor=pointer]
                  - generic [ref=e335]: Natural light is an appearance preview. Colour check uses neutral lighting to compare finishes.
              - group "Camera navigation" [ref=e336]:
                - button "Layers" [ref=e338] [cursor=pointer]:
                  - img [ref=e339]
                  - generic [ref=e341]: Layers
                - button "House build guide" [ref=e342] [cursor=pointer]:
                  - img [ref=e343]
                - button "Move view" [ref=e345] [cursor=pointer]:
                  - img [ref=e346]
                  - generic [ref=e348]: Move view
                - button "Zoom in" [ref=e349] [cursor=pointer]:
                  - img [ref=e350]
                - button "Zoom out" [ref=e352] [cursor=pointer]:
                  - img [ref=e353]
                - button "Fit" [ref=e354] [cursor=pointer]:
                  - img [ref=e355]
                - button "View" [expanded] [ref=e357] [cursor=pointer]:
                  - img [ref=e358]
                  - generic [ref=e360]: View
            - paragraph [ref=e361]: Drag to orbit · two fingers or Shift-drag to pan · pinch to zoom · drag items to move
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | 
  3   | // A real WebGL regression: intercept the browser's canvas allocations, rather
  4   | // than asserting which helper name appears in ThreeStage's source.
  5   | type Allocation = { axis: 'width' | 'height'; value: number; cssWidth: number; cssHeight: number; at: number };
  6   | type BufferWindow = Window & { __bufferAllocations: Allocation[] };
  7   | test.use({ launchOptions: { args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', '--host-resolver-rules=MAP *.vercel.app 216.198.79.3'] } });
  8   | const read = (page: Page) => page.getByTestId('wallpaint-3d-gl').evaluate(canvas => {
  9   |   const surface = canvas as HTMLCanvasElement;
  10  |   const rect = surface.getBoundingClientRect();
  11  |   const gl = surface.getContext('webgl2')!;
  12  |   return {
  13  |     width: surface.width, height: surface.height,
  14  |     cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height),
  15  |     css: surface.getAttribute('style'), viewport: Array.from(gl.getParameter(gl.VIEWPORT) as Int32Array),
  16  |     error: gl.getError(), quality: surface.dataset.quality, shading: surface.dataset.shading,
  17  |     writes: (window as BufferWindow).__bufferAllocations,
  18  |   };
  19  | });
  20  | async function assertBuffer(page: Page, ratio: number) {
  21  |   await expect.poll(async () => {
  22  |     const r = await read(page);
  23  |     return r.width === Math.floor(r.cssWidth * ratio) && r.height === Math.floor(r.cssHeight * ratio);
  24  |   }).toBe(true);
  25  |   const r = await read(page);
> 26  |   expect(r.viewport).toEqual([0, 0, r.width, r.height]);
      |                      ^ Error: expect(received).toEqual(expected) // deep equality
  27  |   expect(r.error).toBe(0);
  28  |   return r;
  29  | }
  30  | 
  31  | for (const device of [
  32  |   { name: 'desktop', viewport: { width: 1280, height: 800 }, scale: 2 },
  33  |   { name: 'phone', viewport: { width: 390, height: 844 }, scale: 3 },
  34  | ]) test.describe(device.name, () => {
  35  |   test.use({ viewport: device.viewport, deviceScaleFactor: device.scale, hasTouch: device.name === 'phone' });
  36  |   test('allocates at final density once, preserves CSS, and resizes only for actual layout/density changes', async ({ page }, info) => {
  37  |     test.setTimeout(120000);
  38  |     const errors: string[] = [], writes: string[] = [];
  39  |     // Browser navigation uses the same pinned host as the application. The
  40  |     // separate Node API request client does not inherit Chromium's resolver.
  41  |     const health = await page.goto('/api/healthcheck');
  42  |     expect(health?.ok()).toBe(true);
  43  |     await info.attach('health.json', { body: await page.locator('body').innerText(), contentType: 'application/json' });
  44  |     page.on('pageerror', e => errors.push(e.message));
  45  |     await page.route('**/*', route => {
  46  |       if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) {
  47  |         writes.push(route.request().url()); return route.abort();
  48  |       }
  49  |       return route.continue();
  50  |     });
  51  |     await page.addInitScript(() => {
  52  |       localStorage.setItem('ppw_designer_coach_v1', '1');
  53  |       localStorage.setItem('olb-render-quality-v1', JSON.stringify({ state: { choice: 'medium' }, version: 0 }));
  54  |       const records: Allocation[] = (window as BufferWindow).__bufferAllocations = [];
  55  |       for (const axis of ['width', 'height'] as const) {
  56  |         const descriptor = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, axis)!;
  57  |         Object.defineProperty(HTMLCanvasElement.prototype, axis, {
  58  |           ...descriptor,
  59  |           set(this: HTMLCanvasElement, value: number) {
  60  |             if (this.dataset.testid === 'wallpaint-3d-gl') {
  61  |               const rect = this.getBoundingClientRect();
  62  |               records.push({ axis, value, cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height), at: performance.now() });
  63  |             }
  64  |             descriptor.set!.call(this, value);
  65  |           },
  66  |         });
  67  |       }
  68  |     });
  69  |     await page.goto('/demo?view=3d&pitch=1');
  70  |     await page.waitForFunction(() => Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0);
  71  |     const initial = await assertBuffer(page, 1.5);
  72  |     await info.attach('initial-buffer.json', { body: JSON.stringify(initial, null, 2), contentType: 'application/json' });
  73  |     expect(initial.writes.length).toBeGreaterThanOrEqual(2);
  74  |     expect(initial.writes.length % 2).toBe(0);
  75  |     for (let i = 0; i < initial.writes.length; i += 2) {
  76  |       const [width, height] = initial.writes.slice(i, i + 2);
  77  |       expect([width.axis, height.axis]).toEqual(['width', 'height']);
  78  |       expect(width.value).toBe(Math.floor(width.cssWidth * 1.5));
  79  |       expect(height.value).toBe(Math.floor(height.cssHeight * 1.5));
  80  |       if (i > 0) expect([width.value, height.value]).not.toEqual([initial.writes[i - 2].value, initial.writes[i - 1].value]);
  81  |     }
  82  |     await page.getByTestId('house-view-settings').click();
  83  |     const beforeOrbit = (await read(page)).writes.length;
  84  |     await page.getByTestId('wallpaint-3d-rotate-left').click();
  85  |     await page.waitForTimeout(150);
  86  |     expect((await read(page)).writes).toHaveLength(beforeOrbit);
  87  |     for (const [choice, ratio] of [['low', 1], ['high', 2], ['medium', 1.5]] as const) {
  88  |       const before = (await read(page)).writes.length;
  89  |       await page.getByRole('combobox', { name: '3D rendering quality' }).selectOption(choice);
  90  |       const after = await assertBuffer(page, ratio);
  91  |       expect(after.writes).toHaveLength(before + 2);
  92  |       expect(after.css).toBe(initial.css);
  93  |     }
  94  |     const beforeResize = (await read(page)).writes.length;
  95  |     await page.setViewportSize({ width: device.viewport.width - 20, height: device.viewport.height - 30 });
  96  |     await expect.poll(async () => (await read(page)).writes.length).toBeGreaterThan(beforeResize);
  97  |     const resized = await assertBuffer(page, 1.5);
  98  |     expect(resized.writes.length).toBeGreaterThan(beforeResize);
  99  |     expect(resized.css).toBe(initial.css);
  100 |     await info.attach('final-buffer.json', { body: JSON.stringify(resized, null, 2), contentType: 'application/json' });
  101 |     expect(errors).toEqual([]);
  102 |     expect(writes).toEqual([]);
  103 |   });
  104 | });
  105 | 
```