import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const runId = branch => { const raw = process.argv.find(value => value.startsWith('--' + branch + '-run='))?.split('=')[1]; if (!/^\d+$/.test(raw ?? '')) throw Error('Pass both exact --walk-run and --site-run IDs'); return Number(raw); };
const read = path => JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const route = value => { const url = new URL(value); return url.pathname + url.search; };
const normalize = item => ({ route: route(item.url), id: item.auditId, property: item.auditProperty ?? null, assertion: item.name, level: item.level, expected: item.expected, actual: item.actual, operator: item.operator });
const key = item => [item.route, item.id, item.property, item.assertion, item.level].join('|');
const failures = file => read(file).filter(item => !item.passed).map(normalize);
const baselineFile = resolve(root, '../../lighthouse-comparison/pr51/assertion-results.json');
const baseline = failures(baselineFile);
const reasons = {
  'csp-xss': 'Informational audit has score:null; inherited minScore>=0.9 converts it to actual0. Changing application headers cannot turn this audit into a scored pass, and LHCI uses its static server rather than Vercel response headers. Threshold/settings unchanged.',
  'total-byte-weight': 'Informational audit has score:null; inherited minScore>=0.9 converts it to actual0. Transfer reductions do not change that assertion. Threshold/settings unchanged.',
  'valid-source-maps': 'Public source maps are intentionally forbidden by the existing build guard/private Sentry upload policy. Do not disclose maps to make the inherited audit pass.',
  'unused-css-rules': 'Designer retains initial shared main/App styles needed by deferred tools, conditional states and other routes; pruning from one viewport is unsafe. The isolated plumbing base now omits Designer utility CSS while retaining complete preflight/fonts/body/preferences/brand/sales and lazy form styles. Actual audit items below determine whether that clears the unchanged maxLength0 assertion; no threshold/settings changes.',
};
const output = {
  at: new Date().toISOString(),
  baseline: { file: baselineFile, commit: '3eefbf7646f2b5c76e5297f7836e6e0336e8f1a2', sourceHead: '5a5f4a24281d118e80d3e54cd11f6233d6968f4b', sourceTreeIdentical: true, errorCount: baseline.filter(item => item.level === 'error').length },
  settingsUnchanged: true,
  branches: {}
};
for (const [branch, head, run] of [
  ['walk', '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e', runId('walk')],
  ['site', '7a73b25a2a32556d9d5cf5381d72e7c7bf611447', runId('site')]
]) {
  const directory = resolve(root, `lighthouse-final-${branch}-${head.slice(0, 7)}`);
  const runMetadata = read(resolve(directory, 'run-metadata.json'));
  if (runMetadata.id !== run || runMetadata.head_sha !== head || runMetadata.status !== 'completed') throw Error('Run metadata is not the completed exact-head run');
  const current = failures(resolve(directory, 'assertion-results.json'));
  const reports = readdirSync(directory).filter(name => /^lhr-.*\.json$/.test(name)).map(name => ({ file: name, report: read(resolve(directory, name)) }));
  const reportFor = item => reports.find(({ report }) => route(report.finalUrl) === item.route);
  const baseErrors = baseline.filter(item => item.level === 'error');
  const errors = current.filter(item => item.level === 'error');
  const unclassified = errors.filter(item => !reasons[item.id]);
  if (unclassified.length) throw Error('New or unexplained assertions require source review before classification: ' + JSON.stringify(unclassified));
  const removed = baseErrors.filter(item => !errors.some(other => key(other) === key(item)));
  const added = errors.filter(item => !baseErrors.some(other => key(other) === key(item)));
  const auditSummary = (report, id) => {
    const audit = report.audits[id];
    return { score: audit?.score, scoreDisplayMode: audit?.scoreDisplayMode, numericValue: audit?.numericValue, displayValue: audit?.displayValue,
      items: ['unused-css-rules', 'prioritize-lcp-image', 'errors-in-console'].includes(id) ? audit?.details?.items : undefined };
  };
  output.branches[branch] = {
    head, run, runMetadata, remainingErrorCount: errors.length, removedErrorCount: removed.length, newErrors: added,
    removed: removed.map(item => ({ ...item, currentAudit: auditSummary(reportFor(item).report, item.id), proof: reportFor(item).file })),
    remaining: errors.map(item => ({ ...item, baselineActual: baseErrors.find(other => key(other) === key(item))?.actual, reason: reasons[item.id], currentAudit: auditSummary(reportFor(item).report, item.id), proof: reportFor(item).file })),
    warnings: { count: current.filter(item => item.level === 'warn').length,
      added: current.filter(item => item.level === 'warn' && !baseline.some(other => key(other) === key(item))),
      removed: baseline.filter(item => item.level === 'warn' && !current.some(other => key(other) === key(item))),
      current: current.filter(item => item.level === 'warn') },
    categories: reports.map(({file, report}) => ({ file, route: route(report.finalUrl), lighthouseVersion: report.lighthouseVersion, scores: Object.fromEntries(Object.entries(report.categories).map(([id, category]) => [id, category.score])) }))
  };
  const prior = read(resolve(root, '../round2/lighthouse-classification-corrected.json')).branches[branch];
  output.branches[branch].sinceRound2 = {
    priorHead: prior.head,
    removed: prior.remaining.filter(item => !errors.some(other => key(other) === key(item))).map(item => ({ route: item.route, id: item.id })),
    added: errors.filter(item => !prior.remaining.some(other => key(other) === key(item))).map(item => ({ route: item.route, id: item.id })),
  };
}
writeFileSync(resolve(root, 'lighthouse-classification-final-52fa408-7a73b25.json'), JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(Object.fromEntries(Object.entries(output.branches).map(([branch, item]) => [branch, { remaining: item.remainingErrorCount, removed: item.removedErrorCount, newErrors: item.newErrors, categories: item.categories, newWarningIds: item.warnings.added.map(item => `${item.route}|${item.id}`) }])), null, 2));
