# Bounded native phone tap pair

Prepared after formal phonev6 failed its first door Open tap at exact source `52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e`. The failed formal result remains unchanged. This is diagnostic source preparation only; no run is authorized while Site owns the browser/CPU lease.

The new `harness/walk-functional-phone-tap-diagnostic.mjs` is a separate copy of the predeclared v6 harness. Application source and the v6 harness remain unchanged. Each of the following two arms opens a fresh browser/context and executes the same native movement, controls, door approach and bounded safety behavior. Both use identical passive instrumentation. The only action difference is the door tap: unchanged Playwright locator.tap versus native CDP touchStart at the measured centre, an explicit100ms held contact, and touchEnd. This changes both contact duration and native dispatch path, so any difference is evidence for a narrower follow-up, not proof that duration alone caused it.

Run these two commands serially only after root grants the exclusive lease, once each even if the first fails:

1. `node work/world-finish/round3/harness/walk-functional-phone-tap-diagnostic.mjs walk --expected=52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e --tap-protocol=locator --label=r3-phone-tap-pair-v1-locator`
2. `node work/world-finish/round3/harness/walk-functional-phone-tap-diagnostic.mjs walk --expected=52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e --tap-protocol=contact100 --label=r3-phone-tap-pair-v1-contact100`

Each writes its own immutable `results/<label>/walk-functional-walk.json` and any failure screenshots. No success-selected retry or third context is planned. Missing click/no-state-change stops the door check; only an observed trusted click and explicit collision-safety rejection permits the unchanged maximum two native0.20m retreats. The second arm's100ms contact is explicit diagnostic input, not a pre-tap/ready settling wait. All ordinary navigation and observations remain the same.

Both arms retain pointer/touch delivery, isPrimary/buttons/pressure, actual target identity/connection, got/lostpointercapture and hasPointerCapture at the event target, compatibility mouse/click events, post-bubble/microtask defaultPrevented, and status publication. There is no preventDefault monkeypatch, synthetic DOM click, pose injection or application patch. Contact100 records command boundaries as well as the real event timestamps. Native touchEnd is attempted in finally after a successful native start.

Hypothesis: native gesture classification/click delivery after the preceding drag may differ from the application door handler. This is not established. A result difference between arms would narrow native dispatch/gesture handling; neither arm's success erases formalv6 or proves a product fix. Identical missing-click failures keep the hypothesis unresolved. DOM replacement/prevention/capture evidence must be reported if observed rather than assuming a browser cause. These functional diagnostics do not alter or replace input/FPS timing protocols or establish physical-phone ergonomics.
