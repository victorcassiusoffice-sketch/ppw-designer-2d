// Functional/visual and CSS coverage checks only. Never run during a formal
// timing campaign. Requires an exact deployed head; preserves every failure.
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TARGETS, LABEL, acquireRun } from '../round2/run-config.mjs';

const branch = process.argv[2], expectedHead = process.argv[3];
if (!['walk', 'site'].includes(branch) || !/^[a-f0-9]{40}$/.test(expectedHead ?? '')) throw Error('Usage: node plumbing-browser.mjs walk|site FULL_HEAD --label=r3-unique');
if (!process.argv.some(arg => arg.startsWith('--label=r3-'))) throw Error('Use a new explicit r2 label.');
acquireRun('plumbing-functional-visual');
const repo = `C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-${branch}`;
const require = createRequire(resolve(repo, 'package.json'));
const { chromium } = require('playwright');
const base = TARGETS[branch];
const output = resolve(dirname(fileURLToPath(import.meta.url)), 'plumbing', LABEL, branch);
if (existsSync(output)) throw Error('Refusing to overwrite prior browser evidence');
mkdirSync(output, { recursive: true });
const report = { at: new Date().toISOString(), branch, expectedHead, base, label: LABEL, checks: [] };
const assert = (condition, message) => { if (!condition) throw Error(message); };

async function checkEnquiry(page, row, prefix) {
  row.formChecks = { fixtures: [], purposes: [] };
  const form = page.locator('form.pitch-enquiry');
  const submit = form.locator('button[type="submit"]');
  const startingRequests = row.attemptedWrites.length;
  await submit.click();
  assert(await form.locator(':invalid').count() > 0, 'Empty form is unexpectedly valid');
  assert(row.attemptedWrites.length === startingRequests, 'Invalid form attempted submission');
  await form.locator('[name="name"]').fill('Diagnostic Fixture');
  await form.locator('[name="email"]').fill('fixture@example.test');
  await form.locator('[name="message"]').fill('Local browser test fixture. No request leaves this browser.');
  await submit.click();
  assert(!(await form.locator('[name="consent"]').isChecked()), 'Consent was preselected');
  assert(row.attemptedWrites.length === startingRequests, 'Missing consent attempted submission');
  await form.locator('[name="consent"]').check();
  row.formChecks.honeypot = await form.locator('.pitch-honeypot').evaluate(element => ({ hidden: element.getAttribute('aria-hidden'), clip: getComputedStyle(element).clipPath, position: getComputedStyle(element).position, tabIndex: element.querySelector('input').tabIndex }));
  assert(row.formChecks.honeypot.hidden === 'true' && row.formChecks.honeypot.tabIndex === -1 && row.formChecks.honeypot.clip === 'inset(50%)', 'Honeypot presentation changed');
  let prepared;
  await page.route('**/api/pitch-enquiry', async route => {
    if (!prepared || route.request().method() !== 'POST') { row.attemptedWrites.push({ url: route.request().url(), method: route.request().method(), unexpectedFixture: true }); return route.abort(); }
    const current = prepared; prepared = null;
    const payload = route.request().postDataJSON();
    row.formChecks.fixtures.push({ payload, response: current.response, transmitted: false });
    let release;
    const hold = new Promise(accept => { release = accept; });
    current.arrived({ payload, release });
    await hold;
    await route.fulfill({ status: current.status, contentType: 'application/json', body: JSON.stringify(current.response) });
  });
  const sendFixture = async (purpose, status) => {
    let timer;
    const arrived = new Promise((accept, reject) => {
      timer = setTimeout(() => reject(Error('Fixture was not intercepted within 5s')), 5000);
      prepared = { status, response: status === 200 ? { status: 'received', receipt: 'PPW-123456' } : { error: 'Local diagnostic rejection' }, arrived: accept };
    });
    arrived.catch(() => {}); // Retain a timeout without an unhandled rejection during click.
    let caught;
    try { await submit.click(); caught = await arrived; }
    finally { clearTimeout(timer); }
    try {
      assert(caught.payload.purpose === purpose && caught.payload.consent && caught.payload.website === '', 'Fixture payload changed');
      assert(await submit.isDisabled(), 'Submit must be disabled while saving');
    } finally { caught.release(); }
    await form.locator(status === 200 ? '[role="status"]' : '[role="alert"]').waitFor({ state: 'visible' });
    assert((await submit.isDisabled()) === (status === 200), 'Submit status changed');
  };
  for (const [index, purpose] of ['project', 'feedback', 'physical-meeting'].entries()) {
    await form.locator('[role="group"] button').nth(index).click();
    const physical = purpose === 'physical-meeting';
    assert((await form.locator('[name="location"]').count() > 0) === physical, 'Conditional meeting field');
    if (physical) {
      assert(await form.locator('[name="location"]').getAttribute('required') !== null, 'Meeting location must be required');
      await form.locator('[name="location"]').fill('Fixture office');
      await form.locator('[name="availability"]').fill('Fixture daytime');
    }
    if (purpose === 'project') {
      await sendFixture(purpose, 503);
      assert(await form.locator('[name="email"]').inputValue() === 'fixture@example.test', 'Failure discarded form entries');
      await page.screenshot({ path: resolve(output, `${prefix}-form-error.jpg`), type: 'jpeg', quality: 65, fullPage: true });
    }
    await sendFixture(purpose, 200);
    row.formChecks.purposes.push(purpose);
    await page.screenshot({ path: resolve(output, `${prefix}-form-${purpose}.jpg`), type: 'jpeg', quality: 65, fullPage: true });
  }
  const downloadEvent = page.waitForEvent('download');
  await form.locator('button.pitch-secondary').click();
  const download = await downloadEvent;
  const path = await download.path();
  row.formChecks.download = { name: download.suggestedFilename(), text: readFileSync(path, 'utf8') };
  assert(row.formChecks.download.text.includes('not submitted by this download') && row.formChecks.download.text.includes('Purpose: physical-meeting') && row.formChecks.download.text.includes('Location: Fixture office'), 'Downloaded draft content');
  await page.unroute('**/api/pitch-enquiry');
}

const browser = await chromium.launch({ headless: true, args: ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', `--host-resolver-rules=MAP ${new URL(base).hostname} 216.198.79.3`] });
try {
  for (const brand of ['olb', 'ppw']) for (const [device, options] of Object.entries({ desktop: { viewport: { width: 1365, height: 900 } }, phone: { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 } })) {
    const context = await browser.newContext(options);
    const row = { brand, device, attemptedWrites: [], pageErrors: [], consoleErrors: [], httpErrors: [], initialRequests: [], states: [] };
    report.checks.push(row);
    await context.route('**/*', route => {
      const request = route.request();
      if (!['GET', 'HEAD', 'OPTIONS'].includes(request.method())) { row.attemptedWrites.push({ method: request.method(), url: request.url() }); return route.abort(); }
      return route.continue();
    });
    const page = await context.newPage();
    page.on('pageerror', error => row.pageErrors.push(String(error)));
    page.on('console', message => { if (message.type() === 'error') row.consoleErrors.push({ text: message.text(), url: message.location().url, fixture: message.location().url?.endsWith('/api/pitch-enquiry') && (row.formChecks?.fixtures.length ?? 0) > 0 }); });
    page.on('response', response => { if (response.status() >= 400) row.httpErrors.push({ url: response.url(), status: response.status(), fixture: response.url().endsWith('/api/pitch-enquiry') && response.request().method() === 'POST' && (row.formChecks?.fixtures.length ?? 0) > 0 }); });
    const healthResponse = await page.goto(base + '/api/healthcheck');
    assert(healthResponse?.ok(), 'Health request failed');
    row.health = JSON.parse(await page.locator('body').innerText());
    assert(row.health.commit === expectedHead && row.health.env === 'preview', 'Wrong deployed head/environment');
    await page.coverage.startCSSCoverage({ resetOnNavigation: false });
    const request = request => row.initialRequests.push({ url: request.url(), type: request.resourceType() });
    page.on('request', request);
    await page.goto(base + '/pitch/plumbing' + (brand === 'ppw' ? '?brand=ppw' : ''), { waitUntil: 'domcontentloaded' });
    await page.locator('.sales-shot img').waitFor({ state: 'visible' });
    await page.evaluate(async () => { await document.fonts.ready; await Promise.all([...document.images].map(image => image.decode().catch(() => {}))); });
    page.off('request', request);
    row.initial = await page.evaluate(() => ({
      href: location.href, brand: document.documentElement.dataset.brand, manifest: document.querySelector('link[rel="manifest"]')?.getAttribute('href'),
      scripts: [...document.querySelectorAll('link[rel="modulepreload"]')].map(link => link.getAttribute('href')),
      styles: [...document.querySelectorAll('link[rel="stylesheet"]')].map(link => link.getAttribute('href')),
      imagePreloads: [...document.querySelectorAll('link[rel="preload"][as="image"]')].map(link => ({ href: link.getAttribute('href'), srcset: link.imageSrcset, sizes: link.imageSizes })),
      hero: (() => { const image = document.querySelector('.sales-shot img'); const box = image.getBoundingClientRect(); return { src: image.currentSrc, width: box.width, height: box.height, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight }; })(),
      fcp: performance.getEntriesByName('first-contentful-paint')[0]?.startTime,
    }));
    assert(row.initial.scripts.length === 3 && row.initial.scripts.every(url => url.startsWith('/assets/plumbing/')), 'Primary startup was loaded by pitch');
    assert(row.initial.styles.length === 1 && row.initial.styles[0].startsWith('/assets/plumbing/'), 'Pitch initial stylesheet selection');
    assert(row.initial.imagePreloads.length === 1 && row.initial.hero.src.endsWith('.webp'), 'Responsive hero was not preloaded');
    assert(!row.initialRequests.some(item => item.url.includes('exchangerate.host') || /\/assets\/main-[^/]+\.js/.test(item.url)), 'Pitch started FX or primary main');
    const initialJs = row.initialRequests.filter(item => item.type === 'script');
    assert(initialJs.every(item => new URL(item.url).pathname.startsWith('/assets/plumbing/')), 'Unexpected pitch startup script request');

    for (const theme of ['ivory', 'ocean', 'slate']) {
      await page.locator('details.locale-theme-controls > summary').click();
      await page.locator(`.theme-skin-card--${theme}`).click();
      await page.waitForFunction(theme => document.documentElement.dataset.uiTheme === theme, theme);
      await page.screenshot({ path: resolve(output, `${brand}-${device}-${theme}-preferences.jpg`), type: 'jpeg', quality: 65, fullPage: true, animations: 'disabled' });
      await page.locator('.locale-theme-controls__heading button').click();
      for (let chapter = 0; chapter < 6; chapter++) {
        await page.locator('[role="tab"]').nth(chapter).click();
        await page.locator(`[role="tab"][aria-selected="true"]`).nth(0).waitFor();
        if (chapter === 5) await page.locator('form.pitch-enquiry input[name="email"]').waitFor({ state: 'visible' });
        await page.evaluate(async () => { await document.fonts.ready; await Promise.all([...document.images].map(image => image.decode().catch(() => {}))); });
        const state = await page.evaluate(({ theme, chapter }) => ({ theme, chapter, heading: document.querySelector('h1')?.textContent,
          selected: document.querySelector('[role="tab"][aria-selected="true"]')?.id, hash: location.hash,
          overflow: document.documentElement.scrollWidth > innerWidth, fonts: document.fonts.status,
          main: (() => { const style = getComputedStyle(document.querySelector('.sales-pack')); return { font: style.fontFamily, color: style.color, background: style.backgroundColor }; })(),
          form: (() => { const form = document.querySelector('form.pitch-enquiry'); return form ? { display: getComputedStyle(form).display, gap: getComputedStyle(form).gap, consent: !!form.querySelector('input[name="consent"]') } : null; })(),
        }), { theme, chapter });
        row.states.push(state);
        assert(!state.overflow && state.heading && state.selected === `sales-tab-${chapter}`, `${device}/${theme}/${chapter} layout/navigation`);
        if (chapter === 5) assert(state.form?.display === 'flex' && state.form.consent, 'Deferred enquiry form changed');
        await page.screenshot({ path: resolve(output, `${brand}-${device}-${theme}-chapter${chapter + 1}.jpg`), type: 'jpeg', quality: 65, fullPage: true, animations: 'disabled' });
      }
    }
    row.locales = [];
    for (const locale of ['en', 'fr', 'zh-CN', 'es']) {
      await page.locator('details.locale-theme-controls > summary').click();
      await page.locator('.locale-theme-controls select').first().selectOption(locale);
      await page.waitForFunction(locale => document.documentElement.lang === locale, locale);
      const controls = await page.evaluate(() => {
        const select = document.querySelector('.locale-theme-controls select'); const box = select.getBoundingClientRect();
        return { language: document.documentElement.lang, width: box.width, right: box.right, viewport: innerWidth, value: select.value, text: select.selectedOptions[0].text, font: getComputedStyle(select).fontFamily };
      });
      assert(controls.width > 100 && controls.right <= controls.viewport + 1 && controls.value === locale, 'Locale select size/value');
      await page.screenshot({ path: resolve(output, `${brand}-${device}-locale-${locale}.jpg`), type: 'jpeg', quality: 65, fullPage: true, animations: 'disabled' });
      await page.locator('.locale-theme-controls__heading button').click();
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.locator('form.pitch-enquiry input[name="email"]').waitFor({ state: 'visible' });
      const persisted = await page.evaluate(() => ({ locale: document.documentElement.lang, preferences: localStorage.getItem('olb.ui-preferences.v1') }));
      assert(persisted.locale === locale, 'Locale preference not restored');
      row.locales.push({ ...controls, persisted });
    }
    await page.locator('details.locale-theme-controls > summary').click();
    await page.locator('.locale-theme-controls select').first().selectOption('en');
    await page.locator('.locale-theme-controls__heading button').click();
    await checkEnquiry(page, row, `${brand}-${device}`);
    row.cssCoverage = (await page.coverage.stopCSSCoverage()).map(entry => ({ url: entry.url, bytes: entry.text.length, usedBytes: entry.ranges.reduce((sum, range) => sum + range.end - range.start, 0), ranges: entry.ranges }));
    await page.locator('[role="tab"]').nth(1).click();
    await page.locator('.sales-start-demo').click();
    const frame = page.frameLocator('iframe[title="Working 2D and 3D building services planner"]');
    await frame.getByTestId('rooms-trigger').waitFor({ state: 'visible', timeout: 60000 });
    row.iframe = { src: await page.locator('iframe').getAttribute('src'), ready: await frame.getByTestId('rooms-trigger').isVisible() };
    await frame.getByRole('button', { name: '3D edit', exact: true }).click();
    await frame.getByRole('button', { name: '3D edit', exact: true }).getAttribute('aria-pressed').then(value => assert(value === 'true', 'Iframe 3D control'));
    await frame.getByRole('button', { name: '2D plan', exact: true }).click();
    await frame.getByRole('button', { name: '2D plan', exact: true }).getAttribute('aria-pressed').then(value => assert(value === 'true', 'Iframe 2D control'));
    row.iframe.originalStyles = await page.locator('iframe').evaluate(iframe => [...iframe.contentDocument.querySelectorAll('link[rel="stylesheet"]')].map(link => link.getAttribute('href')));
    assert(row.iframe.originalStyles.some(url => url.startsWith('/assets/main-')), 'Iframe lost primary stylesheet');
    assert(row.iframe.src === '/embed/designer?scene=home&view=2d&panel=services&pitch=1' && row.iframe.ready, 'Standalone iframe failed to start original designer');
    await page.goto(base + '/pitch/plumbing/?brand=ppw#Next%20step', { waitUntil: 'domcontentloaded' });
    await page.locator('form.pitch-enquiry input[name="email"]').waitFor({ state: 'visible' });
    row.permalink = await page.evaluate(() => ({ url: location.href, brand: document.documentElement.dataset.brand, manifest: document.querySelector('link[rel="manifest"]')?.getAttribute('href'), heroPreloads: document.querySelectorAll('link[as="image"]').length, selected: document.querySelector('[role="tab"][aria-selected="true"]')?.id }));
    assert(row.permalink.manifest === '/brand/ppw/site.webmanifest' && row.permalink.selected === 'sales-tab-5' && row.permalink.heroPreloads === 0, 'PPW/slash/chapter permalink changed');
    assert(row.attemptedWrites.length === 0 && row.pageErrors.length === 0 && !row.consoleErrors.some(error => !error.fixture) && !row.httpErrors.some(error => !error.fixture), 'Browser errors or writes');
    const endingHealth = await page.goto(base + '/api/healthcheck');
    assert(endingHealth?.ok(), 'Final health request failed');
    row.healthAfter = JSON.parse(await page.locator('body').innerText());
    assert(row.healthAfter.commit === expectedHead && row.healthAfter.env === 'preview', 'Head changed during browser checks');
    await context.close(); row.contextClosed = true;
    writeFileSync(resolve(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  }
} catch (error) { report.failure = String(error); process.exitCode = 1; }
finally { await browser.close(); writeFileSync(resolve(output, 'report.json'), JSON.stringify(report, null, 2) + '\n'); }
console.log(JSON.stringify({ branch, label: LABEL, checks: report.checks.length, states: report.checks.reduce((sum, row) => sum + row.states.length, 0), failure: report.failure ?? null }));
