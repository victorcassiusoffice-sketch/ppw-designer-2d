# Round 3 Site campaign protocol

## Retained v1 failure and authorized v2 disclosure correction

The first exact-head plan attempt, `results/r3-site-plan-7a73b25-v1`,
failed both native rows because it required the mounted `plot-capacity` text to
be visible without opening the existing **Show plan tools** disclosure. Both
timeouts resolved the correct `Plot 64 m²` text in a hidden span. No saved-data
rows or plan screenshots were reached. The original JSON and harness are retained.

Before the fresh `r3-site-plan-7a73b25-v2` attempt, the coordinator authorized a
scratch-only correction: activate the visible `canvas-chrome-toggle` by native
click/tap when `aria-expanded` is not true, before the visible-capacity check.
The held-hydration context opens the same disclosure before checking that pending
capacity is absent, then requires visible canonical capacity after release.
Canonical-area, label, unchanged-room, concave constraints and pending-data
assertions are unchanged. No application source or state is changed by this repair.

## Current authorized source and fresh labels

Final source update before execution on 29 October 2026: use
`7a73b25a2a32556d9d5cf5381d72e7c7bf611447`. This replaces the pending heads below
after the test-only measurement repair. The application assertions, native input
protocol, PDF oracle and required visual review stay unchanged. Fresh locations:

- UI: `site-g-7a73b25-20261029`.
- Dedicated PDF: `site-print-7a73b25-20261029`.
- Plan: `results/r3-site-plan-7a73b25-v1`.

Every harness receives that full SHA explicitly and checks normal-preview health.
Run only after the Lighthouse visual campaign and Walk performance campaign have
released their leases and the coordinator grants the Site browser window. Retain
raw health/error/write records, all actual PDF pages, and all eight plan images;
no old-source result substitutes for this exact-head campaign.

## Prior unexecuted 7f64f6c declaration

Updated before execution on 29 October 2026 after the isolated contrast follow-up.
The current expected source is `7f64f6cb8d4fb7c06c8f6c23a909503f96067fe0`.
Pass this full SHA to each unchanged harness; use these fresh output locations:

- UI: `site-g-7f64f6c-20261029`.
- Dedicated PDF: `site-print-7f64f6c-20261029`.
- Plan: `results/r3-site-plan-7f64f6c-v1`.

All three locations were confirmed absent before this update. The previous
`4da2e21` plan below is retained as preparation history; its campaigns were never
run and its output locations remain unused. The locator correction and all
protocol assertions below still apply. No browser, build or test is started by
this update. Execution waits for the exclusive lease and exact preview health.

Review every raw health/error/write record. Render and inspect all PDF pages
(expected four per device, eight total; actual page inventory governs), and all
eight plan images: applied outline, accepted interior room, held hydration and
released hydration at both device sizes. Any missing screenshot/page or failed
row stays an explicit failure; neither a partial visual review nor a raw pass
flag can stand in for complete evidence. Preserve each attempt in its own folder.

## Earlier unexecuted source declaration

Prepared before execution on 29 October 2026. Expected source is
`4da2e213a0957467e68d903d99883fd336982ae7`; every harness receives the full SHA
as an argument and verifies the normal preview healthcheck. No browser campaign
has been executed under these labels at the time of this declaration.

The existing seven-case UI and all-page PDF harnesses remain unchanged. Run them
in separate fresh directories `site-g-4da2e21-20261029` and
`site-print-4da2e21-20261029`. The PDF skill marker runs immediately before each
PDF-producing campaign. Retain all failures, provider responses, console and HTTP
errors, blocked writes, and all rendered pages. Automated PDF success is not
visual approval: inspect every rendered page and write a separate visual review.
The UI harness's raw pass flag does not check every console/HTTP error; review
those arrays explicitly in the final assessment.

The new `harness/site-plan-projection.mjs` campaign uses the fresh label
`r3-site-plan-4da2e21-v1`. It enters a six-leg, 64 m² concave survey through the
actual Site controls, applies it without changing existing rooms, reads the real
canvas label and capacity, and draws a rejected notch room and an accepted
interior room through native mouse/touch input. A second fresh context per device
seeds only that resulting local saved fixture and deliberately holds the deferred
hydration response. Pending data must show no geographic label/capacity; release
must restore canonical geometry/64 m² and preserve existing rooms. The test is
functional viewport emulation, not physical-phone or performance evidence.

## Pre-execution locator correction

Static review found that the phone construction shelf defaults to collapsed.
`src/styles/designerStudio.css` lines 644–645 hide its tool buttons while
`data-expanded="false"`; `src/components/TopBar.tsx` exposes the visible **Build**
category to open the shelf. The initial draft tried to tap `wall-tool-toggle`
directly and could therefore target a hidden control.

Before starting a new room, the revised scratch harness checks the real Walls
button's pressed state. If it is not pressed and is hidden, it activates the
visible **Plan tool categories → Build** button, then activates Walls. An already
active drawing tool is left active. All activations remain native locator click
or tap operations, with no forced click, DOM event injection, product mutation,
or change to the assertions. This correction was authorized and declared before
the first execution; it does not replace or erase a failed browser run.

The harness retains each row's exact before/after health, errors and network-write
counts. Its four required rows are laptop/phone × native-concave-plan/saved-world-
held-hydration. Missing rows fail the campaign. Inspect all plan screenshots for
the actual north arrow, canonical outline, pending absence and visible controls;
record that review separately. Preserve a fresh directory for every subsequent
attempt rather than overwriting evidence. Close all browser contexts/processes
and release the shared run lock before handing the lease back.
