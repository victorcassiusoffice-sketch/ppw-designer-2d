# Final Round 3 package configuration

The packager is prepared but has not been executed, hashed, compressed or syntax-checked during another agent's CPU lease. Root supplies a complete config after final publication/measurement and explicitly authorizes execution. No preliminary head or evidence directory is a silent default.

Run only after the exclusive work is released:

`node work/world-finish/round3/package-round3.mjs --execute --walk-final-reviewed --inputs=package-inputs-final.json`

Without --execute it only prints the required schema; it does not read evidence or create output. This schema description is not permission to run during another lease.

The config has exactly these six keys:

```json
{
  "version": 1,
  "heads": { "base": "<40 lowercase hex>", "walk": "<final40 lowercase hex>", "site": "<final40 lowercase hex>" },
  "inputs": {
    "summary": "results/<final-campaign>/summary.json",
    "network": "results/<final-campaign>/network-audit.json",
    "loads": "results/<final-campaign>/load-all.json",
    "attribution": "build-attribution-<final-label>.json",
    "semantic": "semantic-gate-<final-label>.json",
    "buildBase": "builds/<controlled-base-label>/base/audit.json",
    "buildWalk": "builds/<final-build-label>/walk/audit.json",
    "buildSite": "builds/<final-build-label>/site/audit.json",
    "startup": "startup-analysis-final.json",
    "lighthouse": "lighthouse-classification-<final-label>.json",
    "themeWalk": "theme-tests/<final-theme-label>/walk/verified.json",
    "themeSite": "theme-tests/<final-theme-label>/site/verified.json",
    "themeWalkReview": "theme-tests/<final-theme-label>/walk/visual-review.json",
    "themeSiteReview": "theme-tests/<final-theme-label>/site/visual-review.json",
    "walk": "R3-WALK-INPUT-FRAMES-FUNCTIONAL.json",
    "walkReview": "R3-WALK-INPUT-FRAMES-FUNCTIONAL.md",
    "siteDirectory": "site-g-<final7>-20261029",
    "sitePlan": "results/r3-site-plan-<final7>-v1/plan-projection.json",
    "sitePlanReview": "results/r3-site-plan-<final7>-v1/visual-review.json",
    "printDirectory": "site-print-<final7>-20261029",
    "rules": "rules-audit-final.json",
    "visibleRules": "results/<final-rules-label>/visible-rules.json",
    "ci": "ci-status-<final-label>.json",
    "publication": "source-publication-final.json"
  },
  "walkProofs": {
    "background": "results/<label>/background-ownership.json",
    "input": "results/<label>/walk-performance-walk.json",
    "frames": "results/<label>/walk-framerate-walk.json",
    "desktop": "results/<label>/walk-functional-walk.json",
    "phone": "results/<label>/walk-functional-walk.json"
  },
  "walkHarnesses": {
    "background": { "path": "harness/walk-background.mjs", "sha256": "<64 lowercase hex>" },
    "input": { "path": "harness/walk-performance.mjs", "sha256": "<64 lowercase hex>" },
    "frames": { "path": "harness/walk-framerate.mjs", "sha256": "<64 lowercase hex>" },
    "desktop": { "path": "harness/walk-functional-lock.mjs", "sha256": "<64 lowercase hex>" },
    "phone": { "path": "harness/walk-functional-phone-current.mjs", "sha256": "<64 lowercase hex>" },
    "lib": { "path": "harness/lib.mjs", "sha256": "<64 lowercase hex>" },
    "config": { "path": "run-config.mjs", "sha256": "<64 lowercase hex>" }
  },
  "retainedDocsBytes": { "walk": 0, "site": 0 }
}
```

Replace every placeholder and both retained-byte numbers with measured final values. Zero is not an inferred docs size. Every path is relative to round3 and must remain inside it; a controlled base audit may be copied there with its source SHA intact if currently outside. No source evidence or old result may be overwritten. The five proof paths must equal the corresponding compact.proofFiles keys and report the exact Walk head before and after.

The semantic file requires baseHead and exactly branches.walk/branches.site. Each branch has head, passed boolean, earlyModuleClassifications, deferredModules, generalStartupChanges, sourceReview and sourceCoverage. The semantic passed flag is separate from numericPassed. sourceReview identifies the exact reviewedHead, reviewer and conclusion. sourceCoverage lists changedSourcePaths from Git, earlyChangedSourcePaths intersected with the final build, renderedChangePaths, their requiredClassifications union, sourceOnlyChanges and missingClassifications. The packager independently reconstructs that intersection/union; equal-length/equal-export changes still require source review. Every union id must have exactly one classification `{id,kind,reason}`; allowed kinds for PASS are lazy-seam, existing-alias, general-startup-fix and existing-accessibility-fix, with no missing classifications. A failed audit may explicitly use disallowed-feature/unclassified kinds. Each named deferred module must exist only as early:false in the selected final audit for a semantic PASS. List actual module ids from that audit; do not infer filenames. General startup improvements and repairs to existing accessibility remain separately labelled, with source rationale. The TopBar accessible-name repair restores the intentional Round1 fix after its erroneous base restoration; preserve the failed check and correction as evidence. A numerical byte pass does not waive semantic failure.

The Walk compact retains the existing input/frames/protocol/functional/gates shape. It additionally requires preparationDecision `{decision,reason,entryComparison:[{device,round2EntryMs,currentEntryMs,deltaMs}]}` for desktop and phone. Use exact Round2 raw costs, not displayed rounding; the packager checks current cost/delta against selected raw samples. Input must remain v3 with zero settling; strict frames remain v2/40000ms; phone functional is the predeclared v6. Existing failed prior-head probes remain separate, all compressed raw evidence retained.

For loader-specific paint, startup may include loadingPanelPaint `{heads:{walk,site},passed:true|false|null,reason,source:<relative JSON>}`. Omit it when proof is unavailable. All candidate FCPs within1s alone leave the actual-loader gate UNPROVEN; a failed prerequisite makes it FAIL. Never relabel FCP as loader paint.

Both final normal-source automated theme reports and both final visual reviews are mandatory, through the exact inputs themeWalk, themeSite, themeWalkReview and themeSiteReview. Each automated report must identify its current branch/head, normalSource:true, styleInjection:false, validHeads:true, four distinct tests and exact before/after health. Test statuses, minimum contrast and check counts independently determine its recorded automated pass/fail.

Each visual review requires `{sourceHead,branch,visualPassed,inspectedScreenshots,scope,findings}`. sourceHead must equal the final configured branch head; visualPassed is a boolean; scope is a nonempty string or string array; findings is an array, including any limitations/failures. inspectedScreenshots must list every final extracted PNG/JPG/JPEG exactly once, using branch-directory-relative forward-slash paths such as `extracted/1280px-olb-ocean-chapter-3.png`. Missing/extra images block packaging; a visual PASS requires actual images. The explicit list may cover images opened directly or byte-identical copies of a named opened representative.

Optional `imageEquivalence` groups have `{sha256,representative:{branch,path},members:[{branch,path}]}`. They may span the two selected final branch directories. The representative must be an explicit member; member paths must identify actual final extracted images; no image may occur in multiple groups in the same review. The packager checks the actual SHA256 of every member (including the representative), rejects conflicting claims and records the source hashes. Distinct images must be inspected rather than called equivalent. Automated and visual results are displayed separately; the combined theme gate requires both branches' automated AND visual results. Earlier automated PASS/visual FAIL attempts remain failed combined evidence. Every dark-contrast, footer-tests, theme-tests and lighthouse-prefixed directory is retained in the manifest, including uniquely named attempts. Textual evidence remains fully packaged; surplus screenshots/trace artifacts remain outside with hashes.

The Site plan review lists inspectedScreenshots as filenames relative to its result directory. Every produced PNG/JPEG must be reviewed; a passing visual review requires all eight expected images. Failed rows/reviews remain packageable when explicitly recorded. Original pending-review labels are not edited.

The selected Site UI directory must also contain visual-review.json. It is derived from siteDirectory without adding a configuration key. The review identifies sourceHead, automatedPassed, visualPassed, findings, inspectedScreenshots and inspectedPages; the last two lists together must cover every actual UI screenshot and generated PDF-page image exactly once. Automated and visual results remain separate, and the combined Site gate requires both. A raw seven-case pass must not hide a failed screenshot or attribution observation. Later bounded diagnostic captures retain their own identity and do not replace the initial visual record.

Before writing any output, the packager validates identity, schemas, distinct load/device/view coverage, raw-to-summary numbers, semantic classification, selected harness hashes, local report links and combined docs budget. It stages all writes in memory, then exclusively creates chat outputs/world-finish/round-3; an existing output blocks execution. Under3MB is strongly preferred;3.8MB is the soft package budget; package plus retained docs must be strictly under5,000,000bytes per PR. Final PDFs/pages and complete raw loads/Walk samples remain included. Large traces,144 pitch states and surplus screenshots remain outside with SHA256/bytes. Root rechecks the installed combined directory and archives prior published evidence before replacing it.

Playwright JSON results can embed many PNGs as base64. The packager preserves each complete original externally with SHA256/bytes, and packages a clearly named `*.sanitized.json.gz` derivative only when it finds known binary base64 bodies in actual suite/spec/test/result attachments. It changes only those bodies into references containing the original result path/hash/size, RFC6901 JSON pointer and decoded binary hash/size. Status, timing, errors, stdout, retry data, attachment metadata and text/JSON bodies are unchanged; SVG/text/JSON and ambiguous octet-stream bodies are not removed. Before writing each derivative, the packager restores every original body by its pointer, verifies decoded hashes/sizes and container identity, then asserts JSON-equivalence with the complete original parsed result. Extracted contrast/health/request JSON is still fully compressed into the package. `BINARY-ATTACHMENT-DERIVATIONS.json` records every transformation and preservation proof; `derivedPackagedAs` is distinct from byte-identical `packagedAs` in the source manifest. Invalid JSON, malformed attachment schemas or failed preservation invariants fall back to exact original raw gzip plus the diagnostic, never a partial derivative. This size repair does not change the strict combined five-million-byte ceiling.

Recognized Lighthouse reports (`lighthouseVersion` plus `audits`) use the same preservation policy through `*.screenshots-externalized.json.gz`. Only verified `/audits/screenshot-thumbnails/details/items/<index>/data`, `/audits/final-screenshot/details/data` and `/fullPageScreenshot/screenshot/data` fields may change, and only canonical nonempty JPEG/JPG/PNG/WebP/GIF/AVIF base64 image data URLs are accepted. References retain the exact data-URL prefix/MIME, original-container identity/pointer and decoded hashes/sizes. Every other audit field, score, category, warning/error, environment/configuration field, timing, dimensions and node geometry remains. The verifier restores all original data strings and compares the complete report before staging. Unsupported schema variants remain unchanged; malformed recognized data takes the exact-original fallback with diagnostic. No original LHR or failed run is discarded.

Final compact layout: JSON proofs above50KB and full source/failure/derivation tables are lossless gzip files with readable JSON indexes identifying original/compressed sizes and SHA256 values. All current formal load/network/Walk records remain included, including failures. Earlier/intermediate contrast and Lighthouse bulk records are retained externally, unchanged and hashed, with full failed-observation summaries packaged. Every top-level and nested scratch harness source is inventoried with execution determined only by its run record. No slow run or original is deleted. This supersedes earlier statements that every intermediate textual record travels inside the PR.
