# Native phone tap diagnostic pair

Both predeclared fresh contexts ran once at `52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e`, with exact preview health before/after and unchanged application source. Original formal phonev6 remains FAIL. Complete compact events and raw paths are in `PHONE-TAP-PAIR-52fa408-v1.json`.

| Arm | Door result | Observed contact duration ms | Last look-end to first tap-down ms | Other checks |
| --- | --- | --- | --- | --- |
| Unchanged locator.tap | First Open: no native mouse/click, FAIL | 0.10000002384185791 | 156.60000002384186 | Movement, controls, Exit PASS |
| Native CDP held100ms | Open/Close in both views: PASS | 134.10000002384186;137.20000004768372;143.10000002384186;127.70000004768372 | 111.79999995231628 | Movement, controls, Exit PASS |

Both first taps target the same enabled, connected door-button node throughout their own down/up and capture release. Both show isPrimary=true, buttons1/pressure1 at down and buttons0/pressure0 at up, implicit gotpointercapture then lostpointercapture, and no default prevention at capture, bubbling or microtask. Thus the newly captured failed arm does not support a leaked pointer capture, disconnected button or prevented event as its explanation.

The failed locator arm ends after trusted pointer/touch release with no compatibility mousedown/up/click. The contact100 arm additionally produces native mousedown/up/click and the door state changes safely. Its four actions succeed on attempt0, with no safety retreat or collision bypass. Both runs use one concurrent contact, no key events, exact design/camera restoration, and no page/console/HTTP errors or attempted writes.

This pair changes contact duration and native dispatch path together; it does not isolate duration alone. In particular, the retained older instrumented v5 locator pass had effectively zero-duration contact, so zero-duration suppression is not established as the cause. Post-drag intervals also overlap across prior failures and successes. The result justifies evaluating a finite-contact native protocol in a later round; it is not a product fix, a physical-device study, or permission to erase the Round3 formal failure.

Both terminal sessions finished (locator exit1, contact100 exit0); owned browser/harness OS matches were0 and the shared lock was absent at `2026-10-29T19:07:37.2892446Z`. `phone-tap-pair-release-52fa408-v1.json` records release before the next agent's diagnostic lease.
