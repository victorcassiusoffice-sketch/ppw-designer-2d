# Round 3 closure: failure streaks to verify against final evidence

This is a preparation note, not a final result. Round0 and within-round retries do not add failed rounds. A later passing round resets a failure streak. Do not use this note to override actual raw results.

| Item | Finish1 | Finish2 | Round3 decision rule |
|---|---|---|---|
| Absolute desktop first picture | Walk wall5700/canvas5183.5ms; Site5262/5184.2: fail | Walk4299/4165.9; Site4838/4718.8: fail | A genuine final failure is the third; record each attempt and next idea as OPEN |
| Loading panel visible within1s every run | All20 candidate FCPs exceed1s; fail | Only9/20 candidate FCPs within1s; fail | FCP is a prerequisite only. A final failed prerequisite is the third failure; never infer loader pixels from DOM/FCP alone |
| Desktop input every sample under50ms | Third-person max110.9ms; fail | Third-person max383.4ms; independent444.9ms diagnostic; fail | Report all final zero-settle samples and entry costs. A real failure is third; make an explicit retain/revert decision for preparation experiment |
| First-use human comprehension | Unmeasured, score1 | Unmeasured, score1 | Honest unproven human criterion remains OPEN after three documented rounds; device-specific copy is improvement, not a human study |
| Physical one-hand usability | Unmeasured, score1 | Unmeasured plus separate native phone door failure | Do not equate emulated one-contact success with physical comfort; report the human limit independently |
| Native phone Open/Close behavior | Earlier functional proof passes | New actual one-pointer follow-up reaches door but Open does not yield Close; fail | A Round3 failure is only the second consecutive actual failure. Diagnose/fix or continue Round4; do not retire it with human-proof limitation |
| Site phone relative timing | Wall+11.407% fails; canvas+7.817% passes | Both wall/canvas pass | A Round3 failure begins a new streak; it is not a third failure |
| Strict desktop60fps |58.6/59.7: fail|60/60: pass|A Round3 failure begins a new streak; preserve full precision, all tails and1% lows|
| Site repeated printed banner | Missing middle-page disclaimer; fail | All8pages pass, minimum gap17.9917mm | A new Round3 failure begins a new streak |
| Early semantic seam | Initially claimed pass, withdrawn after shader warm-up found | Initially claimed pass, withdrawn after actual feature code found | Round3 source repair must receive independent review plus actual request proof; numeric pass alone is insufficient |
| CI/accessibility/contrast introduced regression | Prior repair passes | Passes | All own regressions must be fixed; multiple within-Round3 attempts are not multiple failed rounds |

After final measurements, close the real round once. If every remaining failed/unproven item has exhausted its three-consecutive-round allowance, record its three attempts and next idea, and use the required stopped-round handoff. Otherwise continue the next real round, up to10, without prematurely declaring merge readiness.
