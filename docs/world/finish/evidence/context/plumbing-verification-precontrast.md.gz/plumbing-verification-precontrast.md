# Round 3 isolated CSS proof, before contrast repair

Exact application heads: Walk `bf249b542152eb72870fdfa76426a03152c069c7`, Site `6e57e7ed244a07572ffb2157210f650ba77be38f`. These results are immutable evidence for those heads; later seam/contrast commits require new final checks.

Root's controlled before/after build comparison passed: isolated initial CSS 17858→9028 gzip, with all 620 Walk / 613 Site primary non-HTML hashes identical. Early deltas at these heads532/940 gzip. The CSS concern added no primary code/request.

Readiness v1 returned the preceding documentation heads and is retained in `plumbing-readiness-v1.log`; no browser measurements were started. Readiness v2 matched both new heads. Commands were run serially under an exclusive lease:

```text
node work/world-finish/round3/plumbing-browser.mjs walk bf249b542152eb72870fdfa76426a03152c069c7 --label=r3-plumbing-v1
node work/world-finish/round3/plumbing-browser.mjs site 6e57e7ed244a07572ffb2157210f650ba77be38f --label=r3-plumbing-v1
node work/world-finish/round3/footer-browser-tests.mjs walk bf249b542152eb72870fdfa76426a03152c069c7 --label=r3-footer-v1
node work/world-finish/round3/footer-browser-tests.mjs site 6e57e7ed244a07572ffb2157210f650ba77be38f --label=r3-footer-v1
node work/world-finish/round3/pitch-dark-contrast-probe.mjs --label=r3-dark-v1
```

Both matrices pass 72 functional states (six chapters × three themes × two brands × two sizes),16 locale/persistence checks,16 intercepted form responses, four downloads and four iframe 2D/3D checks per branch. Real POSTs remained blocked; expected local 503 responses are retained and marked as fixtures. No unexpected page/console/HTTP errors or writes. Ending health remains exact. Output `plumbing/r3-plumbing-v1/{walk,site}` and console `plumbing-{walk,site}-v1.log`.

Both existing footer regressions pass 4/4, with 96 contrast readings combined and minimum 7.974437546:1. Output `footer-tests/r3-footer-v1/{walk,site}`. Both branches' 36 OLB states have zero changes in previously captured computed fonts/colors/backgrounds/form layout or headings/selection/overflow relative to Round 2; see `css-browser-comparison-{walk,site}.json`.

This is **not a visual pass**. Screenshot review found faint PPW dark catalogue text, both brands' dark enquiry status text, and the preferences Close glyph. The bounded comparison ran six contexts/twelve states across base 52 and both candidates. All 32 ancestor color/background/image/opacity comparisons are identical to base 52 (`dark-contrast-comparison.json`), proving these measured failures inherited rather than caused by the isolated base. Exact opaque ratios: Close 1.002 Ocean / 1.025 Slate; error status 1.315/1.308. Alpha-composited PPW gradient modelling also fails; `dark-contrast-quantified-v2.json` corrects the preliminary uncomposited gradient figures in the first derived file. Raw styles/screenshots remain untouched at `dark-contrast/r3-dark-v1`.

All five commands exited 0; all browsers/contexts closed and shared performance lock absent. Lease released before remote Lighthouse processing. The approved isolated contrast source and new actual-browser regression are now prepared, but not yet tested, committed or published.

## Exact-head CI and inherited Lighthouse classification

Quality, Secrets and Vercel pass on both heads. Walk runs: Quality 40840054055, Secrets 40840054043, Lighthouse 40840054052. Site: Quality 40840073497, Secrets 40840073539, Lighthouse 40840073575. Full API metadata and artifact contents are in `lighthouse-walk` / `lighthouse-site`.

Both now fix 16/22 inherited errors, with six remaining and no new error/warning IDs. The pitch unused-CSS audit has score 1 and an empty item array, so its unchanged maxLength 0 assertion passes. All five pitch category scores are 1.00. Both demo audits still flag the identical App 38014 transfer / 32868 waste and main 15234/11709 CSS; all conditional tool/dialog/3D styles remain owned by the primary app.

Remaining assertions: csp-xss×2 and total-byte-weight×2 are informative score-null audits whose inherited minScore assertion maps null to 0; no content reduction can make them scored passes. valid-source-maps×1 conflicts with the existing private-map policy. Demo unused-css-rules×1 covers two shared files needed outside the initial audited view; safe reduction would require broader ownership/refactoring and full feature/cascade/request proof, not deleting first-frame-unused selectors or adding non-seam early loading code. Thresholds/settings/dependencies are unchanged. Complete rows and raw audit objects: `lighthouse-classification.json`.

Artifact provenance: Walk 12882392384, digest 36f413d13e2a9c7696b9ac349f2b79f4e50192cf5e18f0dfe0b574bf28964051; Site 12882262897, digest 5bf614b3b4b67afcaf568c1cc090d07cd67e6b1f84625ba09b0f54a3cc5d88d8. Later exact-head artifacts must use distinct output directories and final classification filenames.
