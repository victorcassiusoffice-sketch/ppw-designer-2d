import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './run-config.mjs';
const read=(label,branch)=>JSON.parse(fs.readFileSync(path.join(ROOT,'builds',label,branch,'audit.json'),'utf8'));
const reports=[];
for(const branch of ['walk','site']) {
 const before=read('r3-before-css',branch),after=read('r3-after-css',branch);
 const primary=a=>a.assets.filter(row=>!row.file.startsWith('assets/plumbing/')&&!row.file.endsWith('.html'));
 const old=new Map(primary(before).map(row=>[row.file,row]));
 const current=new Map(primary(after).map(row=>[row.file,row]));
 const differences=[...new Set([...old.keys(),...current.keys()])].filter(file=>old.get(file)?.sha256!==current.get(file)?.sha256);
 const early=a=>a.early.reduce((sum,row)=>sum+row.gzipBytes,0);
 const css=a=>a.assets.filter(row=>row.file.startsWith('assets/plumbing/')&&row.file.endsWith('.css')).map(({file,bytes,gzipBytes,sha256})=>({file,bytes,gzipBytes,sha256}));
 const report={branch,beforeHead:before.sourceCommit,afterHead:after.sourceCommit,beforeStatus:before.sourceStatus,afterStatus:after.sourceStatus,primaryCount:current.size,primaryIdentical:differences.length===0,differences,earlyGzipBefore:early(before),earlyGzipAfter:early(after),cssBefore:css(before),cssAfter:css(after),htmlBefore:before.assets.filter(row=>row.file.endsWith('.html')),htmlAfter:after.assets.filter(row=>row.file.endsWith('.html')),finalizerPreserved:after.finalization?.originalNonHtmlHashesPreserved,publicMaps:after.publicMaps};
 report.allPrimaryFilesIncludingPublic = after.finalization.primaryFilesVerified;
 report.primaryDigestBefore = before.finalization.primaryHashDigest;
 report.primaryDigestAfter = after.finalization.primaryHashDigest;
 report.allPrimaryHashesIdentical = report.primaryDigestBefore === report.primaryDigestAfter;
 report.pass=report.primaryIdentical&&report.allPrimaryHashesIdentical&&report.earlyGzipAfter===report.earlyGzipBefore&&report.finalizerPreserved&&report.publicMaps.length===0;
 reports.push(report);
}
fs.writeFileSync(path.join(ROOT,'css-build-comparison.json'),JSON.stringify({at:new Date().toISOString(),reports},null,2));
console.log(JSON.stringify(reports.map(({branch,primaryCount,primaryIdentical,differences,earlyGzipBefore,earlyGzipAfter,cssBefore,cssAfter,pass})=>({branch,primaryCount,primaryIdentical,differences,earlyGzipBefore,earlyGzipAfter,cssBefore,cssAfter,pass})),null,2));
if(reports.some(row=>!row.pass)) process.exitCode=1;
