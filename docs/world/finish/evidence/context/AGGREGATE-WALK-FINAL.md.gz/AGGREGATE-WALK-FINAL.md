# Walk final aggregation preparation

`aggregate-walk-final.mjs` is source-prepared only. It has not been run or syntax-checked under the active Lighthouse lease. It performs no hashing, compression, browser or network work. Do not execute until all five predeclared Walk campaigns finish and the coordinator grants aggregation work.

The script binds to Walk `52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e` and the five filenames in `WALK-CAMPAIGN-PLAN.md`. Every file must exist, identify the exact head before/after, have a completed timestamp and preserve the selected protocol versions. Duplicate observations cannot be selected away. Missing measurements within a completed failed campaign stay absent/UNPROVEN rather than passing; the package's separate full-coverage guard still applies.

After inspecting results, create a new `walk-preparation-decision-final.json` with this shape:

```json
{
  "expected": "52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e",
  "decision": "retain | recommend-revert",
  "reason": "Explicit evidence-based interpretation of entry cost and observed benefit",
  "demonstratedBenefit": "The actual observed benefit, or its absence",
  "evidenceLimits": ["Limitations of this observation"],
  "campaignRelease": {
    "atUtc": "Actual recorded release timestamp",
    "allFiveProcessesExited": true,
    "allBrowsersClosed": true,
    "sharedLockAbsent": true,
    "matchingHarnessOrPlaywrightProcesses": 0
  }
}
```

Select one decision value; the placeholder containing a vertical bar is intentionally invalid. Process-closure values must come from actual checks. The script does not infer either the preparation decision or process release. A recommendation to revert is evidence, not a source mutation or authorization to package superseded heads as final.

Run only when authorized:

`node work/world-finish/round3/aggregate-walk-final.mjs --execute --decision=walk-preparation-decision-final.json`

Without `--execute` it only describes requirements, without reading evidence or writing output. Execution creates fresh `R3-WALK-INPUT-FRAMES-FUNCTIONAL.json` and `.md` and refuses existing files. It reads exact Round2 entry costs and every previous input sample directly from the original d78064f raw proof. It retains full-precision current distributions, event/handler/render intervals, strict frame results, long stalls/tails, original-scene ownership, door/Escape/restoration evidence and all raw paths. Phone latency remains informational; physical one-hand comfort and human comprehension remain unproven. Sanitized or rounded input is not accepted as a substitute for the selected original proofs.
