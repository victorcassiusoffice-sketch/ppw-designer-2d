# Round 3 bounded startup diagnostic

Executed once on 29 October 2026, 11:35–11:36 MU. Six cases, no retries. Exact preview health before and after: Walk `9a1cb7e9d292300bdac253526af32d2722099c17`, Site `23d1aa9e8f7760d72b52d2cc19950b02ac21e77d`. These are documentation-only successors of application heads `d78064f9f57ed6e060d9782036b4a8b7a7e95451` and `b3727b1d20fff6be3ac448dfe8bf11e9261ad500`.

Evidence: `startup-diagnostic/r3-startup-v1/report.json`, six complete `.trace.json.gz` files and two loader screenshots. Harness: `startup-diagnostic.mjs`; console: `startup-diagnostic-v1.log`. Process exit0, all six contexts closed, four browser processes closed, shared performance lock absent. No application source changed. Prototype wrappers, tracing, process reuse and deliberate resource aborts make these diagnostic results unsuitable as replacements for the formal fresh-browser timing rows.

## Results retained in full

All values are milliseconds from navigation unless noted. Cold/warm full cases use the same complete route and viewport. Warm means a fresh context in the preceding browser process; network/process state is not controlled to be identical.

| Branch/case | responseStart | responseEnd | loading DOM | FCP | getContext duration | native size setter total | first picture |
|---|---:|---:|---:|---:|---:|---:|---:|
| Walk cold full | 3105.4 | 3922.1 | 3997.7 | 4088 | 355.7 | 29.5 | 7781.0 |
| Walk warm process | 334.5 | 583.6 | 622.9 | 652 | 34.6 | 5.3 | 2641.9 |
| Walk cold loader only | 344.6 | 637.0 | 674.1 | 1116 | none | none | intentionally absent |
| Site cold full | 369.7 | 1163.4 | 1204.3 | 1276 | 151.7 | 1011.5 | 6115.2 |
| Site warm process | 330.8 | 611.4 | 649.5 | 676 | 44.1 | 5.6 | 3125.0 |
| Site cold loader only | 364.5 | 665.5 | 708.4 | 772 | none | none | intentionally absent |

All four full cases have zero page errors, console errors or attempted writes. Each loader-only intervention aborts30 external subresources and retains30 blocked-resource console errors plus one failed dynamic-import page error. Those expected intervention errors are not application successes or filtered evidence. All six documents remain visible. At FCP the HTML loading panel is present and React root has zero children. Both post-FCP screenshots visibly show that panel. Every trace reports `dataLossOccurred:false`; peak buffer use is below21%.

## Native renderer attribution

The existing renderer construction remains at `src/components/three/ThreeStage.tsx:1013`; first preparation starts around795 and existing layout/density sizing around1562. The application passes antialias true, alpha false and high-performance preference. The native context argument reports alpha true because installed Three r186 explicitly sets `contextAttributes.alpha:true` in `node_modules/three/src/renderers/WebGLRenderer.js:389`; this diagnostic did not change it. Context, width and height wrappers forward original arguments and results unchanged.

Walk cold full: getContext6363.4–6719.1 (355.7), then width300→1167 at7202.6–7204.1 (1.5) and height150→596 at7204.1–7232.1 (28.0). These are inside the6358.0–7245.0 long task (887ms), followed by firstPrepareStart7279.7. The native calls account for385.2ms, leaving about502ms in other work; it is not solely context creation. Warm process:1855.6–2381.6 long task526ms, context34.6ms and setters5.3ms. The context cost falls substantially, but substantial other main-thread setup remains.

Site cold full: getContext3453.7–3605.4 (151.7). Initial width300→1167 at4014.5–4394.7 (380.2), height150→544 at4394.9–4398.2 (3.3), inside3451.5–4398.5 long task947ms. FirstPrepareStart4421.1 then a real later layout resize sets width1167→1167 at4542.2 (0ms) and height544→596 at4542.2–5170.2 (628ms). That height setter accounts for nearly all of4538.5–5170.5 long task632ms. FirstPrepared5172.7, firstPicture6115.2. Warm process has a single1167×596 target allocation and44.1ms context plus5.6ms setters. The cold second resize is observable but its layout trigger was not instrumented, so do not call it redundant or remove it. The already-tested atomic initial sizing cannot prevent a genuine later layout change.

These intervals justify investigating the layout trigger and the uninstrumented renderer/scene setup if further startup work is authorized. They do not justify reduced quality, antialias/power changes, an earlier throwaway context, freezing dimensions or moving feature code into the early closure.

## Loading paint and delivery

The Walk loader-only case reproduces a441.9ms DOM→FCP gap with no WebGL context, successful external app/CSS/font resource, or main-thread long task. Its trace contains a CrGpuMain `RasterDecoderImpl::DoRasterCHROMIUM` span approximately661.15–1043.53ms (382.38ms), inside a391.22ms GPU scheduler task. This overlaps most of that gap and supports a raster/compositor cost in this diagnostic. It is stronger evidence than attributing the gap to a late stylesheet; it still does not identify every formal run or establish what exact layer each GPU event rasterized. Site loader-only DOM→FCP is63.6ms. No repeated sampling was used to select a result.

The extreme Walk cold-full delivery delay is not a3s TLS/origin delay. NavigationTiming DNS starts2744.0ms; connect2744.1–2970.1 is226.0ms, request2970.3→response3105.4 is135.1ms. The trace includes a PAC/proxy-resolver `StartJob` task13.18–2729.31ms on `PAC thread #0`, before DNS/connect. Response body transfer then lasts816.7ms. This is evidence of a pre-connect browser/system proxy phase in this run, not proof that all earlier formal slow rows have that cause. Do not change network/hosting/proxy/browser launch settings to make the result pass.

Site cold full starts receiving at369.7 but finishes1163.4ms, before loading DOM1204.3. Client rendering cannot show this particular panel before the required body bytes arrive. Connection setup, request-to-response, body transfer and post-body paint must remain distinct. No speculative stylesheet-media change follows from these cases.

## Scope and next step

The bounded experiment resolves that native context/buffer work and browser raster work can contribute materially; it does not provide a universally safe startup patch. The formal absolute desktop/paint gates remain open. Keep the full raw evidence and report the limits. The separately approved isolated plumbing CSS change can proceed after a controlled before-build freezes all other edits; it addresses Lighthouse, not these3D timing gaps.

Harness preparation fixed bounded state/trace-stream reads, setup-failure recording, partial-state retention and cleanup status before this first execution. Syntax checking passed. An initial read-only health probe used an invalid Node `-e` option ordering and exited before any request; corrected ordering then verified both ready heads. There was no failed/repeated measured browser case.
