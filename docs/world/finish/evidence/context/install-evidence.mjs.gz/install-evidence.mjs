import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { ROOT, REPOS } from './run-config.mjs';
const chat = path.resolve(ROOT, '../../..');
const packageRoot = path.join(chat, 'outputs/world-finish/round-3');
const archiveRoot = path.join(chat, 'outputs/world-finish/round-2-published');
const receipt = path.join(ROOT, 'evidence-installation.json');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function inventory(root) {
  const rows = [];
  function visit(directory) {
    for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
      const full = path.join(directory, item.name);
      if (item.isSymbolicLink()) throw Error('Refusing linked evidence: ' + full);
      if (item.isDirectory()) visit(full);
      else if (item.isFile()) rows.push({ path: path.relative(root, full).replaceAll('\\', '/'), bytes: fs.statSync(full).size, sha256: hash(full) });
    }
  }
  visit(root); return rows.sort((a,b) => a.path.localeCompare(b.path));
}
const identical = (a,b) => JSON.stringify(a) === JSON.stringify(b);
if (!process.argv.includes('--install')) throw Error('Explicit --install required after final package review');
if (fs.existsSync(archiveRoot) || fs.existsSync(receipt)) throw Error('Preserve existing archive/receipt; inspect before any retry');
if (!/Round 3 evidence/i.test(fs.readFileSync(path.join(packageRoot, 'REPORT.md'), 'utf8'))) throw Error('Wrong package');
const packageRows = inventory(packageRoot), packageBytes = packageRows.reduce((sum,row) => sum + row.bytes, 0);
const planned = ['walk','site'].map(branch => {
  const repo = fs.realpathSync(REPOS[branch]);
  const expected = path.resolve(repo, 'docs/world/finish/evidence');
  const destination = fs.realpathSync(expected);
  if (destination.toLowerCase() !== expected.toLowerCase() || !destination.startsWith(repo + path.sep)) throw Error('Unexpected resolved evidence target: ' + destination);
  const before = inventory(destination), docs = inventory(path.join(repo, 'docs/world'));
  const retainedBytes = docs.filter(row => !row.path.startsWith('finish/evidence/')).reduce((sum,row) => sum + row.bytes, 0);
  if (retainedBytes + packageBytes >= 5_000_000) throw Error('Combined budget would fail for ' + branch);
  return { branch, repo, destination, before, retainedBytes, archive: path.join(archiveRoot,branch) };
});
// Archive and verify BOTH branches before replacing either exact resolved target.
for (const entry of planned) {
  fs.mkdirSync(path.dirname(entry.archive), { recursive: true });
  fs.cpSync(entry.destination, entry.archive, { recursive: true, errorOnExist: true, force: false });
  if (!identical(inventory(entry.archive),entry.before)) throw Error('Archive verification failed: ' + entry.branch);
  fs.writeFileSync(path.join(archiveRoot,entry.branch + '-manifest.json'), JSON.stringify({ source:entry.destination, archivedAt:new Date().toISOString(), files:entry.before },null,2) + '\n', { flag:'wx' });
}
const records = [];
for (const entry of planned) {
  if (fs.realpathSync(entry.destination) !== entry.destination || !identical(inventory(entry.destination),entry.before)) throw Error('Target changed after archival');
  if (!identical(inventory(entry.archive),entry.before)) throw Error('Archive changed after verification');
  fs.rmSync(entry.destination,{recursive:true});
  fs.cpSync(packageRoot,entry.destination,{recursive:true,errorOnExist:true,force:false});
  if (!identical(inventory(entry.destination),packageRows)) throw Error('Installed package mismatch');
  const allWorldDocsBytes = inventory(path.join(entry.repo,'docs/world')).reduce((sum,row) => sum + row.bytes,0);
  if (allWorldDocsBytes >= 5_000_000) throw Error('Combined installed budget exceeded');
  records.push({ branch:entry.branch, archive:entry.archive, destination:entry.destination, packageBytes, allWorldDocsBytes, archivedFiles:entry.before.length, installedFiles:packageRows.length });
}
fs.writeFileSync(receipt,JSON.stringify({at:new Date().toISOString(),records},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(records,null,2));
