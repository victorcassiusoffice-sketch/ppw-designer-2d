# Prepared Walk Round3 work — not executed

Prepared after Round2 at published head `d78064f9f57ed6e060d9782036b4a8b7a7e95451`. No repository source was changed and no browser, build, test or network request was run for this preparation. Root must announce Round3 start and grant the appropriate lease before execution.

Update after Round3 authorization: runtime preparation is implemented in the four scoped runtime/test files and passes54/54 focused tests. The independent Site agent reviewed it without finding an actionable issue. The two bounded baseline phone diagnostics have completed and both retain the door failure; see `R3-PHONE-DOOR-DIAGNOSTIC.{json,md}`. Controls-copy work belongs to the Site agent and is now present only in `WalkMode.tsx` plus `controlsCopy.test.tsx`, with its checks awaiting root coordination; it does not change CSS/layout. Earlier preparation text below records the plan rather than claiming these later actions had already happened.

## Native phone door diagnostic

Scratch entry point: `harness/walk-functional-phone-door-probe.mjs`. It uses copied `harness/lib.mjs` and `run-config.mjs`, the same exclusive performance lock, pinned preview hostname, fresh D3D11 Chromium, 390×844 touch emulation, read-only network policy and exact before/after health checks.

Planned command, only after a browser lease:

```text
node work/world-finish/round3/harness/walk-functional-phone-door-probe.mjs walk --expected=<40-character-published-head> --label=<unique-round3-label>
```

The probe retains the native movement/stop/restoration, controls and Exit checks from Round2 v2. It adds:

- Native pointer/touch events with trusted flag, target, event path and coordinates; actual click capture/bubble events and status snapshots.
- A status MutationObserver records published `data-status` changes and door text, including the two-second safety-rejection state.
- Before each door tap: button bounds, disabled state, computed pointer/visibility state, centre point and `elementFromPoint` hit path. The CDP tap uses that measured centre.
- Immediate post-tap status, then at most 2500 ms to observe expected state or safety rejection. Outcomes remain distinct: state changed, safety rejected, click not observed, or no state change.
- Only a delivered click with a safety rejection permits a native backward retreat of 0.20 m (maximum 2000 ms) and retry. At most two retreats/retries per open/close action; no collision or pose override. A missing click, unchanged state, blocked retreat or lost prompt stops that check and preserves all evidence.
- Door opening/closing must still retain its expected prompt after the normal swing interval. Every attempt and failure is saved before assertions; screenshots occur only for functional evidence, never input/FPS measurements.

All one-contact checks remain emulation evidence. This diagnostic does not replace either Round2 failure or the unchanged formal zero-settle input and strict frame protocols. Internal retained-door identity and angles are not exposed by current production diagnostics; the harness records the public status and visible result rather than inventing those values.

## Reversible selected-scene compilation experiment

Proposed production scope: `src/walk/runtime.ts` only, entirely deferred. Supporting tests: new `src/walk/__tests__/runtimePreparation.test.ts`, plus `compileAsync` mock support in our existing `runtime.test.ts` and `runtimeFrameMeasurement.test.ts`. No `ThreeStage`, early renderer, material quality, model asset, snapshot or store changes.

The private stage compiles before the selected avatar and hinged door materials are attached. `load()` currently attaches them, starts idle animation and immediately sets ready. Calling the existing actual renderer's `compileAsync(host.scene, actualWalkCamera)` after attachment is a plausible preparation experiment. The Round2 GPU flush is not established as shader compilation; preparation may leave the observed stall unchanged.

Use the normal spawn actor pose, idle animation pose, door transforms and initial Walk camera/projection. Extract the existing camera/door synchronization code only as needed to reuse it before compilation and in normal frames; do not replace its formulas or advance simulation time. Keep the same private renderer/context and full scene. Architectural lighting, fog type, color space, tone mapping and shadow configuration already exist. The existing render handle changes fill/sky positions and fog distances during rendering; those values do not justify changing material/program features or renderer quality for this experiment.

Hold readiness, controls/status and the first regular RAF until the real compile promise completes. Include preparation in the existing Start→ready entry metric. Add no arbitrary sleep, frame exclusion or post-ready input wait.

The existing 20-second abort timer only directly aborts fetch. Race pending compilation against that same finite abort/deadline, remove listeners and timers, handle synchronous compile throws and promise rejection, and recheck disposed/aborted after awaiting. A late resolve/reject after Exit must never start RAF or publish status. The existing modal error/release path must remain the single owner of disposal; late completion must not double-dispose scene materials or release the host again.

Meaningful tests should cover: exact renderer/scene/camera and selected attached avatar; no readiness/RAF before preparation completes; entry duration includes preparation; same camera/pose/material/visibility/shadow configuration at the first frame; synchronous throw, rejection, deadline and disposal during pending work; handled late resolve/reject; exactly-once host/material cleanup; no saved property or editing-camera mutation. Existing input and frame measurement lifecycle tests must continue unchanged apart from realistic compile mocks.

Measure the candidate with the unchanged zero-settle input protocol, entry latency, strict FPS and functional restoration. Retain failure samples; revert the experiment if it adds startup cost without useful evidence.

## Device-specific controls copy proposal

Proposed files: `src/walk/WalkMode.tsx`, `src/walk/walk.css`, and focused additions to our `src/walk/__tests__/chooser.test.tsx` (or a small `controlsCopy.test.tsx` if clearer). These are all deferred.

- Replace the unmeasured promise “Ready in ten seconds” with “How to walk”.
- On touch/coarse-pointer layouts, show “Use the pad to move and turn. Drag the view to look. Tap a door button when close.” Use “Tap Exit walk to return to your design” instead of keyboard Escape advice in the persistent phone hint.
- Keep keyboard/mouse instructions and actual Esc/E/V shortcuts available for desktop or hybrid users. Phone door buttons need no visible E badge; preserve their accessible action name.
- Controls help should lead with the device's actual input method. Existing run/view/Exit buttons remain visibly named. No claim that this proves ten-second human comprehension or physical thumb comfort.

Any reach/layout relocation is a separate usability experiment requiring actual overlap, hit-target and native-input evidence; copy changes alone do not satisfy a physical one-hand study.
