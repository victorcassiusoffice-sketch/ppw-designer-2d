// Six bounded diagnostic cases. NEVER substitute these for formal timing rows.
// Do not run until Round 3 is open and the browser/CPU lease is explicitly held.
import { mkdirSync, writeFileSync, appendFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { launch, DEVICES, health, TARGETS, LABEL } from '../round2/harness/lib.mjs';

if (!process.argv.some(arg => arg.startsWith('--label=r3-startup-'))) throw Error('Use a fresh --label=r3-startup-...');
const expected = Object.fromEntries(['walk', 'site'].map(branch => {
  const sha = process.argv.find(arg => arg.startsWith(`--${branch}-sha=`))?.split('=')[1];
  if (!/^[a-f0-9]{40}$/.test(sha ?? '')) throw Error(`Pass exact --${branch}-sha`);
  return [branch, sha];
}));
const output = resolve(dirname(fileURLToPath(import.meta.url)), 'startup-diagnostic', LABEL);
if (existsSync(output)) throw Error('Never overwrite a prior diagnostic label');
mkdirSync(output, { recursive: true });
const report = { at: new Date().toISOString(), label: LABEL, expected, diagnosticOnly: true,
  limits: { cases: 6, caseNavigationTimeoutMs: 25000, stateCaptureTimeoutMs: 2000, traceFlushTimeoutMs: 5000, traceBufferKiB: 16384, traceFileByteCap: 33554432, retries: 0 },
  method: 'Desktop only, unchanged native D3D11/pinned hosts/viewport/quality. Per branch: cold full route, same browser process with fresh context full route, separate cold browser loader-only counterfactual. Loader-only aborts external subresources while preserving the real document/inline HTML. These changed conditions, prototype timing wrappers and trace overhead invalidate formal performance comparison. Warm process may retain more than GPU state; do not assume transport is unchanged.',
  applicationSourceHeads: { walk: 'd78064f9f57ed6e060d9782036b4a8b7a7e95451', site: 'b3727b1d20fff6be3ac448dfe8bf11e9261ad500' }, healthBefore: [], cases: [], healthAfter: [] };
const save = () => writeFileSync(resolve(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
for (const branch of ['walk', 'site']) {
  const result = await health(branch); report.healthBefore.push(result);
  if (result.body.commit !== expected[branch] || result.body.env !== 'preview') { save(); throw Error('Wrong head/environment: ' + branch); }
}

async function bounded(promise, ms, label) {
  let timer;
  try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(Error(`${label} exceeded ${ms}ms`)), ms); })]); }
  finally { clearTimeout(timer); }
}
async function readTrace(cdp, file) {
  const deadline = Date.now() + 5000;
  const remaining = () => Math.max(1, deadline - Date.now());
  let listener;
  const completed = new Promise(accept => { listener = event => accept(event); cdp.once('Tracing.tracingComplete', listener); });
  let event;
  try { [, event] = await bounded(Promise.all([cdp.send('Tracing.end'), completed]), remaining(), 'Trace stop'); }
  finally { cdp.off('Tracing.tracingComplete', listener); }
  if (!event.stream) throw Error('Trace returned no stream');
  writeFileSync(file, Buffer.alloc(0));
  let bytes = 0;
  try {
    for (;;) {
      const item = await bounded(cdp.send('IO.read', { handle: event.stream, size: 65536 }), remaining(), 'Trace stream read');
      const data = item.base64Encoded ? Buffer.from(item.data, 'base64') : Buffer.from(item.data);
      bytes += data.length;
      if (bytes > 33554432) throw Error('Trace file exceeded 32MiB; retained partial stream');
      appendFileSync(file, data);
      if (item.eof) break;
    }
  } finally { await bounded(cdp.send('IO.close', { handle: event.stream }), 1000, 'Trace stream close'); }
  return { bytes, dataLossOccurred: event.dataLossOccurred ?? null, streamFormat: event.streamFormat, streamCompression: event.streamCompression };
}

const captureState = page => bounded(page.evaluate(() => ({ timeOrigin: performance.timeOrigin, navigation: performance.getEntriesByType('navigation')[0]?.toJSON(), paints: performance.getEntriesByType('paint').map(entry => entry.toJSON()), ...window.__startupNativeDiagnostic,
  picture: { ...document.querySelector('[data-testid="wallpaint-3d-gl"]')?.dataset }, resources: performance.getEntriesByType('resource').map(entry => entry.toJSON()) })), 2000, 'State capture');

async function runCase(browser, branch, mode) {
  const row = { branch, mode, expectedHead: expected[branch], errors: [], consoleErrors: [], blockedWrites: [], abortedSubresources: [], requests: [], traceBuffer: [] };
  report.cases.push(row); save();
  const caseStarted = Date.now();
  const remaining = () => Math.max(1, 25000 - (Date.now() - caseStarted));
  let context, page, browserCdp, network, tracing = false;
  try {
  context = await bounded(browser.newContext(DEVICES.desktop), remaining(), 'Context setup');
  page = await bounded(context.newPage(), remaining(), 'Page setup');
  browserCdp = await bounded(browser.newBrowserCDPSession(), remaining(), 'Browser CDP setup');
  network = await bounded(context.newCDPSession(page), remaining(), 'Page CDP setup');
  const requests = new Map();
  const loaderOnly = mode === 'cold-loader-only';
  await context.route('**/*', route => {
    const request = route.request();
    if (!['GET','HEAD','OPTIONS'].includes(request.method())) { row.blockedWrites.push({ url: request.url(), method: request.method() }); return route.abort('blockedbyclient'); }
    if (loaderOnly && request.resourceType() !== 'document') { row.abortedSubresources.push({ url: request.url(), type: request.resourceType() }); return route.abort('blockedbyclient'); }
    return route.continue();
  });
  page.on('pageerror', error => row.errors.push(String(error)));
  page.on('console', message => { if (message.type() === 'error') row.consoleErrors.push(message.text()); });
  await context.addInitScript(() => {
    localStorage.setItem('ppw_designer_coach_v1', '1');
    const state = window.__startupNativeDiagnostic = { native: [], longTasks: [], loadingSeen: null, fcp: null,
      visibility: [{ at: performance.now(), state: document.visibilityState }], originalGetContext: HTMLCanvasElement.prototype.getContext.name };
    document.addEventListener('visibilitychange', () => state.visibility.push({ at: performance.now(), state: document.visibilityState }));
    try { new PerformanceObserver(list => { for (const entry of list.getEntries()) state.longTasks.push({ start: entry.startTime, duration: entry.duration }); }).observe({ type: 'longtask', buffered: true }); } catch {}
    new PerformanceObserver(list => { for (const entry of list.getEntries()) if (entry.name === 'first-contentful-paint') state.fcp = { at: entry.startTime, observedAt: performance.now(), htmlPresent: !!document.getElementById('designer-startup'), reactChildren: document.getElementById('root')?.childElementCount ?? 0 }; }).observe({ type: 'paint', buffered: true });
    // Preserve the formal 30ms visibility sampling instead of adding an rAF
    // loop that could itself change the browser's frame scheduling.
    const visible = selector => [...document.querySelectorAll(selector)].some(element => { const box = element.getBoundingClientRect(), style = getComputedStyle(element); return box.width > 0 && box.height > 0 && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0'; });
    const poll = setInterval(() => {
      const html = visible('#designer-startup'), combined = visible('[data-testid="loading-3d"]');
      visible('[data-testid="loading-3d"]:not(#designer-startup)');
      if ((html || combined) && state.loadingSeen === null) state.loadingSeen = performance.now();
      const picture = Number(document.querySelector('[data-first-picture-ms]')?.getAttribute('data-first-picture-ms'));
      if (picture > 0) clearInterval(poll);
    }, 30);
    setTimeout(() => clearInterval(poll), 25000);
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(...args) {
      if (this.dataset.testid !== 'wallpaint-3d-gl') return Reflect.apply(original, this, args);
      const item = { kind: 'getContext', type: args[0], attributes: args[1] ?? null, start: performance.now(), width: this.width, height: this.height };
      const index = state.native.push(item) - 1;
      performance.mark(`diag-native-${index}-start`);
      try { const result = Reflect.apply(original, this, args); item.returned = !!result; return result; }
      finally { item.end = performance.now(); item.duration = item.end - item.start; performance.mark(`diag-native-${index}-end`); }
    };
    for (const axis of ['width','height']) {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, axis);
      Object.defineProperty(HTMLCanvasElement.prototype, axis, { ...descriptor, set(value) {
        if (this.dataset.testid !== 'wallpaint-3d-gl') return descriptor.set.call(this, value);
        const item = { kind: 'drawing-buffer-set', axis, value, start: performance.now(), width: this.width, height: this.height };
        const index = state.native.push(item) - 1; performance.mark(`diag-native-${index}-start`);
        try { return descriptor.set.call(this, value); }
        finally { item.end = performance.now(); item.duration = item.end - item.start; performance.mark(`diag-native-${index}-end`); }
      } });
    }
  });
  await network.send('Network.enable');
  network.on('Network.requestWillBeSent', event => {
    const item = { id: event.requestId, url: event.request.url, method: event.request.method, type: event.type, wallTime: event.wallTime, timestamp: event.timestamp, initiator: event.initiator };
    requests.set(event.requestId, item); row.requests.push(item);
  });
  network.on('Network.responseReceived', event => {
    const item = requests.get(event.requestId); if (!item) return;
    Object.assign(item, { status: event.response.status, protocol: event.response.protocol, timing: event.response.timing, fromDiskCache: event.response.fromDiskCache, fromServiceWorker: event.response.fromServiceWorker });
    if (event.type === 'Document') item.deliveryHeaders = Object.fromEntries(Object.entries(event.response.headers).filter(([key]) => /^(date|server|server-timing|x-vercel-cache|x-vercel-id|age|cache-control|content-encoding)$/i.test(key)));
  });
  network.on('Network.loadingFinished', event => { const item = requests.get(event.requestId); if (item) Object.assign(item, { finished: event.timestamp, bytes: event.encodedDataLength }); });
  network.on('Network.loadingFailed', event => { const item = requests.get(event.requestId); if (item) item.failure = event.errorText; });
  browserCdp.on('Tracing.bufferUsage', event => row.traceBuffer.push(event));
    const available = (await bounded(browserCdp.send('Tracing.getCategories'), remaining(), 'Trace categories')).categories;
    const wanted = ['devtools.timeline', 'blink.user_timing', 'loading', 'cc', 'gpu', 'viz', 'toplevel', 'v8'];
    row.traceCategories = wanted.filter(category => available.includes(category));
    row.missingTraceCategories = wanted.filter(category => !available.includes(category));
    await browserCdp.send('Tracing.start', { transferMode: 'ReturnAsStream', streamFormat: 'json', streamCompression: 'gzip', bufferUsageReportingInterval: 1000,
      traceConfig: { recordMode: 'recordUntilFull', traceBufferSizeInKb: 16384, enableSampling: false, enableSystrace: false, includedCategories: row.traceCategories } });
    tracing = true;
    await page.goto(TARGETS[branch] + '/demo?view=3d&pitch=1', { waitUntil: 'domcontentloaded', timeout: remaining() });
    await page.waitForFunction(loader => loader ? !!window.__startupNativeDiagnostic?.fcp : Number(document.querySelector('[data-testid="wallpaint-3d-gl"]')?.getAttribute('data-first-picture-ms')) > 0, loaderOnly, { timeout: remaining() });
    row.state = await captureState(page);
    if (loaderOnly) await page.screenshot({ path: resolve(output, `${branch}-${mode}-loader.png`), timeout: 2000 });
  } catch (error) {
    row.failure = String(error);
    if (page) { try { row.partialState = await captureState(page); } catch (captureError) { row.stateFailure = String(captureError); } }
  }
  finally {
    if (tracing) {
      try { row.trace = await readTrace(browserCdp, resolve(output, `${branch}-${mode}.trace.json.gz`)); }
      catch (error) { row.traceFailure = String(error); }
    }
    try { if (context) await bounded(context.close(), 3000, 'Context close'); row.contextClosed = true; } catch (error) { row.cleanupFailure = String(error); }
    try { if (browserCdp) await bounded(browserCdp.detach(), 2000, 'Browser CDP detach'); } catch (error) { row.detachFailure = String(error); }
    row.endedAt = new Date().toISOString(); row.elapsedMs = Date.now() - caseStarted; save();
  }
  console.log(JSON.stringify({ branch, mode, responseStart: row.state?.navigation?.responseStart, fcp: row.state?.fcp, native: row.state?.native, failure: row.failure ?? null }));
}

try {
  for (const branch of ['walk','site']) {
    const browser = await launch();
    try { await runCase(browser, branch, 'cold-full'); await runCase(browser, branch, 'warm-process-fresh-context-full'); }
    finally { await bounded(browser.close(), 5000, 'Browser close'); }
    const isolatedBrowser = await launch();
    try { await runCase(isolatedBrowser, branch, 'cold-loader-only'); }
    finally { await bounded(isolatedBrowser.close(), 5000, 'Isolated browser close'); }
  }
} finally {
  for (const branch of ['walk','site']) { try { report.healthAfter.push(await health(branch)); } catch (error) { report.healthAfter.push({ branch, failure: String(error) }); } }
  report.healthStable = report.healthAfter.every(item => item.body?.commit === expected[item.target] && item.body?.env === 'preview');
  report.endedAt = new Date().toISOString(); save();
}
if (!report.healthStable || report.cases.length !== 6 || report.cases.some(row => row.failure || row.traceFailure || row.cleanupFailure || row.detachFailure)) process.exitCode = 1;
