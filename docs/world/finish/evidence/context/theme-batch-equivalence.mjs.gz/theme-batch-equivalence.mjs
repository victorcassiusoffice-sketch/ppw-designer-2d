import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { launch, TARGETS, LABEL } from '../round2/harness/lib.mjs';
const repo = 'C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-walk';
const expected = '2e90b2a7c96f63f58ee9293dd9c791924f95a9f6';
if (LABEL !== 'r3-theme-batch-equivalence-v1') throw Error('Fresh diagnostic label required');
const out = resolve(dirname(fileURLToPath(import.meta.url)), 'theme-tests', LABEL);
if (existsSync(out)) throw Error('Existing evidence');
mkdirSync(out, { recursive: true });
const ts = createRequire(repo + '/package.json')('typescript');
const relative = 'tests/e2e/plumbing-theme-contrast.spec.ts';
const oldSource = execFileSync('git', ['show', expected + ':' + relative], { cwd: repo, encoding: 'utf8' });
const newSource = readFileSync(resolve(repo, relative), 'utf8');
writeFileSync(resolve(out, 'old-test-source.ts'), oldSource);
writeFileSync(resolve(out, 'new-test-source.ts'), newSource);
async function helper(source, name) {
  const ast = ts.createSourceFile('test.ts', source, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
  const node = ast.statements.find(item => ts.isFunctionDeclaration(item) && item.name?.text === name);
  if (!node) throw Error('Missing helper ' + name);
  const compiled = ts.transpileModule('export ' + node.getText(ast), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
  return (await import('data:text/javascript;base64,' + Buffer.from(compiled).toString('base64')))[name];
}
const oldContrast = await helper(oldSource, 'contrast'), newContrasts = await helper(newSource, 'contrasts');
const selector = '.sales-content :is(h1, h2, h3, p, span, strong, em, a, summary, label, li, figcaption, button)';
const report = { expected, label: LABEL, diagnostic: true, normalSourceApp: true, candidateTestUncommitted: true, unchangedTimeoutMs: 60000, unchangedThreshold: 4.5, cases: [] };
const save = () => writeFileSync(resolve(out, 'report.json'), JSON.stringify(report, null, 2));
const browser = await launch();
try {
  for (const [brand, theme, chapter] of [['ppw', 'ivory', 1], ['ppw', 'ocean', 1], ['olb', 'slate', 2], ['ppw', 'slate', 5]]) {
    const row = { brand, theme, chapter: chapter + 1, groups: [], writes: [], errors: [] };
    report.cases.push(row);
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    page.on('pageerror', error => row.errors.push(String(error)));
    await context.route('**/*', route => {
      if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) { row.writes.push(route.request().url()); return route.abort(); }
      return route.continue();
    });
    const compare = async (name, locator, pseudo = null, ownText = false) => {
      const old = [], identities = [];
      for (let index = 0, count = await locator.count(); index < count; index++) {
        const element = locator.nth(index);
        if (ownText) {
          if (!await element.isVisible() || await element.evaluate(node => !!node.closest('[aria-hidden="true"]'))) continue;
          if (!await element.evaluate(node => Array.from(node.childNodes).some(child => child.nodeType === 3 && child.textContent?.trim()))) continue;
        }
        old.push(await oldContrast(element, pseudo));
        identities.push(await element.evaluate(node => ({ tag: node.tagName, className: node.className, text: node.textContent?.trim(), name: node.getAttribute('name') })));
      }
      const fresh = await newContrasts(ownText ? locator.filter({ visible: true }) : locator, pseudo, ownText);
      const same = JSON.stringify(old) === JSON.stringify(fresh);
      row.groups.push({ name, pseudo, oldCount: old.length, newCount: fresh.length, exactReadingEquality: same, identities, old, new: fresh });
      save();
      if (!same || !old.length) throw Error('Old/new mismatch: ' + name);
    };
    try {
      await page.goto(TARGETS.walk + '/api/healthcheck');
      row.healthBefore = JSON.parse(await page.locator('body').innerText());
      if (row.healthBefore.commit !== expected) throw Error('Wrong app head');
      await page.goto(TARGETS.walk + '/pitch/plumbing?brand=' + brand);
      await page.locator('details.locale-theme-controls > summary').click();
      await page.locator('.theme-skin-card--' + theme).click();
      await page.locator('.locale-theme-controls__heading button').click();
      await page.locator('[role="tab"]').nth(chapter).click();
      if (chapter === 2) await page.locator('.sales-details summary').click();
      if (chapter === 5) { await page.locator('form.pitch-enquiry').waitFor(); await page.locator('.pitch-enquiry .pitch-segment button').last().click(); }
      await page.evaluate(async () => { await document.fonts.ready; await Promise.all(document.getAnimations().filter(animation => animation.effect?.getTiming().iterations !== Infinity).map(animation => animation.finished.catch(() => {}))); });
      await compare('all visible own-text nodes', page.locator(selector), null, true);
      await compare('tab numbers including selected', page.locator('.sales-tabs button span'));
      if (chapter === 1) await compare('generated counters', page.locator('.sales-steps li'), '::before');
      if (chapter === 5) await compare('physical-meeting placeholders', page.locator('.pitch-enquiry :is(input,textarea)[placeholder]'), '::placeholder');
      await page.goto(TARGETS.walk + '/api/healthcheck');
      row.healthAfter = JSON.parse(await page.locator('body').innerText());
      if (row.healthAfter.commit !== expected) throw Error('Changed app head');
    } catch (error) { row.failure = String(error); }
    finally { await context.close(); row.contextClosed = true; save(); }
  }
} finally { await browser.close(); report.browserClosed = true; save(); }
report.passed = report.cases.length === 4 && report.cases.every(row => !row.failure && !row.writes.length && !row.errors.length && row.groups.every(group => group.exactReadingEquality));
save();
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.length, groups: report.cases.flatMap(row => row.groups).length, oldCount: report.cases.flatMap(row => row.groups).reduce((sum, group) => sum + group.oldCount, 0), failures: report.cases.map(row => row.failure ?? null) }));
if (!report.passed) process.exitCode = 1;
