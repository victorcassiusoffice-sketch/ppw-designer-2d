# Round 3 closure checklist — preparation, not a result

Prepared 29 October 2026 from the amended Finish instruction and the published Round 2 CURRENT, RUBRIC, DECISIONS, ROUNDS and LESSONS. Only this scratch file was written. No browser, test, build, source or repository-document change was made for this review.

Published Round 3 candidates supplied by the coordinator:

- Walk: `bf249b542152eb72870fdfa76426a03152c069c7`.
- Site: `6e57e7ed244a07572ffb2157210f650ba77be38f`.
- Expected base while PR #52 remains open: `56d852d1f2f5d7342b9e02194964d6b998c795c7`, its normal preview and controlled build.

Exact current-head formal outcomes are **pending**. Publication is not measurement. This checklist must not turn historical or diagnostic evidence into a current-head pass.

## Counting rule

Finish section 2 allows up to ten rounds. An item that fails three consecutive completed real rounds is recorded OPEN in DECISIONS with the three attempts and the next idea, then work moves on from that item. Round 0, Fix 1, multiple diagnostic attempts within one round, and a repeated description of the same failure do not add rounds. A real intervening pass resets the failure streak. Do not retire an entire gate merely because one distinct item within it reaches three failures.

For missing human evidence, record three rounds in which the criterion remained unproven; do not call those three human studies or three failed engineering experiments. An OPEN disposition does not change a rubric 1 to 2 or a failed metric to PASS.

## Failure streaks to resolve only after Round 3 measurements

| Distinct item | Finish Round 1 | Finish Round 2 | If still unmet at Round 3 closure |
|---|---|---|---|
| B: Walk laptop median first picture under 3 s | FAIL: wall/canvas 5,700/5,183.5 ms | FAIL: 4,299/4,165.9 ms | Third consecutive failure; record three measurements, attempted repairs and next idea as OPEN. |
| B: Site laptop median first picture under 3 s | FAIL: wall/canvas 5,262/5,184.2 ms | FAIL: 4,838/4,718.8 ms | Third consecutive failure, separately from Walk. |
| B: loading panel actually painted within 1 s | FAIL: all 20 candidate FCPs exceeded 1 s | FAIL: only 9/20 candidate FCPs met 1 s | Third consecutive unmet campaign. Keep both branches/devices and every run; DOM visibility is not visible-paint proof. |
| F / input rubric: laptop input-to-movement under 50 ms | FAIL: third-person median 82.3 ms, max 110.9 ms | FAIL: third-person max 383.4 ms; separate diagnostic 444.9 ms | Third consecutive failure if any required current formal sample fails; a low median does not erase it. |
| D: first-time controls understood within 10 s | UNPROVEN, rubric 1 | UNPROVEN, rubric 1 | Third consecutive missing proof. New honest copy does not prove human comprehension; OPEN with an actual first-time participant test as next evidence. |
| D: physical one-hand reach/comfort | UNPROVEN, rubric 1 | UNPROVEN, rubric 1 | Third consecutive missing physical/human evidence. Keep separate from the functional phone-door issue below. |
| E/F / door rubrics: native phone Open/Close works reliably | Earlier functional checks passed; the later native delivery failure was not established in R1 | FAIL: native one-pointer v2 reaches the door, but Open tap does not produce Close | A repeated current failure is only the second consecutive failed round. Continue diagnosis in R4 if unresolved; no three-round exemption yet. |
| C: Site phone relative median within 10% | FAIL: wall +11.407%; canvas +7.817% passes | PASS: both paired definitions | Streak reset. A new R3 failure would be first, not third. |
| F: strict laptop 60 fps | FAIL: 58.6/59.7 | PASS: 60/60 | Streak reset. Keep all intervals and 1% lows; a new R3 failure would be first. |
| G / banner and print rubrics: complete banner on every A4 page | FAIL: disclaimer absent on both page 2s | PASS: all eight pages inspected; no overlap/clipping, minimum gap 17.99 mm | Streak reset. Fresh R3 PDFs must pass; earlier success alone is not current proof. |
| C: semantically valid early closure | R1 semantic pass later withdrawn for non-seam shader preparation | PASS after exact upstream shading restoration, +489/+940 gzip bytes | Streak reset. Recheck final emitted graph, scope and request timing; byte ceiling alone is insufficient. |

The R2 rubric has 25 scores of 2 and five scores of 1: input delay, doors clear/reachable, ten-second comprehension, one-hand phone use, and every door type. The two door scores share the same native-phone failure evidence; they are not two additional independent failed rounds. The one-hand line combines functional emulation with unmeasured physical comfort: split those limits explicitly in R3 notes rather than retiring the functional issue with the older physical-evidence streak.

Phone absolute startup passed R1 and R2. Chooser, print and other repaired criteria remain subject to current regression proof; they are not permanently waived.

## Native phone evidence: retain the distinction

The R3 baseline diagnostics used old head `9a1cb7e9d292300bdac253526af32d2722099c17`, whose application is unchanged from R2. Two native protocols failed to observe a click after trusted pointer/touch down/up on an enabled Open button; status stayed Open and `blocked=false`. Instrumented v5 then passed four native Open/Close actions across both views on that same application, with no retreat. Successful v5 had one connected button identity, correct hit targets, complete compatibility mouse/click events, no observed preventDefault calls and no prevented events.

These observations do not establish the suppression cause or a source fix. The failed 250.5 ms and 149.4 ms drag-release-to-tap gaps and successful 200.2 ms gap do not support a simple fixed waiting threshold. Instrumentation/fresh-run timing differs. Keep all failures and v5; do not substitute synthetic DOM clicks, add a hidden post-input wait or weaken collision safety. The first probe's separate final run-animation failure also remains in the inventory.

Current-head formal native phone evidence must be reported on its own. A pass proves that campaign's operation and may close the formal failed sample after explicit reliability review; it cannot retrospectively erase intermittent old-source failures or justify “door bug fixed” without causal/source evidence. A failure in the same criterion leaves the streak at two real rounds. Neither outcome proves physical thumb reach, comfort or first-time human understanding.

## A–J closure evidence checklist

- [ ] **A — integration/publication:** record round-start fetch/main/PR52 state, required forward-merge result, PR52 ancestry exit 0, exact remote tip equals local final commit, and no unpushed commits. PR bodies say includes PR #52 by merge and close #52 as superseded when this merges. No production merge, force push, main push or manual deploy.
- [ ] **B — absolute startup:** exact before/after preview health, five fresh runs per device, interleaved/pinned/no throttle; laptop median <3 s, phone <5 s. Retain wall/canvas definitions and actual loading pixels/FCP alongside legacy DOM milestone. Keep every slow row and classify failures without altering gates.
- [ ] **C — incremental cost:** controlled base/candidate builds use final Vite output after preload transforms. Report 28-file early closure raw/gzip and individually identify allowed lazy seams; <=1,024 gzip growth per PR. Zero feature implementation/dependency requests before first canvas render; same required request paths. Five fresh base/candidate pairs per device at pinned `216.198.79.3`, candidate medians <=110% of base for retained timing definitions. Every pair stays in report, including individually slower pairs.
- [ ] **D — rubric:** proof beside every current score; preserve five R2 low scores until their specific evidence improves or an OPEN limitation is recorded. No invented 3s; name reference behavior for any demonstrated 3. Controls-copy tests do not supply human evidence.
- [ ] **E — tester findings:** preserve tests for F2 door prompt, F4 decoded chooser/under-1-s opening, F5 visible Exit/pointer lock, F6 phone camera/head, F7 offline hint/no hidden credit, F8 preview-only live map/fail-closed production gate. Current browser checks must agree; explicitly label environment-negative simulation. Native phone intermittent delivery remains separate from the already-fixed retained-prompt behavior.
- [ ] **F — Walk:** unchanged zero-settle input protocol with every sample; Start-to-ready preparation cost separately; strict FPS windows, every frame interval and 1% lows. Native stairs/doors/camera/Exit checks, property and both camera restoration, zero writes. Current deferred compile experiment must not hide input delay behind arbitrary settle time or reduce rendering quality.
- [ ] **G — Site:** fresh exact-`6e57e7e` seven-case live/offline campaign at both sizes: successful explicit search, draw, keyboard edit, true Undo, survey traverse, tagged/unavailable values, visible map credits only where map draws, screen banner, focus/Escape and no overflow. Dedicated actual PDF campaign at both sizes, page-text/geometry oracle, all rendered pages visually inspected and separately recorded. Keep failed attempts, raw provider errors and attempted/blocked/transmitted write counts.
- [ ] **H — validation:** exact-head full suites and three type configurations; regression tests for each fix; scoped lint and any inherited full-lint findings accurately classified. Quality/secrets/Vercel green. Compare all inherited LH assertions at current exact heads, preserve thresholds/settings, and give a specific reason for every remaining inherited assertion. See exception handling below.
- [ ] **I — rules:** both static protected-source audit and all requested visible screens at end of round; no demo prices/name/phone/WhatsApp, only authorized Calendly link, unchanged estimator source/tests, permitted API paths/catch-all only, no migration/dependency/environment surprises, licences before shipment. Replace current evidence, archive failures, verify <5 MB per PR; do not accumulate prior-round packages in repository docs.
- [ ] **J — once-only currency review:** retain dated 28 Oct review and actual installed/provider versions; do not imply a fresh review or upgrade. J is once at start, not another unsolicited research requirement each round.
- [ ] **Close the round:** final source heads, health/CI runs and evidence heads agree; common CURRENT/RUBRIC/DECISIONS/ROUNDS/LESSONS and PR descriptions reflect actual results. Archive every failed attempt, avoid stale links, record qualified OPEN items only at a genuine three-round threshold. Continue any newly failing item or phone failure that has not reached its threshold. Do not call the candidate merge-ready while unresolved required gates are merely pending.

## Lighthouse: H is not a blanket all-green rule

R2 fixed 15 of the original 22 error assertions, leaving the same seven per PR and no new error IDs. Specific reasons are in `round2/lighthouse-classification-corrected.json`:

| Remaining inherited assertion | Count | Required treatment |
|---|---:|---|
| `csp-xss` and `total-byte-weight`, both routes, `minScore >= 0.9` against informative `score:null` audits | 4 | Record the exact informative/null mismatch. Content/headers cannot make these scored passes under unchanged settings. Do not lower thresholds or present them as unfixed security defects solely from this assertion. |
| Designer `valid-source-maps` | 1 | Existing no-public-maps/private Sentry policy forbids disclosure. Preserve policy and document this explicit exception. |
| Designer `unused-css-rules` | 1 | Initial-view coverage cannot safely establish that reachable Designer/theme/view styles are dead. Preserve full functionality; document the concrete unsafe pruning scope, not a generic “CSS is hard” reason. |
| Isolated plumbing `unused-css-rules` | 1 | R2 identified a safe bounded candidate, so do not pre-exempt it. Evaluate the R3 isolated pitch CSS with both themes/routes/form/brand behavior and unchanged primary output; classify actual current result. If remaining after three recorded real round attempts, OPEN must list those attempts and the next safe idea. |

H explicitly permits inherited assertions whose fixes cannot safely satisfy unchanged Designer rules. Those narrow exceptions do not require fabricating three code attempts or demanding all LH jobs turn green. Conversely, inherited status alone is not an excuse to leave a safe isolated fix undone. Disclose any new assertion or warning change separately. Do not collapse these seven causes into one blanket “Lighthouse exception.”

## Sources reviewed

- `C:/Users/Victor/Documents/PPW-Second-Brain/code runner/GPT-OLB-WORLD-FINISH-2026-10-28.md`, amendment and sections 1A–J / 2.
- Site `docs/world/ROUNDS.md`, completed R1/R2 and opened R3 blocks; `LESSONS.md` Finish1/2; `RUBRIC.md`; `CURRENT.md`; `DECISIONS.md` Finish result decisions. Historical earlier exceptions are superseded by the amended Finish rules.
- `round2/lighthouse-classification-corrected.json` and the original retained R2 evidence linked by those documents.
- `round3/R3-PHONE-DOOR-DIAGNOSTIC.md` and its retained three raw-result paths. Instrumented v5 is diagnostic old-source evidence, not current-head formal performance.

Prepared commands and pending browser lease remain with the coordinator. This file makes no R3 measured pass claim and does not modify the common closure documents.

## Superseding source-review note — 29 October, before final campaigns

The source heads named in this preparatory checklist are historical, unexecuted declarations. Final exact heads will be supplied by the coordinator after the E2E-only measurement repair. The later strict seam review also withdrew Round2's blanket semantic Gate C pass: deferred camera/light/fog/door behavior and geographic geometry/labels/arrow work have since been moved out of the early closure. The newer FAILURE-STREAK-REVIEW.md and semantic-gate-final-v4.json record this correction; R2 numeric/network/timing measurements remain unchanged. Do not use this checklist's older semantic PASS row to override that correction. Final v4 source builds measure +428/+1,014 gzip bytes, and final request/timing proof remains pending. The current Lighthouse comparison fixes 16/22 inherited assertions, with six specific inherited exceptions remaining; the isolated pitch unused-CSS assertion is now fixed. Every final claim still requires the selected final-head evidence.
