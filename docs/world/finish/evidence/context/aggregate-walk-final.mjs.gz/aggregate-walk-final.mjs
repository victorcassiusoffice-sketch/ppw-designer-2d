// Source-prepared before the campaign. Execute only after all five serial runs
// finish and the coordinator releases their CPU/browser lease for aggregation.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const round = path.dirname(fileURLToPath(import.meta.url));
const expected = '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e';
const round2Head = 'd78064f9f57ed6e060d9782036b4a8b7a7e95451';
const proofFiles = {
  input: 'results/r3-walk-input-v3/walk-performance-walk.json',
  frames: 'results/r3-walk-frames-v2/walk-framerate-walk.json',
  background: 'results/r3-walk-background-v1/background-ownership.json',
  desktop: 'results/r3-walk-functional-desktop-v2/walk-functional-walk.json',
  phone: 'results/r3-walk-functional-phone-v6/walk-functional-walk.json',
};
const round2File = '../round2/results/r2-walk-input-v3/walk-performance-walk.json';
const outputNames = ['R3-WALK-INPUT-FRAMES-FUNCTIONAL.json', 'R3-WALK-INPUT-FRAMES-FUNCTIONAL.md'];
const args = process.argv.slice(2);
const assert = (condition, message) => { if (!condition) throw Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const json = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
const number = value => Number.isFinite(value) ? value : null;
const present = value => typeof value === 'string' && value.trim().length > 0;
const bool = value => value === true ? true : value === false ? false : null;
const aggregate = values => values.includes(false) ? false : values.length > 0 && values.every(value => value === true) ? true : null;
const devices = ['desktop', 'phone'], modes = ['third', 'first'];
const notes = [];
if (!args.includes('--execute')) {
  console.log(JSON.stringify({ preparedOnly: true, expected, proofFiles, round2File, outputNames,
    command: 'node work/world-finish/round3/aggregate-walk-final.mjs --execute --decision=walk-preparation-decision-final.json',
    decisionSchema: { expected, decision: 'retain | recommend-revert', reason: 'Evidence-based interpretation, not inferred from a threshold alone', demonstratedBenefit: 'Explicit observed benefit or absence of benefit', evidenceLimits: ['Uncertainty/limitations'], campaignRelease: { atUtc: '<observed release time>', allFiveProcessesExited: true, allBrowsersClosed: true, sharedLockAbsent: true, matchingHarnessOrPlaywrightProcesses: 0 } },
    note: 'Without --execute no evidence is read and no files are written. No hash, compression, browser or network operation exists in this script.' }, null, 2));
  process.exit(0);
}
assert(args.every(value => value === '--execute' || value.startsWith('--decision=')), 'Unknown aggregation option.');
const options = args.filter(value => value.startsWith('--decision='));
assert(options.length === 1, 'One explicit --decision=round3-relative.json is required.');
const decisionName = options[0].slice(11), decisionPath = path.resolve(round, decisionName);
assert(present(decisionName) && !path.isAbsolute(decisionName) && path.relative(round, decisionPath) !== '..' && !path.relative(round, decisionPath).startsWith(`..${path.sep}`), 'Decision must be inside round3.');
for (const name of outputNames) assert(!fs.existsSync(path.join(round, name)), `Preserve existing compact: ${name}`);
for (const [key, file] of Object.entries(proofFiles)) assert(fs.statSync(path.join(round, file)).isFile(), `Required actual ${key} proof missing.`);
const raw = Object.fromEntries(Object.entries(proofFiles).map(([key, file]) => [key, json(path.join(round, file))]));
const decision = json(decisionPath);
assert(decision.expected === expected && ['retain', 'recommend-revert'].includes(decision.decision) && present(decision.reason) && present(decision.demonstratedBenefit) && Array.isArray(decision.evidenceLimits) && decision.evidenceLimits.every(present), 'Explicit current-head preparation decision/reason/benefit/limits required.');
const release = decision.campaignRelease;
assert(object(release) && present(release.atUtc) && release.allFiveProcessesExited === true && release.allBrowsersClosed === true && release.sharedLockAbsent === true && release.matchingHarnessOrPlaywrightProcesses === 0, 'Recorded campaign release is required; do not infer process closure.');
function exactHealth(report, head, label) {
  assert(report.expected === head, `${label} expected head mismatch.`);
  for (const phase of ['healthBefore', 'healthAfter']) {
    const health = report[phase];
    assert(health?.status === 200 && health.body?.commit === head && health.body?.env === 'preview', `${label} ${phase} must prove the exact preview head.`);
  }
  assert(present(report.endedAt), `${label} has no completed-run timestamp.`);
  assert(report.healthStable === true, `${label} health-stability declaration contradicts the required exact-head boundaries.`);
}
for (const [key, report] of Object.entries(raw)) exactHealth(report, expected, key);
assert(raw.input.harnessVersion === 3 && raw.input.postReadySettlingMs === 0 && raw.input.viewSwitchSettlingMs === 0, 'Input protocol changed.');
assert(raw.frames.harnessVersion === 2 && raw.frames.durationMs === 40000, 'Frame protocol changed.');
assert(raw.background.harnessVersion === 1 && raw.desktop.harnessVersion === 2 && raw.phone.harnessVersion === 6, 'Functional/background protocol changed.');
const round2 = json(path.resolve(round, round2File));
exactHealth(round2, round2Head, 'Round2 input');
assert(round2.harnessVersion === 3 && round2.postReadySettlingMs === 0 && round2.viewSwitchSettlingMs === 0, 'Round2 comparison protocol changed.');
function rows(report, label) {
  assert(Array.isArray(report.rows), `${label} rows missing.`);
  return report.rows;
}
function one(items, predicate, label) {
  const selected = items.filter(predicate);
  assert(selected.length <= 1, `Duplicate ${label} rows; do not select a preferred attempt.`);
  if (!selected.length) notes.push(`${label} is absent; missing evidence is UNPROVEN.`);
  return selected[0] ?? null;
}
function arrays(row) {
  return Object.fromEntries(['pageErrors', 'consoleErrors', 'httpErrors', 'blockedWrites'].map(key => [key, Array.isArray(row?.[key]) ? row[key] : null]));
}
function clean(row) {
  if (!row) return null;
  if (row.fatal || row.failure) return false;
  return aggregate(Object.values(arrays(row)).map(value => value === null ? null : value.length === 0));
}
function stats(samples, touch) {
  const values = samples.map(sample => number(sample.delayMs));
  const finite = values.length > 0 && values.every(value => Number.isFinite(value) && value >= 0);
  const sorted = finite ? [...values].sort((a, b) => a - b) : [];
  const sampleCoverage = samples.length === 5 && new Set(samples.map(sample => sample.n)).size === 5 && [0, 1, 2, 3, 4].every(index => samples.some(sample => sample.n === index));
  for (const sample of samples) {
    const start = touch ? sample.pointerInputAt : sample.inputAt;
    if (Number.isFinite(start) && Number.isFinite(sample.firstMovedRenderedAt)) assert(sample.delayMs === sample.firstMovedRenderedAt - start, 'Raw input latency differs from recorded timestamps.');
  }
  return { values, min: finite ? sorted[0] : null, median: finite ? sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2 : null,
    max: finite ? sorted.at(-1) : null, below50: values.filter(value => Number.isFinite(value) && value < 50).length, count: samples.length, completeFive: sampleCoverage && finite,
    eventToHandlerMs: samples.map(sample => number((touch ? sample.inputAt : sample.handlerAt) - (touch ? sample.pointerInputAt : sample.inputAt))),
    handlerToRenderMs: samples.map(sample => number(sample.firstMovedRenderedAt - (touch ? sample.inputAt : sample.handlerAt))), samples };
}
function inputRows(report, label) {
  const source = rows(report, label);
  assert(source.every(row => devices.includes(row.device)), `${label} contains an unexpected device.`);
  return devices.map(device => {
    const row = one(source, item => item.device === device, `${label}/${device}`);
    const summarize = (key, touch) => modes.map(mode => {
      const samples = Array.isArray(row?.[key]) ? row[key].filter(sample => sample.mode === mode) : [];
      return { mode, ...stats(samples, touch) };
    });
    return { device, observed: !!row,
      chooser: { eventToDecodedFrameMs: number(row?.chooserMs), callToVisibleMs: number(row?.chooserWallClockMs), callToDecodedFrameMs: number(row?.chooserCallToDecodedFrameMs), images: row?.chooser?.images ?? null },
      readyObservedAt: number(row?.readyObservedAt), entry: row?.entry ?? null,
      keyboard: summarize('input', false), nativeTouch: device === 'phone' ? summarize('touchInput', true) : [],
      ...arrays(row), fatal: row?.fatal ?? null, clean: clean(row) };
  });
}
const input = inputRows(raw.input, 'input');
const previousInput = inputRows(round2, 'Round2 input');
assert(rows(raw.background, 'background').every(row => devices.includes(row.device)), 'Unexpected background device; do not discard rows.');
for (const device of devices) assert(rows(raw[device], device).every(row => row.device === device), `Unexpected ${device} functional device; do not discard rows.`);
const frameSource = rows(raw.frames, 'frames');
assert(frameSource.every(row => devices.includes(row.device)), 'Unexpected frame device; do not discard rows.');
const frameFailures = frameSource.filter(row => row.fatal || !modes.includes(row.mode));
const frames = devices.flatMap(device => modes.map(mode => {
  const row = one(frameSource, item => item.device === device && item.mode === mode, `frames/${device}/${mode}`), measurement = row?.window?.result;
  const intervals = Array.isArray(measurement?.intervals) ? measurement.intervals : null, tails = Array.isArray(measurement?.unrenderedActiveTails) ? measurement.unrenderedActiveTails : null;
  const measured = measurement && intervals && tails;
  const full = measured ? measurement.reason === 'deadline' && measurement.pausedMs === 0 && measurement.observedMs === 40000 : null;
  const pass = measured && Number.isFinite(measurement.completedFramesPerActiveSecond) ? full && measurement.completedFramesPerActiveSecond >= (device === 'desktop' ? 60 : 30) : null;
  if (measured) {
    assert(row.completeUnpausedWindow === full && row.strictFpsPass === pass, `${device}/${mode} raw FPS gates disagree with unchanged deadline/threshold.`);
    assert(Number.isFinite(measurement.activeMs) && measurement.activeMs > 0 && Number.isSafeInteger(measurement.completedFrames), `${device}/${mode} frame denominator/count invalid.`);
    assert(Math.abs(measurement.completedFramesPerActiveSecond - measurement.completedFrames * 1000 / measurement.activeMs) < 1e-9, `${device}/${mode} FPS differs from count/active-time ratio.`);
  }
  return { device, mode, observed: !!measured, count: number(measurement?.completedFrames), activeMs: number(measurement?.activeMs), pausedMs: number(measurement?.pausedMs), observedMs: number(measurement?.observedMs), reason: measurement?.reason ?? null,
    fps: number(measurement?.completedFramesPerActiveSecond), low1: number(measurement?.low1CompletedIntervalFps), strictFpsPass: pass, completeUnpausedWindow: full,
    maxIntervalMs: intervals?.length ? Math.max(...intervals.map(item => item.durationMs)) : null, maxTailMs: tails ? Math.max(0, ...tails.map(item => item.durationMs)) : null,
    tails, longIntervals: intervals?.filter(item => item.durationMs >= 250) ?? null, intervalCount: intervals?.length ?? null,
    rafMeanFps: number(row?.rafDiagnostic?.meanFps), rafLow1Fps: number(row?.rafDiagnostic?.low1Fps), historicalHudFps: number(row?.historicalHudAfter?.fps), historicalHudLow1: number(row?.historicalHudAfter?.low1), ...arrays(row), clean: clean(row) };
}));
function restored(before, after) {
  const keys = ['savedSha256', 'savedBytes', 'cameraJson', 'renderedCameraJson'];
  if (!before || !after || !keys.every(key => before[key] !== null && before[key] !== undefined && after[key] !== null && after[key] !== undefined)) return null;
  if (!(before.savedBytes > 0) || !present(before.savedSha256) || !present(before.cameraJson) || !present(before.renderedCameraJson)) return false;
  return keys.every(key => before[key] === after[key]);
}
const backgroundRows = devices.map(device => {
  const row = one(rows(raw.background, 'background'), item => item.device === device, `background/${device}`);
  const phases = ['before-open', 'chooser-open', 'chooser-after-750ms', 'after-start', 'visit-ready', 'visit-after-movement', 'after-exit-750ms'];
  const snapshots = Array.isArray(row?.snapshots) ? row.snapshots : [];
  const complete = snapshots.length === phases.length && phases.every(phase => snapshots.filter(sample => sample.phase === phase).length === 1);
  let pausedAndResumed = null;
  if (complete) {
    const at = phase => snapshots.find(sample => sample.phase === phase), before = at(phases[0]), covered = at(phases[1]), after = at(phases.at(-1));
    pausedAndResumed = before.frames > 0 && before.paused === false && Number.isFinite(covered.frames) && phases.slice(1, -1).every(phase => at(phase).paused === true && at(phase).frames === covered.frames) && after.paused === false && after.frames > covered.frames;
  }
  const restore = restored(row?.before, row?.after), passed = aggregate([bool(row?.passed), pausedAndResumed, restore, clean(row), bool(row?.browserClosed)]);
  return { device, observed: !!row, passed, declaredPassed: row?.passed ?? null, snapshots, pausedAndResumed, restored: restore, before: row?.before ?? null, after: row?.after ?? null, ...arrays(row), failure: row?.failure ?? null, fatal: row?.fatal ?? null, browserClosed: row?.browserClosed ?? null };
});
const expectedChecks = { desktop: ['movement-restore', 'doors-both-views', 'five-escape-cycles'], phone: ['single-touch-movement-stop-restore', 'single-touch-controls', 'single-touch-doors-both-views', 'native-exit'] };
const functional = ['desktop', 'phone'].map(device => {
  const report = raw[device], row = one(rows(report, device), item => item.device === device, `${device} functional`);
  const checks = Array.isArray(row?.checks) ? row.checks : [], doors = Array.isArray(row?.door) ? row.door : [], escape = Array.isArray(row?.escape) ? row.escape : [];
  const checkCoverage = checks.length === expectedChecks[device].length && expectedChecks[device].every(name => checks.filter(check => check.name === name).length === 1);
  const checkResult = checkCoverage ? aggregate(checks.map(check => check.failure ? false : bool(check.passed))) : null;
  const doorResult = doors.length === 2 && modes.every(mode => doors.filter(door => door.mode === mode).length === 1) ? aggregate(doors.map(door => bool(door.passed))) : null;
  const escapeResult = device === 'desktop' ? escape.length === 5 ? aggregate(escape.map(cycle => aggregate([bool(cycle.firstEscapeStays), bool(cycle.secondEscapeExits), bool(cycle.unchanged)]))) : null : true;
  const singlePointer = device === 'phone' ? row?.native ? row.native.maxTouches === 1 && Array.isArray(row.native.keys) && row.native.keys.length === 0 : null : true;
  const restore = restored(row?.before, row?.final);
  const passed = aggregate([bool(row?.passed), checkResult, doorResult, escapeResult, singlePointer, restore, clean(row), bool(row?.browserClosed)]);
  return { label: path.basename(path.dirname(proofFiles[device])), healthStable: report.healthStable === true, rows: [{ device, observed: !!row, passed, declaredPassed: row?.passed ?? null,
    checks, ...arrays(row), before: row?.before ?? null, final: row?.final ?? null, restored: restore,
    doorViews: doors, escapeCycles: escape.length, escapeEvidence: escape, singlePointerOnly: device === 'phone' ? singlePointer : null,
    maxConcurrentTouches: row?.native?.maxTouches ?? null, nativeKeyEvents: row?.native?.keys ?? null, fatal: row?.fatal ?? null, browserClosed: row?.browserClosed ?? null }] };
});
const entryComparison = devices.map(device => {
  const previous = previousInput.find(row => row.device === device), current = input.find(row => row.device === device);
  assert(Number.isFinite(previous.entry?.entryMs), `Exact raw Round2 ${device} entry cost missing.`);
  return { device, round2EntryMs: previous.entry.entryMs, currentEntryMs: number(current.entry?.entryMs), deltaMs: Number.isFinite(current.entry?.entryMs) ? current.entry.entryMs - previous.entry.entryMs : null,
    round2Source: round2File, currentSource: proofFiles.input };
});
const keyboardGate = device => {
  const row = input.find(item => item.device === device);
  return aggregate([row.clean, ...row.keyboard.map(mode => mode.values.some(value => Number.isFinite(value) && value >= 50) ? false : mode.completeFive ? true : null)]);
};
const chooserGate = aggregate(input.map(row => {
  const measurements = Object.values(row.chooser).filter(value => typeof value === 'number');
  return measurements.some(value => value >= 1000) ? false : measurements.length === 3 ? true : null;
}));
const inputComparison = input.flatMap(current => ['keyboard', ...(current.device === 'phone' ? ['nativeTouch'] : [])].flatMap(kind => current[kind].map(mode => {
  const before = previousInput.find(row => row.device === current.device)[kind].find(row => row.mode === mode.mode);
  return { device: current.device, kind, mode: mode.mode, round2Values: before.values, currentValues: mode.values, round2Max: before.max, currentMax: mode.max,
    maxDeltaMs: Number.isFinite(mode.max) && Number.isFinite(before.max) ? mode.max - before.max : null, round2Under50: before.below50, currentUnder50: mode.below50, currentCompleteFive: mode.completeFive };
})));
const stalls = input.flatMap(row => ['keyboard', ...(row.device === 'phone' ? ['nativeTouch'] : [])].flatMap(kind => row[kind].flatMap(mode => mode.samples.filter(sample => sample.delayMs >= 50).map(sample => ({ device: row.device, kind, mode: mode.mode, ...sample,
  eventToHandlerMs: number((kind === 'nativeTouch' ? sample.inputAt : sample.handlerAt) - (kind === 'nativeTouch' ? sample.pointerInputAt : sample.inputAt)),
  handlerToRenderMs: number(sample.firstMovedRenderedAt - (kind === 'nativeTouch' ? sample.inputAt : sample.handlerAt)),
  afterReadyMs: number((kind === 'nativeTouch' ? sample.pointerInputAt : sample.inputAt) - row.readyObservedAt) })))));
const compact = {
  at: new Date().toISOString(), commit: expected, inputHealthStable: raw.input.healthStable === true, frameHealthStable: raw.frames.healthStable === true, allExactHeadHealth: true,
  protocol: { inputVersion: 3, postReadySettlingMs: 0, viewSwitchSettlingMs: 0, inputComparison: 'Same zero-settle Round2 v3 protocol; no added post-ready or view-switch settling. All samples remain.', inputEnd: 'First changed-position render submission, not photon latency. Native touch event, runtime handler and render timestamps remain distinct.', nativeTouchOrder: 'Phone native touch follows five keyboard samples in each view; it is not the first post-ready input.', framesVersion: 2, frameDurationMs: 40000, frameInitialWarmupMs: 3000, frameFirstViewSwitchWaitMs: 1000, framesComparison: 'Unchanged strict completed-render protocol; includes long stalls and unfinished tails, no frame deletion or screenshots. Independent rAF cadence and historical HUD stay separate.', phoneFunctionalVersion: 6, environment: 'Exclusive browser/CPU lease; D3D11, no throttling, fresh Chromium per viewport. Phone390x844 emulation does not establish physical one-hand comfort or human first-use comprehension.' },
  input, frames, background: { healthStable: raw.background.healthStable === true, passed: aggregate(backgroundRows.map(row => row.passed)), rows: backgroundRows }, functional,
  preparationDecision: { decision: decision.decision, reason: decision.reason, demonstratedBenefit: decision.demonstratedBenefit, evidenceLimits: decision.evidenceLimits, decisionSource: decisionName, entryComparison, inputComparison },
  diagnostic: { status: 'Current formal samples summarized without a new diagnostic profile; earlier profiles/probes retain their own heads and protocols.', stalls, frameFailures, priorProfile: '../round2/results/r2-walk-input-stall-profile-v2/input-stall-profile-summary.json', priorPhone: 'R3-PHONE-DOOR-DIAGNOSTIC.json', causeLimit: 'A longer interval alone cannot identify shader, GPU, collision, HUD or event-delivery cause. compileAsync is a preparation experiment, not proof that the earlier GPU flush compiled shaders.' },
  limitations: ['Every current failure remains; earlier v3/v4 no-click phone failures and the heavily instrumented v5 pass on unchanged old application code remain separate.', 'Native touch latencies are informational; the under50ms hard input target applies to laptop.', 'Chooser decoded-frame timing is a render opportunity, not a photon measurement.', 'No physical-phone, first-time-human comprehension or one-hand ergonomics study was performed.', ...notes, ...decision.evidenceLimits],
  campaignRelease: release, proofFiles,
  gates: { chooserUnder1Second: chooserGate, laptopInputUnder50: keyboardGate('desktop'), strictFps: aggregate([...frames.map(row => aggregate([row.strictFpsPass, row.clean])), ...(frameFailures.length ? [false] : [])]), originalBackgroundOwnership: aggregate(backgroundRows.map(row => row.passed)), desktopFunctional: functional.find(row => row.rows[0].device === 'desktop').rows[0].passed, phoneFunctional: functional.find(row => row.rows[0].device === 'phone').rows[0].passed },
};
const show = value => value === null || value === undefined ? 'unavailable' : String(value);
const status = value => value === true ? 'PASS' : value === false ? 'FAIL' : 'UNPROVEN';
const escapeCell = value => show(value).replaceAll('|', '\\|').replaceAll('\n', ' ');
const table = (headings, data) => [headings, headings.map(() => '---'), ...data].map(row => `| ${row.map(escapeCell).join(' | ')} |`).join('\n');
const review = `# Round 3 Walk input, frames and functional evidence

Exact source: \`${expected}\`. Every selected proof has exact preview health before and after; all five required files remain unchanged. Full-precision values below use the same zero-settle input and strict40s frame protocols as Round2. Missing observations remain UNPROVEN; failed samples are never dropped.

${table(['Gate', 'Result'], Object.entries(compact.gates).map(([key, value]) => [key, status(value)]))}

## Preparation experiment and entry cost

Decision: **${decision.decision}**. ${decision.reason}

Observed benefit: ${decision.demonstratedBenefit}

${table(['Device', 'Round2 raw entry ms', 'Current raw entry ms', 'Delta ms'], entryComparison.map(row => [row.device, row.round2EntryMs, row.currentEntryMs, row.deltaMs]))}

Round2 costs are read directly from the original d78064f input proof, not rounded display text. Start-to-ready includes actual preparation. compileAsync does not prove the cause of earlier GPU stalls, and the measured sample is not a controlled causal isolation of every intervening change.

## Every input sample

${table(['Device', 'Kind', 'View', 'Round2 values ms', 'Current values ms', 'Current maximum', 'Under50'], inputComparison.map(row => [row.device, row.kind, row.mode, row.round2Values.join(', '), row.currentValues.map(show).join(', '), row.currentMax, row.currentUnder50]))}

The compact retains event-to-handler and handler-to-render arrays and exact timestamps for every sample. Phone native touch follows keyboard sampling; its50ms comparison is informational. No post-ready or view-switch delay was added. Outliers remain in diagnostic.stalls; no cause is inferred from duration alone.

## Completed-render frame windows

${table(['Device', 'View', 'Frames', 'Active ms', 'Paused ms', 'FPS', '1% low', 'Max interval ms', 'Max tail ms', 'Gate'], frames.map(row => [row.device, row.mode, row.count, row.activeMs, row.pausedMs, row.fps, row.low1, row.maxIntervalMs, row.maxTailMs, status(row.strictFpsPass)]))}

All original completed intervals and tails remain in the raw frame file. Independent rAF cadence and historical HUD values remain separate; neither replaces completed-render FPS. Initial3s warm-up and first-person1s switch wait are unchanged and do not apply to input measurements.

## Original scene and functional behavior

${table(['Device', 'Original pause/resume', 'Exact restoration', 'Background overall'], backgroundRows.map(row => [row.device, status(row.pausedAndResumed), status(row.restored), status(row.passed)]))}

${table(['Device', 'Check', 'Result', 'Failure'], functional.flatMap(campaign => campaign.rows.flatMap(row => row.checks.map(check => [row.device, check.name, status(check.failure ? false : bool(check.passed)), check.failure ?? '']))))}

Desktop evidence retains both door views, five actual Escape cycles, and saved property/editing/rendered camera restoration. Native phone v6 retains click/hit-target/status evidence, the bounded safety-retreat rule, one-contact/key counters, and the legacy final-only run assertion separately. Current success would not erase earlier no-click failures or establish their cause.

## Sources and limitations

${Object.entries(proofFiles).map(([key, file]) => `- [${key}](${file})`).join('\n')}

${compact.limitations.map(value => `- ${value}`).join('\n')}

Campaign release: ${JSON.stringify(release)}. This recorded release does not assert that a later coordinator campaign has also stopped.
`;
// Construct both artifacts before touching disk. Exclusive creates preserve any
// previous result; no raw source or decision file is edited by aggregation.
fs.writeFileSync(path.join(round, outputNames[0]), JSON.stringify(compact, null, 2) + '\n', { flag: 'wx' });
fs.writeFileSync(path.join(round, outputNames[1]), review, { flag: 'wx' });
console.log(JSON.stringify({ outputs: outputNames, commit: expected, gates: compact.gates, preparationDecision: compact.preparationDecision }, null, 2));
