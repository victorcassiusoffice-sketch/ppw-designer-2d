import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { ROOT, REPOS, BASE_COMMIT } from './run-config.mjs';

const arg = name => process.argv.find(x => x.startsWith(`--${name}=`))?.slice(name.length + 3);
const label = arg('build-label');
const attributionName = arg('attribution');
const outputName = arg('output');
for (const value of [label, attributionName, outputName]) if (!value || !/^[\w.-]+$/.test(value)) throw Error('Require simple build-label, attribution, output names');
const outputPath = path.join(ROOT, outputName);
if (fs.existsSync(outputPath)) throw Error('Preserve prior semantic review; choose another output');
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const attribution = read(path.join(ROOT, attributionName));
if (attribution.baseHead !== BASE_COMMIT) throw Error('Unexpected baseline');
// This manual source interpretation applies only to the independently read heads.
// A later source change needs a new review rather than inheriting this verdict.
const reviewedHeads = {
  walk: '2e90b2a7c96f63f58ee9293dd9c791924f95a9f6',
  site: '52639e07bd04fd7e594bb577a4dcd3a87de5450c',
};
const result = { at: new Date().toISOString(), baseHead: BASE_COMMIT, buildLabel: label,
  interpretation: 'Source-level review accompanies the numerical byte and independent network gates. Rendered module lengths are not gzip contributions. General repairs to existing startup/accessibility behavior are identified separately from new feature implementation; no symbol-alias byte exemption is used.', branches: {} };
const keyboard = 'Foreground modal ownership guard prevents pre-existing capture listeners from changing the saved design or consuming Walk input. It contains no movement, geometry or rendering behavior.';
const common = {
  'src/components/threeStageLoader.ts': ['existing-alias', 'Source is unchanged from Base52. Emitted preload/import references differ because final chunk names/exports differ; no additional loader behavior.'],
  'src/hooks/useWorkspaceFocus.ts': ['lazy-seam', 'Existing modal focus owner accepts an optional foreground key callback; actual Walk key handling remains deferred.'],
  'src/components/ProjectWorkspace.tsx': ['lazy-seam', keyboard],
  'src/components/OpeningSelectionEditor.tsx': ['lazy-seam', keyboard],
  'src/components/RoomDrawMode.tsx': ['lazy-seam', keyboard],
  'src/components/PlanGardenWorkspace.tsx': ['lazy-seam', keyboard],
  'src/components/RoomView3D.tsx': ['lazy-seam', 'Readiness-gated lazy launcher mounts only after ThreeStage publishes its first actual render. It passes existing scene/property/ownership handles; feature implementation remains in dynamic descendants.'],
  'src/store/propertyStore.ts': ['lazy-seam', 'Preserves an opaque world payload through existing normalization. It does not parse geographic data or calculate any geographic result.'],
  'src/site/SiteLoading.tsx': ['lazy-seam', 'Small cancellable loading/focus placeholder for the explicitly opened deferred workspace.'],
  'src/site/SiteLaunchButton.tsx': ['lazy-seam', 'Launch/mount bootstrap and deferred saved-data hydration scheduling; on 3D it waits for the existing actual-canvas-render mark. Canonical validation, provider access, map and geometry stay deferred.'],
  'src/components/canvasSiteBridge.ts': ['lazy-seam', 'Generic registration/subscription hook transports an optional opaque projection from the deferred validator. No Site schema, coordinates, label construction, area or north-arrow mathematics.'],
};
for (const branch of ['walk', 'site']) {
  const build = read(path.join(ROOT, 'builds', label, branch, 'audit.json'));
  const observed = attribution.branches[branch];
  const git = args => execFileSync('git', args, { cwd: REPOS[branch], encoding: 'utf8' }).trim();
  const head = git(['rev-parse', 'HEAD']);
  if (head !== build.sourceCommit || head !== observed.sourceHead) throw Error(`${branch} source identity mismatch`);
  if (head !== reviewedHeads[branch]) throw Error(`${branch} requires independent source review for its new head`);
  const dirty = git(['status', '--porcelain']).split(/\r?\n/).filter(Boolean).filter(x => !/docs\/world\//.test(x) && x !== '?? work/');
  if (dirty.length) throw Error(`${branch} source not frozen: ${dirty.join(', ')}`);
  const rules = { ...common };
  rules['src/components/TopBar.tsx'] = branch === 'walk'
    ? ['existing-accessibility-fix', 'Retained Round1 accessible-name correction matches the actual visible nested-span text and includes the count. Restoring base spacing regressed both the unchanged owned test and Lighthouse; that failed intermediate result is retained.']
    : ['lazy-seam', 'Mounts the small Site launcher. Also retains the separately evidenced existing room-selector accessible-name correction; no geographic implementation.'];
  rules['src/components/RoomCanvas.tsx'] = branch === 'walk'
    ? ['lazy-seam', keyboard]
    : ['lazy-seam', 'Host mounts the deferred projection through a generic hook/annotation callback. The opaque-presence guard withholds pending data; original legacy rectangle/area code remains inline. Geographic interpretation, labels, area calculation and arrow points are deferred.'];
  rules['src/components/three/ThreeStage.tsx'] = branch === 'walk'
    ? ['lazy-seam', 'Private-view ownership adapter exposes already-existing scene/renderer/live light/sky/bounds aliases and pause/release only. All private-camera lighting/fog/render and door adaptation now reside in deferred stageSurface. The separate general drawing-buffer allocation repair is listed below.']
    : ['general-startup-fix', 'Existing renderer allocates once at final layout/density rather than repeatedly at temporary dimensions. Same quality/DPR/shadows, with no Site feature behavior.'];
  const changedSourcePaths = git(['diff', '--name-only', BASE_COMMIT, 'HEAD', '--', 'src']).split(/\r?\n/).filter(Boolean);
  const earlySourceIds = new Set(build.modules.filter(row => row.early && row.id.startsWith('src/')).map(row => row.id.split('?')[0]));
  const earlyChangedSourcePaths = changedSourcePaths.filter(file => earlySourceIds.has(file)).sort();
  const renderedChangePaths = observed.moduleChanges.map(row => row.id).sort();
  const requiredClassifications = [...new Set([...renderedChangePaths, ...earlyChangedSourcePaths])].sort();
  const sourceOnlyChanges = earlyChangedSourcePaths.filter(file => !renderedChangePaths.includes(file));
  const missingClassifications = requiredClassifications.filter(file => !rules[file]);
  const classifications = requiredClassifications.map(id => {
    const row = observed.moduleChanges.find(item => item.id === id);
    const rule = rules[id] ?? ['unclassified', 'This changed early source has not received an independent semantic review.'];
    return { id, kind: rule[0], reason: rule[1], renderedDelta: row?.renderedDelta ?? null, sourceChanged: earlyChangedSourcePaths.includes(id) };
  });
  const deferredModules = branch === 'walk'
    ? ['src/walk/WalkLauncher.tsx', 'src/walk/WalkMode.tsx', 'src/walk/runtime.ts', 'src/walk/stageSurface.ts', 'src/walk/scene.ts', 'src/walk/collision.ts']
    : ['src/site/hydration.ts', 'src/site/planAdapter.tsx', 'src/site/types.ts', 'src/site/geometry.ts', 'src/site/SiteEntry.tsx', 'src/site/SiteWorkspace.tsx'];
  for (const id of deferredModules) if (!build.modules.some(x => x.id === id && !x.early) || build.modules.some(x => x.id === id && x.early)) throw Error(`Implementation not fully deferred: ${id}`);
  const unchanged = ['src/components/three/naturalSceneRenderer.ts', 'src/components/threeStageLoader.ts'];
  if (branch === 'walk') unchanged.push('src/components/three/joinery.ts');
  for (const file of unchanged) git(['diff', '--exit-code', BASE_COMMIT, 'HEAD', '--', file]);
  const hashes = Object.fromEntries([...new Set([...classifications.map(x => x.id), ...deferredModules, ...unchanged])].map(file => [file, createHash('sha256').update(fs.readFileSync(path.join(REPOS[branch], file))).digest('hex')]));
  result.branches[branch] = { head, passed: missingClassifications.length === 0,
    numericPassed: build.early.length === 28 && Number.isFinite(observed.gzipDelta) && observed.gzipDelta <= 1024,
    sourceReview: { reviewer: 'finish_audit', reviewedHead: reviewedHeads[branch],
      method: 'Read the Base52-to-v2 source diffs and complete new adapter files, then independently read both v2-to-v3 and v3-to-current diffs: only isolated plumbingContrast.css and its owned expanded E2E test changed. Classify the union of rendered changes and Git-changed source paths present in the current final early module inventory, including equal-length/equal-export changes. This source verdict does not establish timing, request or contrast gates.',
      conclusion: missingClassifications.length ? 'Incomplete: unclassified early source remains.' : 'No new World implementation found in the reviewed early sources; adapters transport ownership/projection data, with existing startup/accessibility repairs identified separately.' },
    sourceCoverage: { changedSourcePaths, earlyChangedSourcePaths, renderedChangePaths, requiredClassifications, sourceOnlyChanges, missingClassifications },
    earlyModuleClassifications: classifications, deferredModules,
    generalStartupChanges: ['Atomic drawing-buffer allocation preserves final dimensions/density and existing quality. It is a repair to the existing first-picture path, not new World implementation.'],
    existingAccessibilityChanges: ['The tested room-selector label-content/name correction remains; its temporary reversion is preserved as a failed intermediate CI/Lighthouse result.'],
    earlyCount: build.early.length, earlyRawDelta: observed.rawDelta, earlyGzipDelta: observed.gzipDelta,
    unchangedBaseFiles: unchanged, sourceSha256: hashes,
    requestGate: 'Independent final 40-load network audit must still prove zero new pre-picture request paths; source/build review alone does not establish that gate.' };
}
fs.writeFileSync(outputPath, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ outputPath, branches: Object.fromEntries(Object.entries(result.branches).map(([k,v]) => [k,{ head:v.head, passed:v.passed, earlyCount:v.earlyCount, earlyGzipDelta:v.earlyGzipDelta }])) }, null, 2));
