import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const labels = ['r3-walk-phone-door-probe-v1', 'r3-walk-phone-door-probe-locator-v1', 'r3-walk-phone-door-delivery-v5'];
const rows = labels.map(label => {
  const rawPath = `results/${label}/walk-functional-walk.json`;
  const report = JSON.parse(readFileSync(path.join(root, rawPath), 'utf8')), row = report.rows[0];
  const run = row.navigation.find(item => item.kind === 'native-run');
  const firstTap = row.door[0].attempts[0], down = firstTap.events.find(event => event.type === 'pointerdown' && (!event.phase || event.phase === 'capture'));
  const lastLookEnd = row.native.events.filter(event => event.type === 'touchend' && (!event.phase || event.phase === 'capture') && event.target?.className === 'world-walk-look' && event.listenerAt < down.listenerAt).at(-1);
  return { label, rawPath, expected: report.expected, startedAt: report.startedAt, endedAt: report.endedAt,
    harnessVersion: report.harnessVersion, protocol: report.doorTapProtocol ?? 'Sequential native CDP touchStart/touchEnd with id1',
    healthBefore: report.healthBefore.body.commit, healthAfter: report.healthAfter.body.commit, healthStable: report.healthStable,
    passed: report.passed, checks: row.checks.map(({ name, passed, failure }) => ({ name, passed: passed === true, failure })),
    doors: row.door, singlePointerOnly: row.singlePointerOnly, maxConcurrentTouches: row.native.maxTouches, keyEvents: row.native.keys,
    lookToDoor: { lastLookEndEventAt: lastLookEnd.eventAt, lastLookEndObservedAt: lastLookEnd.listenerAt, doorDownEventAt: down.eventAt, doorDownObservedAt: down.listenerAt, eventGapMs: down.eventAt - lastLookEnd.eventAt, observedGapMs: down.listenerAt - lastLookEnd.listenerAt },
    preventionCalls: row.native.preventionCalls ?? null, doorDomChanges: row.native.doorDomChanges ?? null,
    run: { before: run.before, after: run.after, startedAt: run.startedAt, endedAt: run.endedAt, displacementM: run.displacementM,
      clickEvents: row.native.events.filter(event => event.type === 'click' && event.eventAt >= run.startedAt - 250 && event.eventAt <= run.startedAt),
      states: row.native.statuses.filter(state => state.at >= run.startedAt && state.at <= run.endedAt) },
    pageErrors: row.pageErrors, consoleErrors: row.consoleErrors, httpErrors: row.httpErrors, blockedWrites: row.blockedWrites, browserClosed: row.browserClosed };
});
const result = { baseline: '9a1cb7e9d292300bdac253526af32d2722099c17', appEquivalentToRound2: 'd78064f9f57ed6e060d9782036b4a8b7a7e95451', rows,
  findings: [
    'The first two native protocols deliver trusted pointerdown/up and touchstart/end to an enabled, visible Open door button at the measured centre; neither yields an observed click in the capture or bubble listener.',
    'In both failed attempts every recorded post-tap status keeps Open door and blocked=false. No safety retreat is attempted because no safety rejection was observed. This narrows those observations to native click synthesis/delivery; it does not establish which code or browser behavior suppresses the click.',
    'The Playwright locator.tap comparison also fails, so sequential CDP dispatch or explicit touch id alone is not a sufficient explanation. Both failures remain intact.',
    'The direct-CDP campaign has a separate final-only run-animation assertion failure. Its run toggle emitted a trusted click and movement covered0.8216666666666628m; the last published animation was walk. The locator campaign passes the control check. A final collision-slowed frame is a possible sampling explanation, not a proven run defect.',
    'V5, using the same native locator.tap on unchanged application source with additional event/DOM instrumentation, passes all four functional checks. All four door open/close actions across two views succeed on attempt0 without retreat. Each has one trusted native click and a complete pointer/touch/compatibility-mouse sequence.',
    'The successful v5 gestures have defaultPrevented=false at capture, bubble, microtask and the following task; no preventDefault calls are observed anywhere in that run. Button node39 remains connected and identical at down/up, post-up hit test and after state change; no door-node replacement occurs during those four actions. These facts describe the successful run, not the uninstrumented failures.',
    'Last drag-look release to door pointerdown observed gaps are250.5ms (failed direct CDP),149.39999997615814ms (failed locator),200.20000004768372ms (successful instrumented locator). Thus this evidence does not support a simple fixed delay threshold. No intentional waiting period was added, but instrumentation and fresh-run state can affect timing.',
    'The third-run pass does not erase the two earlier failures or prove a product fix. Native click delivery remains intermittently unresolved; no door source patch was made on this evidence.',
    'No page, console or HTTP errors or attempted network writes occur. Saved property/camera restoration and single-contact/no-key evidence pass. These are emulated-phone functional observations, not formal input/FPS or physical/human evidence.',
  ], nextProbe: 'No additional run is scheduled by this child. Preserve all three attempts and the unresolved intermittent delivery limitation. Do not substitute synthetic DOM clicks, relax collision safety or present the instrumented pass as a source fix.',
  release: JSON.parse(readFileSync(path.join(root, 'audit-lease-release-v1.json'), 'utf8').replace(/^\uFEFF/, '')),
  deliveryRelease: JSON.parse(readFileSync(path.join(root, 'audit-delivery-lease-release.json'), 'utf8').replace(/^\uFEFF/, '')) };
writeFileSync(path.join(root, 'R3-PHONE-DOOR-DIAGNOSTIC.json'), JSON.stringify(result, null, 2) + '\n');
const lines = ['# Round3 baseline phone door diagnostic', '', `All three runs used exact preview head \`${result.baseline}\`, whose application is unchanged from Round2. No door source change was made.`, '',
  '| Native door tap | Overall | Controls/run | Door | Contacts / keys |', '|---|---|---|---|---|',
  ...rows.map(row => `|${row.protocol}|${row.passed ? 'PASS' : 'FAIL'}|${row.checks.find(check => check.name === 'single-touch-controls').passed ? 'PASS' : 'FAIL (retained)'}|${row.passed ? 'Four native actions pass, no retreat' : 'No click observed'}|${row.maxConcurrentTouches} / ${row.keyEvents.length}|`), '',
  ...result.findings.map(finding => `- ${finding}`), '',
  'The enabled button hit target is130.140625×44px at x129.9296875,y585; native taps use centre195,607. The direct-CDP attempt records pointerdown21848.5ms and pointerup21878.100000023842ms, with both targets the Open door button. Nine later status records preserve blocked=false and Open door. Complete bounds, event paths, timestamps, status records and both protocol attempts are retained in the JSON/raw files.', '',
  result.nextProbe, '',
  `The first two diagnostics released at ${result.release.atUtc}; v5 released at ${result.deliveryRelease.atUtc}. All owned browsers/processes closed, lock absent and no matching processes at both releases. Focused runtime/preparation/frame/collision tests passed54/54 across4files in the first lease, after the first diagnostic and before the comparison.`, '',
  ...rows.map(row => `- ${row.rawPath}`), ''];
writeFileSync(path.join(root, 'R3-PHONE-DOOR-DIAGNOSTIC.md'), lines.join('\n'));
console.log(JSON.stringify(rows.map(row => ({ label: row.label, passed: row.passed, exactHealth: row.healthBefore === row.expected && row.healthAfter === row.expected, doorOutcome: row.doors[0].attempts[0].outcome }))));
