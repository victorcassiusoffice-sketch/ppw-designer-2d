# Retained entry resource comparison

Source-only comparison of the original Round2 d78064f and current Round3 52fa408 input-v3 JSON records. No new browser run, trace or final compact aggregation. Full selected resource rows and original paths are in `ENTRY-RESOURCE-COMPARISON-52fa408-v1.json`.

| Device | Round2 total entry ms | Current total entry ms | Total delta ms | Round2 last selected response to ready-observed ms | Current gap ms |
| --- | --- | --- | --- | --- | --- |
| Desktop | 2836.899999976158 | 5990.399999976158 | 3153.5 | 200.10000002384186 | 362.2999999523163 |
| Phone | 2977.100000023842 | 3736.7000000476837 | 759.6000000238419 | 176.20000004768372 | 982 |

Desktop runtime download duration rises from393.5 to808.2000000476837ms; character GLB from386.7999999523163 to769ms; Draco WASM from491 to917.8999999761581ms. These are observed network-resource durations, not separately measured server latency. They overlap where recorded and cannot simply be summed into exclusive entry stages. Current desktop's last selected response is the Draco WASM; current phone's is its wrapper, ending2.1999999284744263ms after the WASM.

The raw proof supplies total entryMs and a later readyObservedAt, not independent parse, Draco decode, actor/scene setup, compileAsync or first-render spans. The last-response-to-observation gap includes all remaining such work and observation delay; calling it shader compilation time would be unsupported. Exact Start click time is not separately recorded. Membership in preStartResources establishes only that a request appears in the earlier snapshot.

The desktop comparison materially weakens any claim that compileAsync caused the multi-second entry increase. Phone's larger post-response gap remains compatible with several unseparated stages. Actual current entry/FPS failures stay retained, but a narrow revert would be a new bounded experiment, not correction of a proven compile-duration cause. No current gate is promoted from these historical resource comparisons.
