import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import https from 'node:https';
import { TARGETS, LABEL, acquireRun } from '../round2/run-config.mjs';
const branch = process.argv[2], expectedHead = process.argv[3];
if (!['walk','site'].includes(branch) || !/^[a-f0-9]{40}$/.test(expectedHead ?? '') || !process.argv.some(arg => arg.startsWith('--label=r3-'))) throw Error('Pass branch, full expected head and a new explicit r3 label');
const finalHeads = { walk: '52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e', site: '7a73b25a2a32556d9d5cf5381d72e7c7bf611447' };
if (expectedHead !== finalHeads[branch]) throw Error('Expected head differs from the committed Round3 contrast candidate');
acquireRun('plumbing-theme-contrast-normal-source-final');
const repo = `C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-${branch}`;
const require = createRequire(repo + '/package.json');
const output = resolve(dirname(fileURLToPath(import.meta.url)), 'theme-tests', LABEL, branch);
if (existsSync(output)) throw Error('Refusing to overwrite existing browser evidence');
mkdirSync(output, { recursive: true });
writeFileSync(resolve(output, 'wrapper-source.mjs'), readFileSync(fileURLToPath(import.meta.url)));
const sourcePath = repo + '/tests/e2e/plumbing-theme-contrast.spec.ts';
const sourceBlob = spawnSync('git', ['show', expectedHead + ':tests/e2e/plumbing-theme-contrast.spec.ts'], { cwd: repo, encoding: 'utf8' });
writeFileSync(resolve(output, 'test-source.ts'), readFileSync(sourcePath));
if (sourceBlob.status !== 0 || sourceBlob.stdout.replace(/\r\n/g, '\n') !== readFileSync(sourcePath, 'utf8').replace(/\r\n/g, '\n')) throw Error('Local test differs from the exact committed candidate');
const healthProof = [];
const checkHealth = async phase => {
  const url = new URL(TARGETS[branch] + '/api/healthcheck');
  const proof = { phase, at: new Date().toISOString(), url: url.href,
    transport: { pinnedAddress: '216.198.79.3', host: url.host, tlsServername: url.hostname } };
  try {
    Object.assign(proof, await new Promise((resolve, reject) => {
      const request = https.get({ hostname: '216.198.79.3', servername: url.hostname,
        headers: { Host: url.host }, path: url.pathname, agent: false, timeout: 20000 }, response => {
        let raw = ''; response.setEncoding('utf8'); response.on('data', chunk => raw += chunk);
        response.on('end', () => { try { resolve({ status: response.statusCode, body: JSON.parse(raw) }); } catch (error) { reject(error); } });
      });
      request.on('timeout', () => request.destroy(Error('Pinned health timeout'))); request.on('error', reject);
    }));
  } catch (error) { proof.error = String(error); }
  healthProof.push(proof);
  writeFileSync(resolve(output, 'health-boundaries.json'), JSON.stringify(healthProof, null, 2) + '\n');
  if (proof.status !== 200 || proof.body?.commit !== expectedHead || proof.body?.env !== 'preview') throw Error('Exact preview health mismatch at ' + phase);
};
await checkHealth('before');
const configPath = resolve(output, 'playwright.config.cjs');
const config = { testDir: repo + '/tests/e2e', testMatch: 'plumbing-theme-contrast.spec.ts', fullyParallel: false, workers: 1, retries: 0,
  timeout: 60000, reporter: [['json', { outputFile: resolve(output, 'results.json') }], ['list']],
  outputDir: resolve(output, 'artifacts'), use: { baseURL: TARGETS[branch], trace: 'retain-on-failure', screenshot: 'only-on-failure' } };
writeFileSync(configPath, 'module.exports = ' + JSON.stringify(config, null, 2) + ';\n');
const run = spawnSync(process.execPath, [require.resolve('@playwright/test/cli'), 'test', '--config', configPath], { cwd: repo, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });
writeFileSync(resolve(output, 'run.log'), run.stdout + run.stderr);
console.log(run.stdout + run.stderr);
await checkHealth('after');
const result = JSON.parse(readFileSync(resolve(output, 'results.json'), 'utf8'));
const tests = [];
const collect = (suite, parents = []) => { const context = [...parents, suite.title].filter(Boolean); for (const spec of suite.specs ?? []) for (const test of spec.tests) tests.push({ title: [...context, spec.title].join(' > '), test }); for (const child of suite.suites ?? []) collect(child, context); };
result.suites.forEach(suite => collect(suite));
const report = { branch, expectedHead, label: LABEL, normalSource: true, styleInjection: false, healthProof, exitCode: run.status, tests: [] };
for (const { title, test } of tests) for (const result of test.results) {
  const readAttachment = name => {
    const attachment = result.attachments.find(item => item.name === name);
    if (!attachment) return null;
    const text = attachment.path ? readFileSync(attachment.path, 'utf8') : Buffer.from(attachment.body, 'base64').toString();
    return JSON.parse(text);
  };
  const health = readAttachment('health.json'), contrast = readAttachment('contrast.json');
  report.tests.push({ title, status: result.status, health, minimumContrast: contrast ? Math.min(...contrast.map(row => row.ratio)) : null, checks: contrast?.length ?? 0 });
}
report.validHeads = report.tests.length === 4 && report.tests.every(test => test.health?.commit === expectedHead && test.health?.env === 'preview');
report.passed = run.status === 0 && report.validHeads;
writeFileSync(resolve(output, 'verified.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
if (!report.passed) process.exitCode = 1;
