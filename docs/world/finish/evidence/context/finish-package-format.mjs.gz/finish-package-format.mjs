import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './run-config.mjs';
const file=path.join(ROOT,'package-round3.mjs');
let source=fs.readFileSync(file,'utf8');
const edits=[
 ['Full Playwright test records retain statuses', 'Current final Playwright test records retain statuses'],
 ['Text/JSON attachments and extracted contrast/health records remain fully packaged.', 'Current final text/JSON attachments and extracted contrast/health records remain fully packaged. Earlier/intermediate contrast and Lighthouse bulk records remain externally retained with exact original hashes and complete failure observations in the packaged failure table.'],
 ['Full Lighthouse audit records remain packaged', 'Current exact-head full Lighthouse audit records remain packaged'],
 ['Complete Round3 load/input/functional/frame samples are gzip copies with original hashes.', 'All forty formal loads, complete network pairs, all five original final Walk proofs and the other retained Walk samples are lossless gzip copies with original hashes. Earlier/intermediate contrast and Lighthouse bulk records remain outside the PR, unchanged and fully hashed; their failure observations remain in the packaged table.'],
 ['## Preservation and budget\n\n', '## Preservation and budget\n\nLarge JSON proofs and generated tables use small readable JSON indexes. Each index identifies a sibling lossless gzip file, its compressed and uncompressed byte counts and SHA256 values. Decompress that file to read the complete evidence/table; indexes are explicitly not substitutes for its contents. Every compression is verified byte-for-byte before packaging. No observation, sample or failure is removed by compression.\n\n'],
 ['Large traces/profiles and binary-bearing original Playwright/Lighthouse results are hashed but not included in the compact package.', 'Large traces/profiles, binary-bearing original Playwright/Lighthouse results, and earlier/intermediate contrast/Lighthouse bulk records are hashed but not included in the compact package. Their complete originals remain at the recorded external paths; all observed failures remain in the packaged failure table.'],
];
for(const [before,after] of edits){if(source.split(before).length!==2)throw Error('Expected one prose replacement: '+before);source=source.replace(before,after);}
fs.writeFileSync(file,source);
fs.appendFileSync(path.join(ROOT,'PACKAGE-CONFIGURATION.md'),'\nFinal compact layout: JSON proofs above50KB and full source/failure/derivation tables are lossless gzip files with readable JSON indexes identifying original/compressed sizes and SHA256 values. All current formal load/network/Walk records remain included, including failures. Earlier/intermediate contrast and Lighthouse bulk records are retained externally, unchanged and hashed, with full failed-observation summaries packaged. Every top-level and nested scratch harness source is inventoried with execution determined only by its run record. No slow run or original is deleted. This supersedes earlier statements that every intermediate textual record travels inside the PR.\n');
