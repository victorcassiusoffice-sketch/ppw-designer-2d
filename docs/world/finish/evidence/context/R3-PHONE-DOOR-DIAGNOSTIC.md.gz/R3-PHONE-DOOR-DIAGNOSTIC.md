# Round3 baseline phone door diagnostic

All three runs used exact preview head `9a1cb7e9d292300bdac253526af32d2722099c17`, whose application is unchanged from Round2. No door source change was made.

| Native door tap | Overall | Controls/run | Door | Contacts / keys |
|---|---|---|---|---|
|Sequential native CDP touchStart/touchEnd with id1|FAIL|FAIL (retained)|No click observed|1 / 0|
|Native Playwright locator.tap; comparison against retained direct-CDP v3. No DOM click injection.|FAIL|PASS|No click observed|1 / 0|
|Native Playwright locator.tap; delivery diagnostic with default-prevention and DOM-identity instrumentation. No DOM click injection. Instrumented timings are not formal performance metrics.|PASS|PASS|Four native actions pass, no retreat|1 / 0|

- The first two native protocols deliver trusted pointerdown/up and touchstart/end to an enabled, visible Open door button at the measured centre; neither yields an observed click in the capture or bubble listener.
- In both failed attempts every recorded post-tap status keeps Open door and blocked=false. No safety retreat is attempted because no safety rejection was observed. This narrows those observations to native click synthesis/delivery; it does not establish which code or browser behavior suppresses the click.
- The Playwright locator.tap comparison also fails, so sequential CDP dispatch or explicit touch id alone is not a sufficient explanation. Both failures remain intact.
- The direct-CDP campaign has a separate final-only run-animation assertion failure. Its run toggle emitted a trusted click and movement covered0.8216666666666628m; the last published animation was walk. The locator campaign passes the control check. A final collision-slowed frame is a possible sampling explanation, not a proven run defect.
- V5, using the same native locator.tap on unchanged application source with additional event/DOM instrumentation, passes all four functional checks. All four door open/close actions across two views succeed on attempt0 without retreat. Each has one trusted native click and a complete pointer/touch/compatibility-mouse sequence.
- The successful v5 gestures have defaultPrevented=false at capture, bubble, microtask and the following task; no preventDefault calls are observed anywhere in that run. Button node39 remains connected and identical at down/up, post-up hit test and after state change; no door-node replacement occurs during those four actions. These facts describe the successful run, not the uninstrumented failures.
- Last drag-look release to door pointerdown observed gaps are250.5ms (failed direct CDP),149.39999997615814ms (failed locator),200.20000004768372ms (successful instrumented locator). Thus this evidence does not support a simple fixed delay threshold. No intentional waiting period was added, but instrumentation and fresh-run state can affect timing.
- The third-run pass does not erase the two earlier failures or prove a product fix. Native click delivery remains intermittently unresolved; no door source patch was made on this evidence.
- No page, console or HTTP errors or attempted network writes occur. Saved property/camera restoration and single-contact/no-key evidence pass. These are emulated-phone functional observations, not formal input/FPS or physical/human evidence.

The enabled button hit target is130.140625×44px at x129.9296875,y585; native taps use centre195,607. The direct-CDP attempt records pointerdown21848.5ms and pointerup21878.100000023842ms, with both targets the Open door button. Nine later status records preserve blocked=false and Open door. Complete bounds, event paths, timestamps, status records and both protocol attempts are retained in the JSON/raw files.

No additional run is scheduled by this child. Preserve all three attempts and the unresolved intermittent delivery limitation. Do not substitute synthetic DOM clicks, relax collision safety or present the instrumented pass as a source fix.

The first two diagnostics released at 2026-10-29T07:48:08.7784187Z; v5 released at 2026-10-29T07:59:01.7214411Z. All owned browsers/processes closed, lock absent and no matching processes at both releases. Focused runtime/preparation/frame/collision tests passed54/54 across4files in the first lease, after the first diagnostic and before the comparison.

- results/r3-walk-phone-door-probe-v1/walk-functional-walk.json
- results/r3-walk-phone-door-probe-locator-v1/walk-functional-walk.json
- results/r3-walk-phone-door-delivery-v5/walk-functional-walk.json
