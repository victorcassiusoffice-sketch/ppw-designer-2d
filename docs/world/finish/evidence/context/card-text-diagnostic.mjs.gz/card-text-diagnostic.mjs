import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { launch, TARGETS, LABEL } from '../round2/harness/lib.mjs';
const expected='b076116f679c6ab176de73f0e7e6cd67c3c4bb79';
if(LABEL!=='r3-card-text-v1')throw Error('Fresh bounded diagnostic label required');
const out=resolve(dirname(fileURLToPath(import.meta.url)),'dark-contrast',LABEL);
if(existsSync(out))throw Error('Existing evidence');mkdirSync(out,{recursive:true});
const report={expected,label:LABEL,diagnostic:true,cases:[]};const save=()=>writeFileSync(resolve(out,'report.json'),JSON.stringify(report,null,2));
const browser=await launch();
try{for(const brand of ['olb','ppw']){
 const row={brand,states:[],errors:[],writes:[]};report.cases.push(row);const context=await browser.newContext({viewport:{width:1280,height:800}});const page=await context.newPage();page.on('pageerror',e=>row.errors.push(String(e)));
 await context.route('**/*',route=>{if(!['GET','HEAD','OPTIONS'].includes(route.request().method())){row.writes.push(route.request().url());return route.abort();}return route.continue();});
 try{
 await page.goto(TARGETS.walk+'/api/healthcheck');row.healthBefore=JSON.parse(await page.locator('body').innerText());if(row.healthBefore.commit!==expected)throw Error('Wrong head');
 await page.goto(TARGETS.walk+'/pitch/plumbing?brand='+brand);await page.locator('.sales-tabs').waitFor();
 for(const theme of ['ivory','ocean','slate']){
 await page.locator('details.locale-theme-controls > summary').click();await page.locator('.theme-skin-card--'+theme).click();await page.locator('.locale-theme-controls__heading button').click();
 for(const chapter of [1,2,3,4]){
 await page.locator('[role="tab"]').nth(chapter).click();
 const measurements=await page.evaluate(()=>{
 const rgba=v=>{const c=v.match(/[\d.]+/g).map(Number);return[c[0],c[1],c[2],c[3]??1]};const comp=(f,b)=>[...f.slice(0,3).map((v,i)=>v*f[3]+b[i]*(1-f[3])),1];const lum=c=>{const v=c.slice(0,3).map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4});return v[0]*.2126+v[1]*.7152+v[2]*.0722};
 const nodes=[...document.querySelectorAll('.sales-surface :is(h2,p,span,strong,a),.sales-content summary,.sales-content .sales-button')].map(element=>({element,pseudo:null}));for(const element of document.querySelectorAll('.sales-steps li'))nodes.push({element,pseudo:'::before'});
 return nodes.filter(({element})=>element.getClientRects().length).map(({element,pseudo})=>{let surfaces=[[255,255,255,1]];const parents=[];for(let n=element;n;n=n.parentElement)parents.unshift(n);for(const n of parents){const s=getComputedStyle(n);surfaces=surfaces.map(b=>comp(rgba(s.backgroundColor),b));if(s.backgroundImage!=='none'){const stops=[...s.backgroundImage.matchAll(/rgba?\([^)]+\)/g)].map(m=>rgba(m[0]));if(!s.backgroundImage.startsWith('linear-gradient(')||!stops.length)throw Error('Unknown background');surfaces=surfaces.flatMap(b=>stops.map(c=>comp(c,b)));}}
 const s=getComputedStyle(element,pseudo);if(pseudo)surfaces=surfaces.map(b=>comp(rgba(s.backgroundColor),b));const ink=lum(rgba(s.color)),backgrounds=surfaces.map(lum),lo=Math.min(...backgrounds),hi=Math.max(...backgrounds);const ratio=ink>=lo&&ink<=hi?1:Math.min(...backgrounds.map(b=>(Math.max(ink,b)+.05)/(Math.min(ink,b)+.05)));
 return{tag:element.tagName,class:element.className,pseudo,text:pseudo?s.content:element.textContent,color:s.color,background:s.backgroundColor,ratio};});});
 row.states.push({theme,chapter:chapter+1,measurements});save();
 if(brand==='ppw'&&theme==='slate'&&[1,4].includes(chapter))await page.locator('.sales-content').screenshot({path:resolve(out,'ppw-slate-chapter'+(chapter+1)+'.png')});
 }
 }
 await page.goto(TARGETS.walk+'/api/healthcheck');row.healthAfter=JSON.parse(await page.locator('body').innerText());if(row.healthAfter.commit!==expected)throw Error('Changed head');
 }catch(error){row.failure=String(error)}finally{await context.close();row.contextClosed=true;save();}
 }}finally{await browser.close();report.browserClosed=true;save();}
console.log(JSON.stringify({states:report.cases.flatMap(c=>c.states).length,failures:report.cases.map(c=>c.failure??null),contrastFailures:report.cases.flatMap(c=>c.states.flatMap(s=>s.measurements.filter(m=>m.ratio<4.5).map(m=>({brand:c.brand,theme:s.theme,chapter:s.chapter,...m}))))},null,2));
if(report.cases.some(c=>c.failure))process.exitCode=1;
