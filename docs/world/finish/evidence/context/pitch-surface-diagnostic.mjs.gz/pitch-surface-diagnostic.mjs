import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { launch, TARGETS, LABEL, BASE_COMMIT } from '../round2/harness/lib.mjs';

if (LABEL !== 'r3-pitch-surfaces-v1') throw Error('Fresh bounded diagnostic label required');
const out = resolve(dirname(fileURLToPath(import.meta.url)), 'dark-contrast', LABEL);
if (existsSync(out)) throw Error('Existing evidence');
mkdirSync(out, { recursive: true });
const report = { label: LABEL, diagnostic: true, threshold: 4.5, cases: [] };
const save = () => writeFileSync(resolve(out, 'report.json'), JSON.stringify(report, null, 2));
const browser = await launch();
try {
  for (const [target, expected] of [['walk', '014937a7e8e219d0d59f7dc59a33ffa4d4f5eab4'], ['base', BASE_COMMIT]]) {
    for (const brand of ['olb', 'ppw']) {
      const row = { target, expected, brand, states: [], errors: [], writes: [] };
      report.cases.push(row);
      const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
      const page = await context.newPage();
      page.on('pageerror', e => row.errors.push(String(e)));
      await context.route('**/*', route => {
        if (!['GET', 'HEAD', 'OPTIONS'].includes(route.request().method())) {
          row.writes.push(route.request().url());
          return route.abort();
        }
        return route.continue();
      });
      const measure = async (theme, chapter, state = 'default') => {
        const measurements = await page.evaluate(() => {
          const rgba = value => { const c = value.match(/[\d.]+/g).map(Number); return [c[0], c[1], c[2], c[3] ?? 1]; };
          const composite = (front, back) => [...front.slice(0, 3).map((v, i) => v * front[3] + back[i] * (1 - front[3])), 1];
          const lum = c => { const v = c.slice(0, 3).map(x => { x /= 255; return x <= .04045 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4; }); return v[0] * .2126 + v[1] * .7152 + v[2] * .0722; };
          const seen = new Set(), nodes = [];
          const walker = document.createTreeWalker(document.querySelector('.sales-plumbing'), NodeFilter.SHOW_TEXT);
          while (walker.nextNode()) {
            const node = walker.currentNode, element = node.parentElement;
            if (!node.textContent.trim() || seen.has(element) || element.closest('svg, script, style, [aria-hidden="true"]')) continue;
            seen.add(element); nodes.push({ element, pseudo: null });
          }
          for (const element of document.querySelectorAll('.sales-steps li')) nodes.push({ element, pseudo: '::before' });
          for (const element of document.querySelectorAll('input[placeholder],textarea[placeholder]')) nodes.push({ element, pseudo: '::placeholder' });
          return nodes.filter(({ element }) => element.getClientRects().length && getComputedStyle(element).visibility === 'visible' && element.getBoundingClientRect().bottom > 0).map(({ element, pseudo }) => {
            const identifier = { tag: element.tagName, class: element.className, pseudo, text: pseudo === '::placeholder' ? element.getAttribute('placeholder') : pseudo ? getComputedStyle(element, pseudo).content : [...element.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join(' ') };
            try {
              let surfaces = [[255, 255, 255, 1]]; const ancestors = [];
              for (let node = element; node; node = node.parentElement) ancestors.unshift(node);
              for (const node of ancestors) {
                const style = getComputedStyle(node);
                if (style.opacity !== '1') throw Error('Unmodelled element opacity ' + style.opacity);
                surfaces = surfaces.map(back => composite(rgba(style.backgroundColor), back));
                if (style.backgroundImage !== 'none') {
                  const stops = [...style.backgroundImage.matchAll(/rgba?\([^)]+\)/g)].map(m => rgba(m[0]));
                  if (!style.backgroundImage.startsWith('linear-gradient(') || !stops.length) throw Error('Unmodelled background ' + style.backgroundImage);
                  surfaces = surfaces.flatMap(back => stops.map(color => composite(color, back)));
                }
              }
              const style = getComputedStyle(element, pseudo);
              if (pseudo) surfaces = surfaces.map(back => composite(rgba(style.backgroundColor), back));
              const color = rgba(style.color); color[3] *= Number(style.opacity);
              const ratios = surfaces.map(back => { const ink = lum(composite(color, back)), bg = lum(back); return (Math.max(ink, bg) + .05) / (Math.min(ink, bg) + .05); });
              return { ...identifier, color: style.color, opacity: style.opacity, background: style.backgroundColor, surfaces, fontSize: style.fontSize, fontWeight: style.fontWeight, ratio: Math.min(...ratios) };
            } catch (error) { return { ...identifier, error: String(error) }; }
          });
        });
        row.states.push({ theme, chapter: chapter + 1, state, measurements }); save();
      };
      try {
        await page.goto(TARGETS[target] + '/api/healthcheck');
        row.healthBefore = JSON.parse(await page.locator('body').innerText());
        if (row.healthBefore.commit !== expected) throw Error('Wrong head');
        await page.goto(TARGETS[target] + '/pitch/plumbing?brand=' + brand);
        await page.locator('.sales-tabs').waitFor();
        for (const theme of ['ivory', 'ocean', 'slate']) {
          await page.locator('details.locale-theme-controls > summary').click();
          await page.locator('.theme-skin-card--' + theme).click();
          await page.locator('.locale-theme-controls__heading button').click();
          for (const chapter of [0, 1, 2, 3, 4, 5]) {
            await page.locator('[role="tab"]').nth(chapter).click();
            if (chapter === 2) await page.locator('.sales-details summary').click();
            if (chapter === 5) await page.locator('form.pitch-enquiry').waitFor();
            await measure(theme, chapter);
            if (chapter === 5) {
              await page.locator('.pitch-segment button').last().click();
              await measure(theme, chapter, 'physical-meeting');
            }
          }
        }
        await page.goto(TARGETS[target] + '/api/healthcheck');
        row.healthAfter = JSON.parse(await page.locator('body').innerText());
        if (row.healthAfter.commit !== expected) throw Error('Changed head');
      } catch (error) { row.failure = String(error); }
      finally { await context.close(); row.contextClosed = true; save(); }
    }
  }
} finally { await browser.close(); report.browserClosed = true; save(); }
const failures = report.cases.flatMap(c => c.states.flatMap(s => s.measurements.filter(m => m.error || m.ratio < 4.5).map(m => ({ target: c.target, brand: c.brand, theme: s.theme, chapter: s.chapter, state: s.state, ...m }))));
writeFileSync(resolve(out, 'failures.json'), JSON.stringify(failures, null, 2));
console.log(JSON.stringify({ cases: report.cases.length, states: report.cases.flatMap(c => c.states).length, failures: report.cases.map(c => c.failure ?? null), contrastFailures: failures.length }));
if (report.cases.some(c => c.failure)) process.exitCode = 1;
