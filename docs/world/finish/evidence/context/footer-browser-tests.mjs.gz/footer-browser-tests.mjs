import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { TARGETS, LABEL, acquireRun } from '../round2/run-config.mjs';
const branch = process.argv[2], expectedHead = process.argv[3];
if (!['walk','site'].includes(branch) || !/^[a-f0-9]{40}$/.test(expectedHead ?? '') || !process.argv.some(arg => arg.startsWith('--label=r3-'))) throw Error('Pass branch, full expected head and a new explicit r2 label');
acquireRun('footer-contrast-native-browser-regression');
const repo = `C:/Users/Victor/Documents/Codex/2026-09-23/c/work/ppw-designer-${branch}`;
const require = createRequire(repo + '/package.json');
const output = resolve(dirname(fileURLToPath(import.meta.url)), 'footer-tests', LABEL, branch);
if (existsSync(output)) throw Error('Refusing to overwrite existing browser evidence');
mkdirSync(output, { recursive: true });
const configPath = resolve(output, 'playwright.config.cjs');
const config = { testDir: repo + '/tests/e2e', testMatch: 'plumbing-footer-contrast.spec.ts', fullyParallel: false, workers: 1, retries: 0,
  timeout: 60000, reporter: [['json', { outputFile: resolve(output, 'results.json') }], ['list']],
  outputDir: resolve(output, 'artifacts'), use: { baseURL: TARGETS[branch], trace: 'retain-on-failure', screenshot: 'only-on-failure' } };
writeFileSync(configPath, 'module.exports = ' + JSON.stringify(config, null, 2) + ';\n');
const run = spawnSync(process.execPath, [require.resolve('@playwright/test/cli'), 'test', '--config', configPath], { cwd: repo, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });
writeFileSync(resolve(output, 'run.log'), run.stdout + run.stderr);
console.log(run.stdout + run.stderr);
const result = JSON.parse(readFileSync(resolve(output, 'results.json'), 'utf8'));
const tests = [];
const collect = suite => { for (const spec of suite.specs ?? []) for (const test of spec.tests) tests.push({ title: spec.title, test }); for (const child of suite.suites ?? []) collect(child); };
result.suites.forEach(collect);
const report = { branch, expectedHead, label: LABEL, exitCode: run.status, tests: [] };
for (const { title, test } of tests) for (const result of test.results) {
  const readAttachment = name => {
    const attachment = result.attachments.find(item => item.name === name);
    if (!attachment) return null;
    const text = attachment.path ? readFileSync(attachment.path, 'utf8') : Buffer.from(attachment.body, 'base64').toString();
    return JSON.parse(text);
  };
  const health = readAttachment('health.json'), contrast = readAttachment('contrast.json');
  report.tests.push({ title, status: result.status, health, minimumContrast: contrast ? Math.min(...contrast.map(row => row.ratio)) : null, checks: contrast?.length ?? 0 });
}
report.validHeads = report.tests.length === 4 && report.tests.every(test => test.health?.commit === expectedHead && test.health?.env === 'preview');
report.passed = run.status === 0 && report.validHeads;
writeFileSync(resolve(output, 'verified.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
if (!report.passed) process.exitCode = 1;
