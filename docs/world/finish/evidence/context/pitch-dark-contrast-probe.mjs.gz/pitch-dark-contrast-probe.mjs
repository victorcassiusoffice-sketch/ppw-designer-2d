// Bounded inherited-vs-regressed comparison. No application source mutations.
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { launch, health, TARGETS, LABEL } from '../round2/harness/lib.mjs';
const expected = { base: '56d852d1f2f5d7342b9e02194964d6b998c795c7', walk: 'bf249b542152eb72870fdfa76426a03152c069c7', site: '6e57e7ed244a07572ffb2157210f650ba77be38f' };
if (!LABEL.startsWith('r3-dark-')) throw Error('Use a fresh r3-dark label');
const out = resolve(dirname(fileURLToPath(import.meta.url)), 'dark-contrast', LABEL);
if (existsSync(out)) throw Error('Do not overwrite diagnostic evidence');
mkdirSync(out, { recursive: true });
const report = { at: new Date().toISOString(), expected, label: LABEL, healthBefore: [], cases: [], healthAfter: [] };
const save = () => writeFileSync(resolve(out, 'report.json'), JSON.stringify(report, null, 2) + '\n');
const assert = (condition, message) => { if (!condition) throw Error(message); };
for (const target of Object.keys(expected)) {
  const result = await health(target); report.healthBefore.push(result); save();
  assert(result.body.commit === expected[target] && result.body.env === 'preview', 'Wrong initial health ' + target);
}
const browser = await launch();
try {
  for (const target of Object.keys(expected)) for (const brand of ['olb', 'ppw']) {
    const row = { target, brand, states: [], errors: [], consoleErrors: [], writes: [], fixtures: [] };
    report.cases.push(row); save();
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    context.setDefaultTimeout(15000); context.setDefaultNavigationTimeout(30000);
    const page = await context.newPage();
    page.on('pageerror', error => row.errors.push(String(error)));
    page.on('console', message => { if (message.type() === 'error') row.consoleErrors.push({ text: message.text(), url: message.location().url }); });
    await context.route('**/*', route => {
      const request = route.request();
      if (!['GET', 'HEAD', 'OPTIONS'].includes(request.method())) { row.writes.push({ url: request.url(), method: request.method() }); return route.abort(); }
      return route.continue();
    });
    await page.route('**/api/pitch-enquiry', route => {
      row.fixtures.push({ transmitted: false, method: route.request().method(), body: route.request().postDataJSON() });
      return route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: 'Local diagnostic rejection' }) });
    });
    const styles = async selector => page.locator(selector).first().evaluate(element => {
      const chain = [];
      for (let node = element; node; node = node.parentElement) {
        const style = getComputedStyle(node);
        chain.push({ tag: node.tagName, class: node.className, color: style.color, background: style.backgroundColor, image: style.backgroundImage, opacity: style.opacity });
      }
      return { text: element.textContent, chain };
    });
    try {
      await page.goto(TARGETS[target] + '/pitch/plumbing' + (brand === 'ppw' ? '?brand=ppw' : '') + '#Your%20catalogue', { waitUntil: 'domcontentloaded' });
      await page.locator('.sales-surface h2').first().waitFor();
      for (const theme of ['ocean', 'slate']) {
        await page.locator('[role="tab"]').nth(2).click();
        await page.locator('details.locale-theme-controls > summary').click();
        await page.locator(`.theme-skin-card--${theme}`).click();
        await page.waitForFunction(theme => document.documentElement.dataset.uiTheme === theme, theme);
        const state = { theme, preferenceClose: await styles('.locale-theme-controls__heading button') };
        await page.screenshot({ path: resolve(out, `${target}-${brand}-${theme}-preferences.png`), fullPage: true, animations: 'disabled' });
        await page.locator('.locale-theme-controls__heading button').click();
        state.heading = await styles('.sales-surface h2');
        state.paragraph = await styles('.sales-surface p');
        await page.screenshot({ path: resolve(out, `${target}-${brand}-${theme}-catalogue.png`), fullPage: true, animations: 'disabled' });
        await page.locator('[role="tab"]').nth(5).click();
        const form = page.locator('form.pitch-enquiry');
        await form.locator('[name="email"]').waitFor();
        await form.locator('[name="name"]').fill('Diagnostic Fixture');
        await form.locator('[name="email"]').fill('fixture@example.test');
        await form.locator('[name="message"]').fill('Local comparison fixture; no request transmitted.');
        await form.locator('[name="consent"]').check();
        await form.locator('button[type="submit"]').click();
        await form.locator('[role="alert"]').waitFor();
        state.errorStatus = await styles('.pitch-enquiry-result');
        await page.screenshot({ path: resolve(out, `${target}-${brand}-${theme}-error.png`), fullPage: true, animations: 'disabled' });
        row.states.push(state); save();
      }
      assert(row.errors.length === 0 && row.writes.length === 0, 'Unexpected error or write');
    } catch (error) { row.failure = String(error); }
    finally { await context.close(); row.contextClosed = true; save(); }
  }
} finally {
  await browser.close(); report.browserClosed = true;
  for (const target of Object.keys(expected)) {
    try { report.healthAfter.push(await health(target)); }
    catch (error) { report.healthAfter.push({ target, failure: String(error) }); }
  }
  report.stableHealth = report.healthAfter.every(result => result.body?.commit === expected[result.target] && result.body?.env === 'preview');
  report.endedAt = new Date().toISOString(); save();
}
console.log(JSON.stringify({ cases: report.cases.length, states: report.cases.reduce((sum, row) => sum + row.states.length, 0), stableHealth: report.stableHealth, failures: report.cases.filter(row => row.failure).map(row => ({ target: row.target, brand: row.brand, failure: row.failure })) }));
if (!report.stableHealth || report.cases.some(row => row.failure)) process.exitCode = 1;
