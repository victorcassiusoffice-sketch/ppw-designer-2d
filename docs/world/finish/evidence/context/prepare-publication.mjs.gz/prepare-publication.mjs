import fs from 'node:fs';
import path from 'node:path';
import { ROOT, REPOS } from './run-config.mjs';
const read = file => fs.readFileSync(file, 'utf8');
const draftRoot = path.join(ROOT, 'closure-drafts');
const current = read(path.join(draftRoot, 'CURRENT.md'));
const rubric = read(path.join(draftRoot, 'RUBRIC.md'));
const decisions = read(path.join(draftRoot, 'DECISIONS.md'));
const research = value => value.split('## Components and releases')[1]?.split('## Evidence status and next work')[0];
const rows = rubric.split('\n').filter(line => /^\|\s*\d+\s*\|/.test(line));
if (rows.length !== 30 || rows.some(line => !/\]\([^)]+\)/.test(line))) throw Error('Thirty linked rubric rows required');
const retained = {};
function bytes(directory, base = directory) {
  let total = 0;
  for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, item.name);
    if (item.isSymbolicLink()) throw Error('Unexpected linked docs');
    if (path.relative(base, full).replaceAll('\\', '/') === 'finish/evidence') continue;
    total += item.isDirectory() ? bytes(full, base) : fs.statSync(full).size;
  }
  return total;
}
for (const branch of ['walk', 'site']) {
  const docs = path.join(REPOS[branch], 'docs/world');
  const old = read(path.join(docs, 'CURRENT.md'));
  if (!research(old) || research(old) !== research(current)) throw Error('Research preservation failed: ' + branch);
  const priorDecisions = read(path.join(docs, 'DECISIONS.md'));
  if (priorDecisions.includes('## Finish round3 decisions')) throw Error('Decisions already appended');
  fs.writeFileSync(path.join(docs, 'CURRENT.md'), current);
  fs.writeFileSync(path.join(docs, 'RUBRIC.md'), rubric);
  fs.appendFileSync(path.join(docs, 'DECISIONS.md'), '\n' + decisions);
  retained[branch] = bytes(docs);
}
const config = JSON.parse(read(path.join(ROOT, 'package-inputs-draft-52fa408-7a73b25.json')));
Object.assign(config.inputs, {
  summary: 'results/r3-candidate/summary.json', network: 'results/r3-candidate/network-audit.json',
  loads: 'results/r3-candidate/load-all.json', startup: 'startup-analysis-final.json',
  rules: 'rules-audit-round-end.json', visibleRules: 'results/r3-rules/visible-rules.json',
});
config.retainedDocsBytes = retained;
fs.writeFileSync(path.join(ROOT, 'package-inputs-final.json'), JSON.stringify(config, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({retainedDocsBytes:retained, rubricRows:rows.length, researchPreserved:true}, null, 2));
