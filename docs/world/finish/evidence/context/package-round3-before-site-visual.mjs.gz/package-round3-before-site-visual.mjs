// Preparation only unless --execute --walk-final-reviewed are explicit.
// Writes only a fresh chat outputs/world-finish/round-3; never repository docs.
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';

const round = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(round, '../../..');
const output = path.join(root, 'outputs/world-finish/round-3');
const script = fileURLToPath(import.meta.url);
const siteRepo = path.resolve(root, '../../2026-09-23/c/work/ppw-designer-site');
const inputKeys = ['summary', 'network', 'loads', 'attribution', 'semantic', 'buildBase', 'buildWalk', 'buildSite', 'startup', 'lighthouse', 'themeWalk', 'themeSite', 'themeWalkReview', 'themeSiteReview', 'walk', 'walkReview', 'siteDirectory', 'sitePlan', 'sitePlanReview', 'printDirectory', 'rules', 'visibleRules', 'ci', 'publication'];
const walkProofKeys = ['background', 'input', 'frames', 'desktop', 'phone'];
const walkHarnessKeys = [...walkProofKeys, 'lib', 'config'];
const options = new Set(process.argv.slice(2));
const preferredBudget = 3_000_000;
const softBudget = 3_800_000;
const hardBudget = 5_000_000;
const assert = (ok, message) => { if (!ok) throw Error(message); };
const slash = value => value.replaceAll('\\', '/');
const originalPath = file => slash(path.relative(root, file));
const status = value => value === true ? 'PASS' : value === false ? 'FAIL' : 'UNPROVEN';
const n = value => Number.isFinite(value) ? String(value) : 'unavailable';
const exact = value => Number.isFinite(value) ? String(value) : 'unavailable';
const esc = value => String(value ?? '').replaceAll('|', '\\|').replaceAll('\n', ' ');
const table = (headers, rows) => [
  `| ${headers.join(' | ')} |`, `| ${headers.map(() => '---').join(' | ')} |`,
  ...rows.map(row => `| ${row.map(esc).join(' | ')} |`),
].join('\n');
const json = async file => JSON.parse((await fs.readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const exactKeys = (value, keys, name) => assert(object(value) && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key)), `${name} requires exactly: ${keys.join(', ')}`);
function within(directory, file) {
  const relative = path.relative(directory, path.resolve(file));
  return relative !== '' && !relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative);
}
function sourcePath(relative) {
  assert(typeof relative === 'string' && !path.isAbsolute(relative), 'Input paths must be relative to round3.');
  const full = path.resolve(round, relative);
  assert(within(round, full), `Input outside round3: ${relative}`);
  return full;
}
function destination(relative) {
  const full = path.resolve(output, relative);
  assert(within(output, full), `Output outside fixed package: ${relative}`);
  return full;
}

// This path reads no evidence, hashes nothing, creates no directories and copies
// nothing. Override-file contents are read only under explicit execution.
if (!options.has('--execute')) {
  console.log(JSON.stringify({
    mode: 'DRY RUN — no filesystem reads/copies/hashes/gzip/output creation',
    output, requiredInputs: inputKeys,
    command: 'node work/world-finish/round3/package-round3.mjs --execute --walk-final-reviewed --inputs=package-inputs-final.json',
    configuration: { version: 1, heads: { base: '<full SHA>', walk: '<full SHA>', site: '<full SHA>' }, inputs: '<all required relative paths>', walkProofs: walkProofKeys, walkHarnesses: Object.fromEntries(walkHarnessKeys.map(key => [key, { path: '<round3-relative source>', sha256: '<64 lowercase hex>' }])), retainedDocsBytes: { walk: '<integer excluding this replacement package>', site: '<integer excluding this replacement package>' } },
    requires: [
      'Coordinator approves final compact Walk interpretation and releases any CPU/browser lease.',
      'Exact-head formal, Site UI, all-page visual inspection, rules and CI inputs are complete.',
      'Fresh output directory; every earlier failed raw attempt remains unchanged.',
    ],
    ciSchema: { branches: { walk: { head: '<final SHA>', checks: ['{name,status,conclusion,url}'] }, site: { head: '<final SHA>', checks: ['{name,status,conclusion,url}'] } } },
    budget: { preferredBytes: preferredBudget, softBytes: softBudget, hardCombinedRepositoryBytes: hardBudget, parentRecheckBeforeInstallation: true },
  }, null, 2));
  process.exit(0);
}
assert(options.has('--walk-final-reviewed'), 'Coordinator must review final Walk compact before execution.');
assert([...options].every(x => ['--execute', '--walk-final-reviewed'].includes(x) || x.startsWith('--inputs=')), 'Unknown execution option.');
const overrideOption = [...options].find(x => x.startsWith('--inputs='));
assert(process.argv.filter(x => x.startsWith('--inputs=')).length === 1, 'Exactly one required --inputs=round3-relative-config.json is needed.');
const configurationPath = sourcePath(overrideOption.slice(9));
const configuration = await json(configurationPath);
exactKeys(configuration, ['version', 'heads', 'inputs', 'walkProofs', 'walkHarnesses', 'retainedDocsBytes'], 'Configuration');
assert(configuration.version === 1, 'Unsupported configuration version.');
const { heads, inputs, walkProofs, walkHarnesses, retainedDocsBytes } = configuration;
exactKeys(heads, ['base', 'walk', 'site'], 'heads');
assert(Object.values(heads).every(value => /^[a-f0-9]{40}$/.test(value)), 'Every head must be a full lowercase Git SHA.');
exactKeys(inputs, inputKeys, 'inputs'); exactKeys(walkProofs, walkProofKeys, 'walkProofs'); exactKeys(walkHarnesses, walkHarnessKeys, 'walkHarnesses');
exactKeys(retainedDocsBytes, ['walk', 'site'], 'retainedDocsBytes');
assert(Object.values(retainedDocsBytes).every(value => Number.isSafeInteger(value) && value >= 0 && value < hardBudget), 'Retained docs bytes must be nonnegative integers below the combined hard budget.');
for (const value of Object.values(inputs)) sourcePath(value);
for (const value of Object.values(walkProofs)) sourcePath(value);
for (const [key, value] of Object.entries(walkHarnesses)) {
  exactKeys(value, ['path', 'sha256'], `walkHarnesses.${key}`); sourcePath(value.path);
  assert(/^[a-f0-9]{64}$/.test(value.sha256), `${key} harness needs a recorded SHA256.`);
}
assert(new Set(Object.values(walkHarnesses).map(value => sourcePath(value.path))).size === walkHarnessKeys.length, 'Each selected Walk harness role requires its own source file.');
try { await fs.access(output); throw Error(`Preserve existing package; output already exists: ${output}`); }
catch (error) { if (error.code !== 'ENOENT') throw error; }

async function files(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const result = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(directory, entry.name);
    assert(!entry.isSymbolicLink(), `Refusing symlink: ${full}`);
    if (entry.isDirectory()) result.push(...await files(full));
    else if (entry.isFile()) result.push(full);
  }
  return result;
}
const required = {
  ...Object.fromEntries(Object.entries(inputs).filter(([key]) => !key.endsWith('Directory') && !key.startsWith('build')).map(([key, value]) => [key, sourcePath(value)])),
  site: sourcePath(`${inputs.siteDirectory}/preview-smoke.json`),
  print: sourcePath(`${inputs.printDirectory}/visual-review.json`),
  printRaw: sourcePath(`${inputs.printDirectory}/print-check.json`),
  printReview: sourcePath(`${inputs.printDirectory}/VISUAL-REVIEW.md`),
  build_base: sourcePath(inputs.buildBase), build_walk: sourcePath(inputs.buildWalk), build_site: sourcePath(inputs.buildSite),
  ...Object.fromEntries(Object.entries(walkProofs).map(([key, value]) => [`walk_${key}`, sourcePath(value)])),
  ...Object.fromEntries(Object.entries(walkHarnesses).map(([key, value]) => [`harness_${key}`, sourcePath(value.path)])),
  siteHarness: path.join(siteRepo, 'work/site-qa/finish-preview.mjs'), sitePrintHarness: path.join(siteRepo, 'scripts/qa/site-print.mjs'), sitePdfHarness: path.join(siteRepo, 'scripts/qa/site-print-pdf.mjs'),
};
// All required identity/proof checks finish before any package is created.
const missing = [];
for (const [key, file] of Object.entries(required)) {
  try { const stat = await fs.lstat(file); assert(stat.isFile() && !stat.isSymbolicLink(), `${key} must be an ordinary file`); }
  catch (error) { missing.push({ key, file, error: String(error) }); }
}
assert(missing.length === 0, `Required final evidence is missing: ${JSON.stringify(missing)}`);
const values = Object.fromEntries(await Promise.all(Object.entries(required).filter(([, file]) => file.endsWith('.json')).map(async ([key, file]) => [key, await json(file)])));
const { summary, network, loads, attribution, semantic, startup, lighthouse, walk, site, sitePlan, sitePlanReview, print, printRaw, rules, visibleRules, ci, publication } = values;
const coverage = (rows, expected, key, name) => {
  assert(Array.isArray(rows), `${name} rows missing.`);
  const actual = rows.map(key);
  assert(actual.length === expected.length && new Set(actual).size === actual.length && expected.every(value => actual.includes(value)), `${name} coverage mismatch: ${JSON.stringify(actual)}`);
};
const checkedHealth = (value, branch, name) => assert(value?.status === 200 && value.body?.commit === heads[branch], `${name} must identify exact ${branch} head.`);
const sourceMatches = (value, file) => typeof value === 'string' && path.resolve(path.isAbsolute(value) ? value : path.join(round, value)) === path.resolve(file);
const equalData = (a, b, name) => assert(JSON.stringify(a) === JSON.stringify(b), `${name} differs from selected raw evidence.`);
const median = samples => { if (!samples.length || samples.some(value => !Number.isFinite(value))) return null; const ordered = [...samples].sort((a, b) => a - b); return ordered.length % 2 ? ordered[(ordered.length - 1) / 2] : (ordered[ordered.length / 2 - 1] + ordered[ordered.length / 2]) / 2; };
const devices = ['desktop', 'phone'], modes = ['third', 'first'];
exactKeys(semantic.branches, ['walk', 'site'], 'semantic.branches');
exactKeys(network.branches, ['walk', 'site'], 'network.branches');
const formalKeys = ['base', 'walk', 'site', 'prod'].flatMap(target => devices.flatMap(device => [1, 2, 3, 4, 5].map(run => `${target}/${device}/${run}`)));
assert(summary.baseCommit === heads.base && attribution.baseHead === heads.base, 'Base identity mismatch.');
assert(loads.baseCommit === heads.base && loads.rows.length === 40, 'All forty formal loads are required.');
assert(loads.expectedHeads?.walk === heads.walk && loads.expectedHeads?.site === heads.site, 'Raw formal expected-head mismatch.');
coverage(loads.rows, formalKeys, row => `${row.target}/${row.device}/${row.run}`, 'Raw formal loads');
coverage(startup.rows, formalKeys, row => `${row.target}/${row.device}/${row.run}`, 'Startup interpretation');
assert(sourceMatches(startup.source, required.loads), 'Startup interpretation must name the selected raw formal file.');
for (const row of startup.rows) {
  const raw = loads.rows.find(item => item.target === row.target && item.device === row.device && item.run === row.run);
  equalData(row.firstPictureMs ?? null, raw.canvasFirstPictureMs ?? null, `${row.target}/${row.device}/${row.run} startup first picture`);
  equalData(row.fcpMs ?? null, raw.paints?.find(item => item.name === 'first-contentful-paint')?.startTime ?? null, `${row.target}/${row.device}/${row.run} startup FCP`);
  equalData(row.loadingFcpWithinOneSecond, Number.isFinite(row.fcpMs) && row.fcpMs <= 1000, `${row.target}/${row.device}/${row.run} independently derived FCP prerequisite`);
}
assert(network.baseCommit === heads.base && network.label === loads.label, 'Network audit must use the selected formal campaign/base.');
assert(semantic.baseHead === heads.base, 'Semantic audit base mismatch.');
const themeImages = {}, themeEquivalenceChecks = new Map();
for (const branch of ['walk', 'site']) {
  const directory = path.dirname(required[branch === 'walk' ? 'themeWalk' : 'themeSite']);
  themeImages[branch] = new Map((await files(path.join(directory, 'extracted')))
    .filter(file => /\.(?:png|jpg|jpeg)$/i.test(file))
    .map(file => [slash(path.relative(directory, file)), file]));
}
for (const branch of ['walk', 'site']) {
  const theme = values[branch === 'walk' ? 'themeWalk' : 'themeSite'];
  assert(theme.branch === branch && theme.expectedHead === heads[branch] && theme.normalSource === true && theme.styleInjection === false && theme.validHeads === true, `${branch} current normal-source contrast identity/protocol proof missing.`);
  assert(Array.isArray(theme.tests) && theme.tests.length === 4 && new Set(theme.tests.map(test => test.title)).size === 4, `${branch} must retain four distinct contrast tests.`);
  for (const test of theme.tests) assert(test.health?.commit === heads[branch] && test.health?.env === 'preview', `${branch} contrast test head mismatch.`);
  coverage(theme.healthProof, ['before', 'after'], proof => proof.phase, `${branch} contrast health boundaries`);
  for (const proof of theme.healthProof) checkedHealth(proof, branch, `${branch} contrast ${proof.phase}`);
  const themePassed = theme.exitCode === 0 && theme.tests.every(test => test.status === 'passed' && Number.isFinite(test.minimumContrast) && test.minimumContrast >= 4.5 && Number.isSafeInteger(test.checks) && test.checks > 0);
  equalData(theme.passed, themePassed, `${branch} independently derived contrast result`);
  const themeReview = values[branch === 'walk' ? 'themeWalkReview' : 'themeSiteReview'];
  assert(themeReview.branch === branch && themeReview.sourceHead === heads[branch] && typeof themeReview.visualPassed === 'boolean', `${branch} current-head visual theme review missing.`);
  const scope = themeReview.scope;
  assert((typeof scope === 'string' && scope.trim()) || (Array.isArray(scope) && scope.length > 0 && scope.every(item => typeof item === 'string' && item.trim())), `${branch} visual review scope must be explicit.`);
  assert(Array.isArray(themeReview.findings), `${branch} visual review findings must be retained.`);
  coverage(themeReview.inspectedScreenshots, [...themeImages[branch].keys()], file => file, `${branch} every final extracted theme image`);
  if (themeReview.visualPassed) assert(themeImages[branch].size > 0, `${branch} visual PASS requires actual screenshots.`);
  if (themeReview.imageEquivalence !== undefined) {
    assert(Array.isArray(themeReview.imageEquivalence), `${branch} image equivalence groups must be an array.`);
    const seenMembers = new Set();
    for (const group of themeReview.imageEquivalence) {
      assert(/^[a-f0-9]{64}$/.test(group.sha256) && Array.isArray(group.members) && group.members.length > 0, `${branch} image equivalence hash/member proof missing.`);
      const representative = group.representative;
      assert(representative && group.members.some(member => member.branch === representative.branch && member.path === representative.path), `${branch} image representative must be explicitly listed among its members.`);
      for (const member of group.members) {
        assert(['walk', 'site'].includes(member.branch) && typeof member.path === 'string' && themeImages[member.branch].has(member.path), `${branch} image equivalence references a missing/non-final screenshot.`);
        const key = `${member.branch}/${member.path}`;
        assert(!seenMembers.has(key), `${branch} image equivalence duplicates a screenshot across groups.`);
        seenMembers.add(key);
        const file = themeImages[member.branch].get(member.path), previous = themeEquivalenceChecks.get(file);
        assert(!previous || previous.sha256 === group.sha256, 'Conflicting byte-identical screenshot claims.');
        themeEquivalenceChecks.set(file, { sha256: group.sha256, key });
      }
    }
  }
  assert(summary.bundles[branch].candidateCommit === heads[branch], `${branch} timing head mismatch.`);
  assert(attribution.branches[branch].sourceHead === heads[branch], `${branch} attribution head mismatch.`);
  assert(values[`build_${branch}`].sourceCommit === heads[branch], `${branch} emitted build head mismatch.`);
  assert(lighthouse.branches[branch].head === heads[branch], `${branch} Lighthouse head mismatch.`);
  assert(ci.branches[branch].head === heads[branch] && Array.isArray(ci.branches[branch].checks) && ci.branches[branch].checks.length > 0, `${branch} exact-head CI list missing.`);
  assert(ci.branches[branch].checks.every(x => x.name && (x.conclusion || x.status) && x.url), `${branch} CI checks require name, status/conclusion and URL.`);
  coverage(summary.timings[branch].rows, devices, row => row.device, `${branch} timing devices`);
  for (const row of summary.timings[branch].rows) {
    coverage(row.pairs, [1, 2, 3, 4, 5], pair => pair.run, `${branch}/${row.device} timing pairs`);
    for (const pair of row.pairs) {
      for (const [label, target] of [['base', 'base'], ['preview', branch], ['custom', 'prod']]) {
        const raw = loads.rows.find(item => item.target === target && item.device === row.device && item.run === pair.run);
        equalData(pair[`${label}WallMs`] ?? null, raw.first3dMs ?? null, `${branch}/${row.device}/${pair.run} ${label} wall`);
        equalData(pair[`${label}CanvasMs`] ?? null, raw.canvasFirstPictureMs ?? null, `${branch}/${row.device}/${pair.run} ${label} canvas`);
      }
    }
    for (const field of ['baseWallMs', 'previewWallMs', 'customWallMs', 'baseCanvasMs', 'previewCanvasMs', 'customCanvasMs']) equalData(row.medians[field], median(row.pairs.map(pair => pair[field])), `${branch}/${row.device} ${field} median`);
    const complete = loads.runs === 5 && row.pairs.every(pair => Array.isArray(pair.failures) && pair.failures.length === 0) && loads.healthStable === true;
    const limit = row.device === 'desktop' ? 3000 : 5000;
    equalData(row.gates.absoluteWall, complete && row.medians.previewWallMs !== null && row.medians.previewWallMs < limit, `${branch}/${row.device} absolute wall gate`);
    equalData(row.gates.absoluteCanvas, complete && row.medians.previewCanvasMs !== null && row.medians.previewCanvasMs < limit, `${branch}/${row.device} absolute canvas gate`);
    equalData(row.gates.pairedWall, complete && row.medians.previewWallMs !== null && row.medians.baseWallMs !== null && row.medians.previewWallMs <= row.medians.baseWallMs * 1.1, `${branch}/${row.device} paired wall gate`);
    equalData(row.gates.pairedCanvas, complete && row.medians.previewCanvasMs !== null && row.medians.baseCanvasMs !== null && row.medians.previewCanvasMs <= row.medians.baseCanvasMs * 1.1, `${branch}/${row.device} paired canvas gate`);
  }
  for (const phase of ['healthBefore', 'healthAfter']) checkedHealth(loads[phase]?.find(row => row.target === branch), branch, `Raw formal ${phase}`);
  assert(sourceMatches(network.branches[branch].source, required.loads), `${branch} network audit raw source mismatch.`);
  coverage(network.branches[branch].perPair, devices.flatMap(device => [1, 2, 3, 4, 5].map(run => `${device}/${run}`)), row => `${row.device}/${row.run}`, `${branch} network pairs`);
  const review = semantic.branches?.[branch], build = values[`build_${branch}`];
  assert(Array.isArray(build.modules), `${branch} emitted module inventory missing.`);
  assert(review?.head === heads[branch] && typeof review.passed === 'boolean', `${branch} semantic review must identify current head and pass/fail.`);
  assert(Array.isArray(review.earlyModuleClassifications) && Array.isArray(review.deferredModules) && review.deferredModules.length > 0 && Array.isArray(review.generalStartupChanges), `${branch} semantic classification lists missing.`);
  const changed = attribution.branches[branch].moduleChanges.map(row => row.id);
  const sourceCoverage = review.sourceCoverage;
  assert(sourceCoverage && Array.isArray(sourceCoverage.changedSourcePaths) && Array.isArray(sourceCoverage.earlyChangedSourcePaths) && Array.isArray(sourceCoverage.sourceOnlyChanges) && Array.isArray(sourceCoverage.missingClassifications), `${branch} Git-source coverage proof missing.`);
  assert(review.sourceReview?.reviewedHead === heads[branch] && typeof review.sourceReview.reviewer === 'string' && typeof review.sourceReview.conclusion === 'string', `${branch} independent source-review identity missing.`);
  const earlySourceIds = new Set(build.modules.filter(row => row.early && row.id.startsWith('src/')).map(row => row.id.split('?')[0]));
  const earlyChangedSourcePaths = sourceCoverage.changedSourcePaths.filter(file => earlySourceIds.has(file)).sort();
  coverage(sourceCoverage.earlyChangedSourcePaths, earlyChangedSourcePaths, file => file, `${branch} Git-changed early-source intersection`);
  coverage(sourceCoverage.renderedChangePaths, changed, file => file, `${branch} rendered-source coverage`);
  coverage(sourceCoverage.sourceOnlyChanges, earlyChangedSourcePaths.filter(file => !changed.includes(file)), file => file, `${branch} same-length source-change coverage`);
  const classificationUnion = [...new Set([...changed, ...earlyChangedSourcePaths])];
  coverage(sourceCoverage.requiredClassifications, classificationUnion, file => file, `${branch} complete early-source union`);
  coverage(review.earlyModuleClassifications, classificationUnion, row => row.id, `${branch} changed early-module classifications`);
  const allowed = new Set(['lazy-seam', 'existing-alias', 'general-startup-fix', 'existing-accessibility-fix']);
  assert(review.earlyModuleClassifications.every(row => typeof row.reason === 'string' && row.reason.trim() && typeof row.kind === 'string'), `${branch} semantic reasons/kinds required.`);
  if (review.passed) {
    assert(sourceCoverage.missingClassifications.length === 0, `${branch} semantic PASS includes unreviewed source.`);
    assert(review.earlyModuleClassifications.every(row => allowed.has(row.kind)), `${branch} semantic PASS includes unapproved feature code.`);
    assert(review.deferredModules.every(id => build.modules.some(row => row.id === id && row.early === false) && !build.modules.some(row => row.id === id && row.early === true)), `${branch} semantic PASS includes missing/early deferred implementation.`);
  }
}
assert(values.build_base.sourceCommit === heads.base, 'Controlled base build SHA mismatch.');
for (const phase of ['healthBefore', 'healthAfter']) checkedHealth(loads[phase]?.find(row => row.target === 'base'), 'base', `Raw formal ${phase}`);
for (const branch of ['base', 'walk', 'site']) {
  const build = values[`build_${branch}`];
  assert(Array.isArray(build.early) && build.early.length > 0 && Array.isArray(build.assets) && Array.isArray(build.modules), `${branch} finalized audit arrays missing.`);
  assert(build.early.every(row => typeof row.file === 'string' && Number.isFinite(row.bytes) && Number.isFinite(row.gzipBytes)), `${branch} early audit schema mismatch.`);
  const claimed = branch === 'base' ? attribution.baseline : attribution.branches[branch];
  assert(build.early.length === claimed.count && build.early.reduce((sum, row) => sum + row.bytes, 0) === claimed.raw && build.early.reduce((sum, row) => sum + row.gzipBytes, 0) === claimed.gzip, `${branch} attribution totals differ from final emitted audit.`);
  if (branch !== 'base') {
    equalData(claimed.rawDelta, claimed.raw - attribution.baseline.raw, `${branch} static raw delta`);
    equalData(claimed.gzipDelta, claimed.gzip - attribution.baseline.gzip, `${branch} static gzip delta`);
  }
}
assert(walk.commit === heads.walk && site.expectedSha === heads.site && print.sourceHead === heads.site && printRaw.expectedSha === heads.site, 'Functional/PDF identity mismatch.');
assert(site.rows.length === 7 && new Set(site.rows.map(row => `${row.case}/${row.device}`)).size === 7, 'Seven distinct Site cases required.');
assert(sitePlan.expectedSha === heads.site && sitePlanReview.sourceHead === heads.site, 'Current Site plan projection/review head mismatch.');
coverage(sitePlan.rows, ['native-concave-plan', 'saved-world-held-hydration'].flatMap(name => ['laptop', 'phone'].map(device => `${name}/${device}`)), row => `${row.case}/${row.device}`, 'Site plan projection');
assert(Array.isArray(sitePlanReview.inspectedScreenshots) && sitePlanReview.inspectedScreenshots.length > 0 && typeof sitePlanReview.visualPassed === 'boolean', 'Site plan needs a completed visual review, even if failed.');
const planImages = (await files(path.dirname(required.sitePlan))).filter(file => /\.(?:png|jpg|jpeg)$/i.test(file));
coverage(sitePlanReview.inspectedScreenshots, planImages.map(file => path.basename(file)), value => value, 'Every produced Site plan image inspection');
if (sitePlanReview.visualPassed) assert(planImages.length === 8, 'A passing plan visual review requires all eight expected screens.');
for (const row of sitePlan.rows) for (const phase of ['healthBefore', 'healthAfter']) {
  if (row[phase]) assert(row[phase].commit === heads.site, `Site plan ${row.case}/${row.device} ${phase} mismatch.`);
  else assert(row.passed !== true && typeof row.error === 'string', `Missing Site plan ${phase} requires an explicit failed observation.`);
}
coverage(walk.input, devices, row => row.device, 'Walk compact input');
coverage(walk.frames, devices.flatMap(device => modes.map(mode => `${device}/${mode}`)), row => `${row.device}/${row.mode}`, 'Walk compact frames');
assert(walk.protocol?.inputVersion === 3 && walk.protocol.postReadySettlingMs === 0 && walk.protocol.viewSwitchSettlingMs === 0 && walk.protocol.framesVersion === 2 && walk.protocol.frameDurationMs === 40000, 'Current zero-settle/strict-frame protocol declaration missing.');
for (const row of walk.input) {
  coverage(row.keyboard, modes, mode => mode.mode, `${row.device} keyboard modes`);
  for (const mode of row.keyboard) assert(mode.count === 5 && mode.values.length === 5, `${row.device}/${mode.mode} must retain five keyboard samples.`);
  if (row.device === 'phone') {
    coverage(row.nativeTouch, modes, mode => mode.mode, 'Native phone modes');
    for (const mode of row.nativeTouch) assert(mode.count === 5 && mode.values.length === 5, `${mode.mode} must retain five native-touch samples.`);
  }
}
for (const key of walkProofKeys) {
  const raw = values[`walk_${key}`];
  assert(raw.expected === heads.walk && sourceMatches(walk.proofFiles?.[key], required[`walk_${key}`]), `${key} current Walk proof path/head mismatch.`);
  checkedHealth(raw.healthBefore, 'walk', `${key} healthBefore`); checkedHealth(raw.healthAfter, 'walk', `${key} healthAfter`);
}
coverage(values.walk_input.rows, devices, row => row.device, 'Raw Walk input');
coverage(values.walk_background.rows, devices, row => row.device, 'Raw background ownership');
coverage(values.walk_frames.rows, devices.flatMap(device => modes.map(mode => `${device}/${mode}`)), row => `${row.device}/${row.mode}`, 'Raw frame windows');
assert(values.walk_input.harnessVersion === 3 && values.walk_input.postReadySettlingMs === 0 && values.walk_input.viewSwitchSettlingMs === 0, 'Raw input is not the selected zero-settle protocol.');
assert(values.walk_frames.harnessVersion === 2 && values.walk_frames.durationMs === 40000, 'Raw frame protocol mismatch.');
coverage(values.walk_desktop.rows, ['desktop'], row => row.device, 'Native desktop functional');
coverage(values.walk_phone.rows, ['phone'], row => row.device, 'Native phone functional');
assert(values.walk_phone.harnessVersion === 6 && values.walk_phone.rows[0].checks.length === 4, 'Current native-phone v6 campaign coverage missing.');
for (const row of walk.input) {
  const raw = values.walk_input.rows.find(item => item.device === row.device);
  equalData(row.entry?.entryMs, raw.entry?.entryMs, `${row.device} entry cost`);
  for (const [key, rawKey] of [['keyboard', 'input'], ['nativeTouch', 'touchInput']]) {
    if (key === 'nativeTouch' && row.device !== 'phone') continue;
    for (const mode of row[key]) {
      const samples = raw[rawKey].filter(item => item.mode === mode.mode);
      coverage(samples, [0, 1, 2, 3, 4], item => item.n, `${row.device}/${mode.mode} raw ${key}`);
      equalData(mode.values, samples.map(item => item.delayMs), `${row.device}/${mode.mode} ${key} values`);
      equalData(mode.max, Math.max(...samples.map(item => item.delayMs)), `${row.device}/${mode.mode} ${key} maximum`);
      equalData(mode.below50, samples.filter(item => item.delayMs < 50).length, `${row.device}/${mode.mode} ${key} under50 count`);
    }
  }
}
for (const row of walk.frames) {
  const raw = values.walk_frames.rows.find(item => item.device === row.device && item.mode === row.mode), measured = raw.window?.result;
  assert(measured && Array.isArray(measured.intervals) && Array.isArray(measured.unrenderedActiveTails), `${row.device}/${row.mode} full frame intervals/tails missing.`);
  for (const [field, source] of [['count', 'completedFrames'], ['activeMs', 'activeMs'], ['pausedMs', 'pausedMs'], ['fps', 'completedFramesPerActiveSecond'], ['low1', 'low1CompletedIntervalFps']]) equalData(row[field], measured[source], `${row.device}/${row.mode} frame ${field}`);
  equalData(row.strictFpsPass, raw.strictFpsPass, `${row.device}/${row.mode} FPS gate`);
  equalData(row.completeUnpausedWindow, raw.completeUnpausedWindow, `${row.device}/${row.mode} full-window gate`);
  const full = measured.reason === 'deadline' && measured.pausedMs === 0 && measured.observedMs === 40000;
  equalData(row.completeUnpausedWindow, full, `${row.device}/${row.mode} independently derived full window`);
  equalData(row.strictFpsPass, full && measured.completedFramesPerActiveSecond >= (row.device === 'desktop' ? 60 : 30), `${row.device}/${row.mode} independently derived FPS gate`);
}
assert(typeof walk.preparationDecision?.decision === 'string' && typeof walk.preparationDecision?.reason === 'string' && Array.isArray(walk.preparationDecision?.entryComparison), 'Compact must include explicit preparation retain/revert decision, reason and entryComparison, preserving Round2 costs.');
coverage(walk.preparationDecision.entryComparison, devices, row => row.device, 'Preparation entry comparison');
for (const row of walk.preparationDecision.entryComparison) {
  assert(Number.isFinite(row.round2EntryMs), `${row.device} Round2 entry cost missing.`);
  equalData(row.currentEntryMs, walk.input.find(input => input.device === row.device).entry.entryMs, `${row.device} preparation current entry`);
  equalData(row.deltaMs, row.currentEntryMs - row.round2EntryMs, `${row.device} entry delta`);
}
assert(printRaw.rows.length === 2 && ['laptop', 'phone'].every(d => printRaw.rows.some(r => r.device === d)), 'Both PDF device exports required.');
const rendered = printRaw.rows.flatMap(row => row.renderedPages || []);
assert(Array.isArray(print.inspectedPages) && rendered.length > 0 && new Set(rendered).size === rendered.length, 'PDF render inventory missing/duplicated.');
assert(rendered.length === print.inspectedPages.length && rendered.every(file => print.inspectedPages.includes(file)), 'Every rendered PDF page needs a recorded inspection, even when the review fails.');
for (const file of rendered) assert((await fs.stat(sourcePath(`${inputs.printDirectory}/${file}`))).isFile(), `Missing inspected page: ${file}`);
assert(visibleRules.rows.length === 4 && visibleRules.rows.reduce((total, row) => total + row.screens.length, 0) === 8, 'All eight final visible-rule screens required.');
coverage(visibleRules.rows, ['walk', 'site'].flatMap(branch => devices.map(device => `${branch}/${device}`)), row => `${row.target}/${row.device}`, 'Visible rules');
for (const branch of ['walk', 'site']) for (const phase of ['healthBefore', 'healthAfter']) checkedHealth(visibleRules[phase]?.[branch], branch, `Visible rules ${phase}`);
assert(Array.isArray(rules) && rules.length === 2, 'Both final static rule results required.');
for (const branch of ['walk', 'site']) {
  const rule = rules.find(x => x.branch === branch || x.head === heads[branch]);
  assert(rule?.head === heads[branch], `${branch} static rules must identify final source head.`);
  const published = publication.branches.find(x => x.head === heads[branch]);
  assert(published && published.ancestorExit === 0 && published.unpublishedCommits.length === 0, `${branch} publication/ancestry proof incomplete.`);
}
// No passing functional/timing result is required to package: failures are proof.
// Identity, full coverage and completed review are required; missing is not FAIL.

const sources = new Map();
const packaged = [];
const pendingWrites = new Map();
const failures = [];
const derivations = [];
async function digest(file) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
async function remember(file, role, name = null) {
  const full = path.resolve(file);
  let row = sources.get(full);
  if (!row) {
    const stat = await fs.stat(full);
    row = { path: originalPath(full), absolutePath: slash(full), bytes: stat.size, sha256: await digest(full), roles: [], packagedAs: [] };
    sources.set(full, row);
  }
  if (!row.roles.includes(role)) row.roles.push(role);
  if (name && !row.packagedAs.includes(name)) row.packagedAs.push(name);
  return row;
}
async function write(name, data) {
  assert(!packaged.some(x => x.path === slash(name)), `Duplicate package target: ${name}`);
  const file = destination(name);
  pendingWrites.set(file, data);
  packaged.push({ path: slash(name), bytes: Buffer.byteLength(data), sha256: createHash('sha256').update(data).digest('hex') });
}
async function copy(file, name, role) {
  const proof = await remember(file, role, name), data = await fs.readFile(file);
  assert(createHash('sha256').update(data).digest('hex') === proof.sha256, `Source changed while packaging: ${file}`);
  await write(name, data);
}
async function gzip(file, name, role) {
  const proof = await remember(file, role, name), data = await fs.readFile(file);
  assert(createHash('sha256').update(data).digest('hex') === proof.sha256, `Source changed while packaging: ${file}`);
  await write(name, gzipSync(data, { level: 9, mtime: 0 }));
}
// Preserve complete Playwright test records without embedding their screenshots
// a second time. Only known binary Buffer attachments change in the derivative;
// text/JSON bodies, timing, status, errors, stdout and all other metadata remain.
function externalizePlaywrightBinaryAttachments(value, proof) {
  if (!object(value) || !object(value.config) || !Array.isArray(value.suites)) return null;
  const derivative = structuredClone(value), replaced = [];
  const binaryMime = mime => /^(?:audio|video)\//.test(mime) || [
    'image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif',
    'image/avif', 'image/bmp', 'image/tiff', 'image/x-icon', 'image/vnd.microsoft.icon',
    'application/pdf', 'application/zip',
    'application/gzip', 'application/x-zip-compressed',
  ].includes(mime);
  const visit = (suite, pointer) => {
    for (const [specIndex, spec] of (suite.specs ?? []).entries()) {
      for (const [testIndex, test] of (spec.tests ?? []).entries()) {
        for (const [resultIndex, result] of (test.results ?? []).entries()) {
          for (const [attachmentIndex, attachment] of (result.attachments ?? []).entries()) {
            const mime = String(attachment.contentType ?? '').split(';')[0].trim().toLowerCase();
            if (typeof attachment.body !== 'string' || !binaryMime(mime)) continue;
            assert(!Object.hasOwn(attachment, 'externalEvidence'), 'Refusing to overwrite existing attachment metadata.');
            const decoded = Buffer.from(attachment.body, 'base64');
            assert(decoded.toString('base64') === attachment.body, 'Binary attachment is not canonical base64; preserve original and stop packaging.');
            const bodyPointer = `${pointer}/specs/${specIndex}/tests/${testIndex}/results/${resultIndex}/attachments/${attachmentIndex}/body`;
            const reference = {
              kind: 'embedded-binary-in-retained-original',
              originalResults: { path: proof.path, absolutePath: proof.absolutePath, bytes: proof.bytes, sha256: proof.sha256 },
              jsonPointer: bodyPointer, encoding: 'base64',
              decodedBytes: decoded.length, decodedSha256: createHash('sha256').update(decoded).digest('hex'),
            };
            const { body, ...metadata } = attachment;
            result.attachments[attachmentIndex] = { ...metadata, externalEvidence: reference };
            replaced.push({ ...reference, attachmentName: attachment.name ?? null, contentType: attachment.contentType ?? null, encodedBytes: Buffer.byteLength(body) });
          }
        }
      }
    }
    for (const [index, child] of (suite.suites ?? []).entries()) visit(child, `${pointer}/suites/${index}`);
  };
  for (const [index, suite] of derivative.suites.entries()) visit(suite, `/suites/${index}`);
  return replaced.length ? { derivative, replaced } : null;
}
function verifyPlaywrightDerivative(original, sanitized, proof) {
  const restored = structuredClone(sanitized.derivative);
  const at = (value, segments) => segments.reduce((current, key) => {
    assert((object(current) || Array.isArray(current)) && Object.hasOwn(current, key), 'Attachment reference does not resolve in the original record.');
    return current[key];
  }, value);
  const equivalent = (left, right) => {
    if (left === right) return true;
    if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equivalent(value, right[index]));
    if (!object(left) || !object(right)) return false;
    const keys = Object.keys(left);
    return keys.length === Object.keys(right).length && keys.every(key => Object.hasOwn(right, key) && equivalent(left[key], right[key]));
  };
  assert(new Set(sanitized.replaced.map(item => item.jsonPointer)).size === sanitized.replaced.length, 'Duplicate binary attachment reference.');
  for (const reference of sanitized.replaced) {
    const container = reference.originalResults;
    assert(container.path === proof.path && container.absolutePath === proof.absolutePath && container.sha256 === proof.sha256 && container.bytes === proof.bytes, 'Binary attachment points to the wrong original container.');
    assert(reference.encoding === 'base64' && reference.jsonPointer.startsWith('/') && reference.jsonPointer.endsWith('/body'), 'Invalid binary attachment reference.');
    const segments = reference.jsonPointer.slice(1).split('/').map(part => part.replaceAll('~1', '/').replaceAll('~0', '~'));
    const body = at(original, segments);
    assert(typeof body === 'string', 'Original binary attachment body is not a string.');
    const decoded = Buffer.from(body, 'base64');
    assert(decoded.toString('base64') === body && decoded.length === reference.decodedBytes && createHash('sha256').update(decoded).digest('hex') === reference.decodedSha256, 'Decoded attachment hash/size does not match the original body.');
    const attachment = at(restored, segments.slice(0, -1));
    assert(object(attachment) && object(attachment.externalEvidence), 'Sanitized attachment reference missing.');
    const { attachmentName, contentType, encodedBytes, ...expectedReference } = reference;
    assert(equivalent(attachment.externalEvidence, expectedReference) && attachmentName === (attachment.name ?? null) && contentType === (attachment.contentType ?? null) && encodedBytes === Buffer.byteLength(body), 'Derivative attachment metadata/reference does not match its manifest.');
    delete attachment.externalEvidence;
    attachment.body = body;
  }
  assert(equivalent(restored, original), 'Sanitization changed information other than the explicitly referenced binary bodies.');
  return { restoredJsonEquivalent: true, decodedAttachmentsVerified: sanitized.replaced.length, decodedBytesVerified: sanitized.replaced.reduce((total, item) => total + item.decodedBytes, 0) };
}
function externalizeLighthouseScreenshotData(value, proof) {
  if (!object(value) || typeof value.lighthouseVersion !== 'string' || !object(value.audits)) return null;
  const derivative = structuredClone(value), replaced = [];
  const replace = (container, key, pointer) => {
    const data = container[key];
    assert(typeof data === 'string', 'Lighthouse screenshot payload is not a string.');
    const match = /^(data:(image\/(?:jpeg|jpg|png|webp|gif|avif));base64,)([A-Za-z0-9+/]*={0,2})$/i.exec(data);
    assert(match, 'Lighthouse screenshot payload is not a supported base64 image data URL.');
    const decoded = Buffer.from(match[3], 'base64');
    assert(decoded.length > 0 && decoded.toString('base64') === match[3], 'Lighthouse screenshot base64 is empty/noncanonical.');
    const reference = {
      kind: 'embedded-lighthouse-screenshot-in-retained-original',
      originalResults: { path: proof.path, absolutePath: proof.absolutePath, bytes: proof.bytes, sha256: proof.sha256 },
      jsonPointer: pointer, encoding: 'base64-data-url', mimeType: match[2].toLowerCase(), dataUrlPrefix: match[1],
      decodedBytes: decoded.length, decodedSha256: createHash('sha256').update(decoded).digest('hex'),
    };
    container[key] = { externalEvidence: reference };
    replaced.push({ ...reference, encodedBytes: Buffer.byteLength(match[3]), originalStringBytes: Buffer.byteLength(data) });
  };
  const filmstrip = derivative.audits['screenshot-thumbnails'];
  if (filmstrip?.details?.type === 'filmstrip') {
    assert(filmstrip.id === 'screenshot-thumbnails' && Array.isArray(filmstrip.details.items), 'Malformed Lighthouse filmstrip audit.');
    filmstrip.details.items.forEach((item, index) => {
      assert(object(item), 'Malformed Lighthouse filmstrip frame.');
      replace(item, 'data', `/audits/screenshot-thumbnails/details/items/${index}/data`);
    });
  }
  const final = derivative.audits['final-screenshot'];
  if (final?.details?.type === 'screenshot') {
    assert(final.id === 'final-screenshot', 'Malformed Lighthouse final-screenshot audit.');
    replace(final.details, 'data', '/audits/final-screenshot/details/data');
  }
  if (derivative.fullPageScreenshot != null) {
    assert(object(derivative.fullPageScreenshot) && object(derivative.fullPageScreenshot.screenshot), 'Malformed Lighthouse full-page screenshot.');
    replace(derivative.fullPageScreenshot.screenshot, 'data', '/fullPageScreenshot/screenshot/data');
  }
  // Unverified schema variants and every other data field remain untouched.
  return replaced.length ? { derivative, replaced } : null;
}
function verifyLighthouseDerivative(original, sanitized, proof) {
  const restored = structuredClone(sanitized.derivative);
  const at = (value, segments) => segments.reduce((current, key) => {
    assert((object(current) || Array.isArray(current)) && Object.hasOwn(current, key), 'Lighthouse reference does not resolve in original report.');
    return current[key];
  }, value);
  const equivalent = (left, right) => {
    if (left === right) return true;
    if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equivalent(value, right[index]));
    if (!object(left) || !object(right)) return false;
    const keys = Object.keys(left);
    return keys.length === Object.keys(right).length && keys.every(key => Object.hasOwn(right, key) && equivalent(left[key], right[key]));
  };
  assert(new Set(sanitized.replaced.map(item => item.jsonPointer)).size === sanitized.replaced.length, 'Duplicate Lighthouse screenshot reference.');
  for (const reference of sanitized.replaced) {
    const container = reference.originalResults;
    assert(container.path === proof.path && container.absolutePath === proof.absolutePath && container.sha256 === proof.sha256 && container.bytes === proof.bytes, 'Lighthouse screenshot points to the wrong original container.');
    assert(reference.encoding === 'base64-data-url' && /^(?:\/audits\/screenshot-thumbnails\/details\/items\/\d+\/data|\/audits\/final-screenshot\/details\/data|\/fullPageScreenshot\/screenshot\/data)$/.test(reference.jsonPointer), 'Lighthouse reference targets an unapproved field.');
    const segments = reference.jsonPointer.slice(1).split('/');
    const data = at(original, segments), match = typeof data === 'string' && /^(data:(image\/(?:jpeg|jpg|png|webp|gif|avif));base64,)([A-Za-z0-9+/]*={0,2})$/i.exec(data);
    assert(match && match[1] === reference.dataUrlPrefix && match[2].toLowerCase() === reference.mimeType, 'Lighthouse MIME/prefix differs from original.');
    const decoded = Buffer.from(match[3], 'base64');
    assert(decoded.length > 0 && decoded.toString('base64') === match[3] && decoded.length === reference.decodedBytes && createHash('sha256').update(decoded).digest('hex') === reference.decodedSha256, 'Lighthouse decoded screenshot hash/size differs from original.');
    const { encodedBytes, originalStringBytes, ...expectedReference } = reference;
    assert(encodedBytes === Buffer.byteLength(match[3]) && originalStringBytes === Buffer.byteLength(data) && equivalent(at(restored, segments), { externalEvidence: expectedReference }), 'Lighthouse derivative reference metadata differs from manifest.');
    at(restored, segments.slice(0, -1))[segments.at(-1)] = data;
  }
  assert(equivalent(restored, original), 'Lighthouse sanitization changed nonbinary audit/report information.');
  return { restoredJsonEquivalent: true, decodedAttachmentsVerified: sanitized.replaced.length, decodedBytesVerified: sanitized.replaced.reduce((total, item) => total + item.decodedBytes, 0) };
}
async function archiveJSON(file, name, role) {
  const proof = await remember(file, role), data = await fs.readFile(file);
  assert(createHash('sha256').update(data).digest('hex') === proof.sha256, `Source changed while packaging: ${file}`);
  let value;
  try { value = JSON.parse(data.toString('utf8').replace(/^\uFEFF/, '')); }
  catch (error) {
    // Interrupted diagnostics can leave invalid JSON. Preserve those exact bytes
    // and the parse failure instead of silently dropping the failed attempt.
    failures.push({ source: originalPath(file), field: 'JSON parsing', value: String(error) });
    if (!proof.packagedAs.includes(name)) proof.packagedAs.push(name);
    await write(name, gzipSync(data, { level: 9, mtime: 0 }));
    return null;
  }
  let sanitized, preservationCheck, sourceFormat;
  try {
    sanitized = externalizePlaywrightBinaryAttachments(value, proof);
    if (sanitized) {
      sourceFormat = 'playwright';
      preservationCheck = verifyPlaywrightDerivative(value, sanitized, proof);
    } else {
      sanitized = externalizeLighthouseScreenshotData(value, proof);
      if (sanitized) {
        sourceFormat = 'lighthouse';
        preservationCheck = verifyLighthouseDerivative(value, sanitized, proof);
      }
    }
  } catch (error) {
    // A syntactically valid interrupted/malformed record, or a failed preservation
    // invariant, keeps its complete original bytes. Never write a partial derivative.
    failures.push({ source: originalPath(file), field: 'Binary-evidence transformation/preservation', value: String(error) });
    proof.roles.push('Exact original retained after attachment transformation/preservation failure');
    if (!proof.packagedAs.includes(name)) proof.packagedAs.push(name);
    await write(name, gzipSync(data, { level: 9, mtime: 0 }));
    return value;
  }
  if (!sanitized) {
    if (!proof.packagedAs.includes(name)) proof.packagedAs.push(name);
    await write(name, gzipSync(data, { level: 9, mtime: 0 }));
  } else {
    assert(name.endsWith('.json.gz'), 'Sanitized output requires a JSON gzip target.');
    const sanitizedName = name.slice(0, -'.json.gz'.length) + (sourceFormat === 'lighthouse' ? '.screenshots-externalized.json.gz' : '.sanitized.json.gz');
    const transformation = {
      source: proof.path, sourceSha256: proof.sha256, sourceBytes: proof.bytes, packagedAs: sanitizedName, sourceFormat,
      method: sourceFormat === 'lighthouse'
        ? 'Only verified Lighthouse filmstrip/final/full-page screenshot data URLs replaced with original-container pointers, original MIME/prefix and decoded hashes. All audits, scores, categories, warnings, timing, environment, dimensions and nodes remain. Exact original remains immutable external evidence.'
        : 'Only known binary base64 attachment bodies replaced with original-container JSON pointers and decoded-byte hashes. All test outcomes, timing, errors, stdout, attachment metadata and text/JSON attachments retained. Original result remains immutable external evidence.',
      preservationCheck,
      binaryAttachments: sanitized.replaced,
    };
    proof.roles.push(`Complete original ${sourceFormat} result retained externally; referenced-binary derivative packaged`);
    proof.derivedPackagedAs = [...(proof.derivedPackagedAs ?? []), sanitizedName];
    derivations.push(transformation);
    await write(sanitizedName, gzipSync(JSON.stringify(sanitized.derivative, null, 2) + '\n', { level: 9, mtime: 0 }));
  }
  return value;
}
const writeJSON = (name, value) => write(name, JSON.stringify(value, null, 2) + '\n');
const sourceIdentity = value => {
  const head = value?.expected ?? value?.expectedSha ?? value?.expectedHead ?? value?.commit ?? value?.sourceHead ?? value?.sourceCommit ?? value?.head ?? null;
  return { head, expectedHeads: value?.expectedHeads ?? null, classification: head ? Object.values(heads).includes(head) ? 'current-selected-source' : 'prior-or-other-source' : 'source-specific-identity-in-raw-record', protocol: value?.harnessVersion ?? value?.methodVersion ?? null };
};
function collectFailures(value, source, pointer = '$', identity = sourceIdentity(value)) {
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    const current = `${pointer}.${key}`;
    const flag = child === false && (/(?:pass|passed|success)$/i.test(key) || /^(?:healthStable|allExactHeadHealth|completeUnpausedWindow|validHeads)$/.test(key) || pointer.endsWith('.gates'));
    const error = /^(?:error|failure|fatal|observationTimeout|pageErrors|consoleErrors|httpErrors|blockedWrites)$/.test(key) && (Array.isArray(child) ? child.length > 0 : Boolean(child));
    const attempted = key === 'attemptedCount' && Number.isFinite(child) && child > 0 && pointer.endsWith('.networkWrites');
    if (flag || error || attempted) failures.push({ source, identity, field: current, value: child });
    else if (child && typeof child === 'object') collectFailures(child, source, current, identity);
  }
}
for (const [key, value] of Object.entries(values)) collectFailures(value, originalPath(required[key]));

for (const [file, expected] of themeEquivalenceChecks) {
  const proof = await remember(file, 'Final theme image-equivalence member; actual SHA checked against visual review');
  assert(proof.sha256 === expected.sha256, `Theme screenshot equivalence claim fails: ${expected.key}`);
}
for (const [key, value] of Object.entries(walkHarnesses)) assert(await digest(required[`harness_${key}`]) === value.sha256, `${key} harness differs from its recorded campaign SHA256.`);
const copies = [
  ['summary', 'timings-and-static.json'], ['attribution', 'build-attribution.json'], ['semantic', 'semantic-gate-final.json'],
  ['lighthouse', 'lighthouse-classification.json'], ['startup', 'startup-analysis.json'],
  ['themeWalk', 'contrast/walk-verified.json'], ['themeSite', 'contrast/site-verified.json'],
  ['themeWalkReview', 'contrast/walk-visual-review.json'], ['themeSiteReview', 'contrast/site-visual-review.json'],
  ['walk', 'walk/compact.json'], ['walkReview', 'walk/REVIEW.md'],
  ['site', 'site/preview-smoke.json'], ['sitePlan', 'site/plan-projection.json'], ['sitePlanReview', 'site/plan-visual-review.json'], ['rules', 'rules-static.json'],
  ['visibleRules', 'rules-visible.json'], ['ci', 'ci-status.json'], ['publication', 'source-publication.json'],
];
for (const [key, name] of copies) await copy(required[key], name, `Final required Round3 ${key} evidence; original source retained`);
await copy(configurationPath, 'package-inputs-final.json', 'Explicit final configuration and recorded harness identities');
for (const [key, value] of Object.entries(walkHarnesses)) await copy(required[`harness_${key}`], key === 'config' ? 'harness/run-config.mjs' : `harness/walk/${path.basename(value.path)}`, `Selected current-head Walk ${key} source; recorded SHA256 verified before output`);
await gzip(required.loads, 'raw40loads.json.gz', 'Every formal load, including errors and slow samples');
await gzip(required.network, 'network-audit.json.gz', 'Every paired network observation and original request row');
for (const branch of ['base', 'walk', 'site']) await gzip(required[`build_${branch}`], `builds/${branch}-audit.json.gz`, 'Final emitted graph/module/HTML and complete asset byte/hash inventory');
const earlySet = branch => new Set(values[`build_${branch}`].early.map(row => row.file));
const lateAssets = Object.fromEntries(['walk', 'site'].map(branch => {
  const early = earlySet(branch);
  return [branch, values[`build_${branch}`].assets.filter(x => !early.has(x.file) && /\.(?:js|css)$/.test(x.file)).map(x => ({ file: x.file, raw: x.bytes, gzip: x.gzipBytes, sha256: x.sha256, imports: x.imports, dynamicImports: x.dynamicImports }))];
}));
await writeJSON('late-assets.json', { note: 'Every non-early JS/CSS asset from final controlled builds; includes unrelated existing late assets, not all charged to World.', branches: lateAssets });
await writeJSON('network-summary.json', {
  at: network.at, baseCommit: network.baseCommit, label: network.label, method: network.method,
  branches: Object.fromEntries(Object.entries(network.branches).map(([branch, value]) => [branch, {
    perPair: value.perPair, newRequestNames: value.newRequestNames, missingRequestNames: value.missingRequestNames,
    featureRequestsBeforePicture: value.featureRequestsBeforePicture, noNewRequestsEveryPair: value.noNewRequestsEveryPair,
    observedStaticRawDelta: value.observedStaticRawDelta, observedStaticGzipDelta: value.observedStaticGzipDelta,
  }])),
});

// Every Round3 run is retained. Full trace/profile binaries stay in scratch with
// hashes; non-trace JSON/log/markdown samples travel compressed. Verified binary
// Playwright/Lighthouse image payloads become explicit external references.
// This includes failed old-source diagnostics, full test records and every interval.
const largeTrace = file => /(?:trace|cpu[-_]?profile|\.cpuprofile)(?:[._-]|$)/i.test(path.basename(file)) && !/(?:summary|attribution|review|manifest)/i.test(path.basename(file));
const roundDirectories = (await fs.readdir(round, { withFileTypes: true })).filter(entry => entry.isDirectory()).map(entry => entry.name);
const evidenceRoots = [...new Set(['results', 'startup-diagnostic', 'plumbing', 'verification', ...roundDirectories.filter(name => /^(?:dark-contrast|footer-tests|theme-tests|lighthouse)(?:$|[-_])/.test(name))])];
for (const directory of evidenceRoots) {
  const absolute = sourcePath(directory);
  try { await fs.access(absolute); } catch { continue; }
  for (const file of await files(absolute)) {
    if (sources.has(file)) continue;
    const relative = slash(path.relative(round, file));
    if (!largeTrace(file) && /\.(?:json|md|log|txt)$/.test(file)) {
      if (file.endsWith('.json')) {
        collectFailures(await archiveJSON(file, `raw/${relative}.gz`, 'Original Round3 run/verification; its own source head and protocol remain authoritative'), originalPath(file));
      } else await gzip(file, `raw/${relative}.gz`, 'Original Round3 run/verification; its own source head and protocol remain authoritative');
    } else await remember(file, largeTrace(file) ? 'Large raw trace/profile retained outside package; SHA and bytes recorded' : 'Original visual/binary evidence retained outside compact package');
  }
}
const samples = [...sources.values()].filter(row => row.path.includes('/round3/results/r3-walk-') && row.path.endsWith('.json'));
assert(samples.some(row => /walk-(?:framerate|frames)/.test(row.path)), 'No complete Round3 frame-window file was found.');
assert(samples.some(row => /walk-performance/.test(row.path)), 'No complete Round3 input file was found.');
assert(samples.some(row => /walk-functional/.test(row.path)), 'No complete Round3 functional file was found.');

for (const file of await files(sourcePath(inputs.printDirectory))) await copy(file, `site/print/${slash(path.relative(sourcePath(inputs.printDirectory), file))}`, 'Final exact-head PDF and every inspected rendering, including warnings/review');
for (const file of await files(sourcePath(inputs.siteDirectory))) {
  if (sources.has(file)) continue;
  if (/\.jpg$/i.test(file)) await copy(file, `site/${path.basename(file)}`, 'Final exact-head UI screenshot');
  else await remember(file, 'Final Site G ancillary artifact; dedicated print campaign supplies all-page proof');
}
// Earlier Site campaigns, if any, are immutable failed attempts, not replacements.
for (const entry of await fs.readdir(round, { withFileTypes: true })) {
  if (!entry.isDirectory() || !/^site-(?:g|print)-/.test(entry.name) || [inputs.siteDirectory, inputs.printDirectory].includes(entry.name)) continue;
  for (const file of await files(sourcePath(entry.name))) {
    if (/\.(?:json|md|log)$/.test(file)) {
      if (file.endsWith('.json')) collectFailures(await archiveJSON(file, `prior-site/${slash(path.relative(round, file))}.gz`, 'Earlier retained Site attempt; final identity is separate'), originalPath(file));
      else await gzip(file, `prior-site/${slash(path.relative(round, file))}.gz`, 'Earlier retained Site attempt; final identity is separate');
    } else await remember(file, 'Earlier Site PDF/image retained outside current compact package');
  }
}
for (const entry of await fs.readdir(round, { withFileTypes: true })) {
  if (!entry.isFile() || !/\.(?:json|md|log)$/.test(entry.name)) continue;
  const file = sourcePath(entry.name);
  if (sources.has(file)) continue;
  // Round3 narrative/diagnostics may carry old-source evidence; preserve labels.
  if (file.endsWith('.json')) collectFailures(await archiveJSON(file, `context/${entry.name}.gz`, 'Round3 source/diagnostic/verification context with original labels'), originalPath(file));
  else await gzip(file, `context/${entry.name}.gz`, 'Round3 source/diagnostic/verification context with original labels');
}
for (const [key, name] of [['siteHarness', 'site-seven-cases.mjs'], ['sitePrintHarness', 'site-print.mjs'], ['sitePdfHarness', 'site-print-pdf.mjs']]) await copy(required[key], `harness/${name}`, 'Read-only copy of harness used for Site proof');
for (const entry of await fs.readdir(sourcePath('harness'), { withFileTypes: true })) {
  if (entry.isFile() && /^walk-functional-phone-door.*\.mjs$/.test(entry.name)) await copy(sourcePath(`harness/${entry.name}`), `harness/prior-phone/${entry.name}`, 'Retained old-head phone diagnostic source; does not substitute for selected current campaign');
}
await copy(script, 'harness/package-round3.mjs', 'Package source, fixed output guard and identity validation');

const timingRows = Object.entries(summary.timings).flatMap(([branch, value]) => value.rows.map(row => ({ branch, ...row })));
const candidates = startup.rows.filter(row => ['walk', 'site'].includes(row.target));
assert(candidates.length === 20, 'Startup analysis must retain twenty candidate loads.');
const aggregate = rows => rows.includes(false) ? false : rows.length > 0 && rows.every(x => x === true) ? true : null;
const paired = aggregate(timingRows.map(row => row.gates.pairedWall && row.gates.pairedCanvas));
const numericSeam = aggregate(Object.values(attribution.branches).map(row => row.count === 28 && Number.isFinite(row.gzipDelta) && row.gzipDelta <= 1024));
const requestGate = aggregate(Object.values(network.branches).map(row => row.noNewRequestsEveryPair && row.featureRequestsBeforePicture.length === 0));
const fcpCount = candidates.filter(row => Number.isFinite(row.fcpMs) && row.fcpMs <= 1000).length;
const fcpPrerequisite = aggregate(candidates.map(row => Number.isFinite(row.fcpMs) ? row.fcpMs <= 1000 : null));
const paint = startup.loadingPanelPaint;
if (paint) {
  assert(paint.heads?.walk === heads.walk && paint.heads?.site === heads.site && (paint.passed === true || paint.passed === false || paint.passed === null) && typeof paint.reason === 'string', 'Optional loader-paint proof needs current heads, tri-state result and reason.');
  const proofPath = sourcePath(paint.source);
  assert((await fs.stat(proofPath)).isFile(), 'Loader-paint proof source missing.');
  await copy(proofPath, 'loading-panel-paint.json', 'Current-head actual loader-paint proof; distinct from FCP prerequisite');
}
const loadingPanelGate = aggregate([fcpPrerequisite, paint?.passed ?? null]);
const semanticGate = aggregate(Object.values(semantic.branches).map(row => row.passed));
const gateRows = [
  ['Exact-head formal health', status(loads.healthStable), 'All forty loads and before/after health retained.'],
  ...devices.map(device => [
    `Absolute ${device === 'desktop' ? 'laptop' : device} first picture`, status(aggregate(timingRows.filter(row => row.device === device).map(row => row.gates.absoluteWall && row.gates.absoluteCanvas))),
    timingRows.filter(row => row.device === device).map(row => `${row.branch}: wall ${n(row.medians.previewWallMs)} / canvas ${n(row.medians.previewCanvasMs)} ms`).join('; '),
  ]),
  ['Relative median <=110% of base', status(paired), 'Gate compares medians. Every individually slower pair also remains.'],
  ['Candidate FCP within 1 s prerequisite', status(fcpPrerequisite), `${fcpCount}/${candidates.length}; this does not identify the loader.`],
  ['Loading panel paint within 1 s', status(loadingPanelGate), paint?.reason ?? 'Current-head loader-specific paint proof not supplied; FCP alone cannot make this PASS.'],
  ['Early28-file closure / gzip ceiling <=1024', status(numericSeam), Object.entries(attribution.branches).map(([branch, row]) => `${branch}: ${row.count}files, ${row.gzipDelta >= 0 ? '+' : ''}${row.gzipDelta}`).join('; ') + '; semantic lazy-seam attribution is separate.'],
  ['Early semantic lazy-seam restriction', status(semanticGate), 'Current-head source classifications and deferred implementation checks in semantic-gate-final.json.'],
  ['No new pre-picture requests', status(requestGate), 'Full network rows and feature starts retained.'],
  ...Object.entries(walk.gates).map(([key, value]) => [`Walk: ${key}`, status(value), 'See compact review and all original samples; no failed sample removed.']),
  ['Site G/E seven cases', status(site.passed), 'Two device sizes; production-negative guard is a labelled healthcheck simulation.'],
  ['Site concave plan / held hydration', `${status(sitePlan.passed)} / visual ${status(sitePlanReview.visualPassed)}`, 'Four current-head native/pending-plan observations and completed image inspection.'],
  ['Actual A4 automated / visual', `${status(print.automatedPassed)} / ${status(print.visualPassed)}`, `${print.inspectedPages.length} rendered pages inspected; failed attempts remain.`],
  ['Static rules', status(aggregate(rules.map(row => row.pass))), 'Protected source/tests/settings/dependencies and ancestry.'],
  ['Visible rules', status(visibleRules.passed), 'All eight screen observations retained.'],
  ['Final normal-source automated theme contrast', status(aggregate([values.themeWalk.passed, values.themeSite.passed])), 'Four exact-head tests per branch; no style injection; all raw readings/failures retained.'],
  ['Final theme screenshot review', status(aggregate([values.themeWalkReview.visualPassed, values.themeSiteReview.visualPassed])), 'Every extracted final PNG/JPG is explicitly covered; claimed byte-identical representatives are SHA-verified.'],
  ['Final theme automated AND visual gate', status(aggregate([values.themeWalk.passed, values.themeSite.passed, values.themeWalkReview.visualPassed, values.themeSiteReview.visualPassed])), 'A passing automated sample cannot override a failed visual review.'],
];
const pairTables = timingRows.map(row => `### ${row.branch} / ${row.device}\n\n${table(
  ['Run', 'Base wall ms', 'Preview wall ms', 'Custom wall ms', 'Base canvas ms', 'Preview canvas ms', 'Custom canvas ms', 'Loader DOM ms', 'Preview FCP ms', 'Failures'],
  row.pairs.map(pair => [pair.run, n(pair.baseWallMs), n(pair.previewWallMs), n(pair.customWallMs), n(pair.baseCanvasMs), n(pair.previewCanvasMs), n(pair.customCanvasMs), n(pair.previewLoadingSeenMs), n(pair.previewFcpMs), pair.failures.length ? JSON.stringify(pair.failures) : 'none'])
)}`).join('\n\n');
const inputRows = walk.input.flatMap(row => (row.keyboard || []).map(mode => [row.device, mode.mode, mode.values.map(value => n(value)).join(', '), n(mode.max), `${mode.below50}/${mode.count}`]));
const frameRows = walk.frames.map(row => [row.device, row.mode, row.count, exact(row.activeMs), exact(row.pausedMs), exact(row.fps), exact(row.low1), exact(row.maxIntervalMs), status(row.strictFpsPass), status(row.completeUnpausedWindow)]);
const entryRows = walk.preparationDecision.entryComparison.map(row => [row.device, exact(row.round2EntryMs), exact(row.currentEntryMs), exact(row.deltaMs)]);
const siteRows = site.rows.map(row => [row.case, row.device, status(row.passed), (row.pageErrors || []).length, (row.consoleErrors || []).length, (row.httpErrors || []).length, (row.providerRequests || []).length, JSON.stringify(row.networkWrites || {}), row.error || '']);
const lhRows = Object.entries(lighthouse.branches).flatMap(([branch, row]) => row.remaining.map(item => [branch, item.route, item.id, item.actual, item.expected, item.reason]));
const ciRows = Object.entries(ci.branches).flatMap(([branch, row]) => row.checks.map(check => [branch, check.name, check.status ?? '', check.conclusion ?? '', `[run](${check.url})`]));
const htmlRows = Object.entries(attribution.branches).flatMap(([branch, row]) => row.html.map(item => [branch, item.file, item.beforeRaw, item.afterRaw, item.rawDelta, item.beforeGzip, item.afterGzip, item.gzipDelta]));
const lateWorld = Object.entries(lateAssets).flatMap(([branch, rows]) => rows.filter(row => /(?:WalkLauncher|walk-animation|walk-controls|\/runtime-|SiteEntry|hydration-|SiteMap|maplibre)/.test(row.file)).map(row => [branch, row.file, row.raw, row.gzip]));
const retainedSamples = samples.filter(row => row.packagedAs.length).map(row => [row.path, row.packagedAs.map(name => `[raw](${name})`).join(', ')]);
const finalNetworkCounts = {
  formal: loads.rows.reduce((count, row) => count + (row.blockedWrites || []).length, 0),
  site: site.networkWrites,
  pdf: printRaw.rows.map(row => ({ device: row.device, blockedWrites: row.blockedWrites, pageErrors: row.pageErrors, consoleErrors: row.consoleErrors, httpErrors: row.httpErrors })),
};

const report = `# World Finish — Round 3 evidence

Base: \`${heads.base}\`. Walk: \`${heads.walk}\`. Site: \`${heads.site}\`.

This report lists measured outcomes, including failures, rather than granting merge approval. Diagnostics and older-source attempts keep their original commit/protocol labels. The common closure documents own the final per-item three-round dispositions; this evidence package does not turn OPEN limitations into passing scores.

## Current gates

${table(['Gate', 'Result', 'Evidence / limit'], gateRows)}

## Every formal first-picture pair

Five fresh pairs per branch/device; forty unique recorded loads. The relative gate compares medians, not every individual pair. All slow and failed runs remain in [raw forty loads](raw40loads.json.gz). Wall observation and browser canvas mark are separate. The custom-host observations are an operational reference, not the same-host baseline.

${table(['Branch', 'Device', 'Base wall median', 'Preview wall median', 'Base canvas median', 'Preview canvas median', 'Wall ratio', 'Canvas ratio'], timingRows.map(row => [row.branch, row.device, n(row.medians.baseWallMs), n(row.medians.previewWallMs), n(row.medians.baseCanvasMs), n(row.medians.previewCanvasMs), n(row.wallRatio, 4), n(row.canvasRatio, 4)]))}

${pairTables}

## Loading, requests and writes

${fcpCount}/${candidates.length} candidate FCPs meet one second. DOM visibility alone is not paint. FCP establishes content paint but does not identify the loader; preserve the actual-pixel diagnostic separately. responseStart includes connection/TLS and must not be called pure server latency. [Startup analysis](startup-analysis.json) contains the current rows; no R2 numerical result is promoted here.

${table(['Branch', 'Compared pairs', 'New names', 'Early feature requests', 'No-new-request gate'], Object.entries(network.branches).map(([branch, row]) => [branch, row.perPair.length, row.newRequestNames.length, row.featureRequestsBeforePicture.length, status(row.noNewRequestsEveryPair)]))}

Current campaign write/error counters, without filtering hosting requests: \`${JSON.stringify(finalNetworkCounts)}\`. Raw attempted and blocked writes remain in their source records. A blocked request is not transmitted, but is still an attempted write and must not be reported as zero. Earlier diagnostics are in the source/failure manifests rather than silently included in a universal clean claim.

## Final emitted build and HTML

${table(['Build', 'Early files', 'Raw', 'Gzip', 'Raw delta', 'Gzip delta'], [['base', attribution.baseline.count, attribution.baseline.raw, attribution.baseline.gzip, 0, 0], ...Object.entries(attribution.branches).map(([branch, row]) => [branch, row.count, row.raw, row.gzip, row.rawDelta, row.gzipDelta])])}

Final Vite output after preload transforms is authoritative. The numerical 1,024-gzip ceiling is distinct from the semantic allowed-seam rule; module attribution names all adapters and is not claimed to be gzip attribution. [Build attribution](build-attribution.json) retains module changes, finalization and HTML evidence; complete emitted audits are under builds/. No literal zero-byte claim is made.

[Current semantic gate](semantic-gate-final.json) classifies every changed early module. General startup changes and repairs to existing accessibility are reported separately from the lazy bootstrap; a numeric byte pass cannot grant semantic permission.

${table(['Branch', 'HTML', 'Before raw', 'After raw', 'Raw delta', 'Before gzip', 'After gzip', 'Gzip delta'], htmlRows)}

Recognized deferred World chunks are listed below; [all late assets](late-assets.json) preserves every non-early JS/CSS asset, including unrelated existing late assets. Filename grouping is descriptive, not proof of when a request starts; the network audit supplies that proof.

${table(['Branch', 'Deferred asset', 'Raw bytes', 'Gzip bytes'], lateWorld)}

## Walk: input, frames and all functional attempts

${table(['Device', 'View', 'Every keyboard latency ms', 'Maximum ms', 'Samples under 50 ms'], inputRows)}

The unchanged zero-settle protocol and Start-to-ready cost are retained in [Walk compact](walk/compact.json) and [review](walk/REVIEW.md). Native touch arrays and every original sample remain in raw files. Render submission is not photon latency. Deferred shader preparation is not automatically proof that a prior GPU stall was shader compilation; only the measured current samples support performance conclusions.

${table(['Device', 'Round2 Start-to-ready ms', 'Current Start-to-ready ms', 'Delta ms'], entryRows)}

Preparation decision: **${esc(walk.preparationDecision.decision)}**. ${esc(walk.preparationDecision.reason)}

${table(['Device', 'View', 'Frames', 'Active ms', 'Paused ms', 'FPS', '1% low', 'Max interval ms', 'FPS gate', 'Full window'], frameRows)}

${table(['Original Round3 sample', 'Complete compressed copy'], retainedSamples)}

Old-source phone delivery probes include two no-click failures and an instrumented pass on unchanged application code. They remain diagnostics with their own identity. The pass does not establish a cause or a product fix and does not erase failures. Current-head native functional status is taken only from the current compact and raw samples. Physical one-hand comfort and ten-second first-user comprehension remain separate human-evidence criteria, not claims supplied by browser emulation or controls copy.

## Site: current live/offline cases and actual A4 output

${table(['Case', 'Device', 'Result', 'JS errors', 'Console errors', 'HTTP errors', 'Provider requests', 'Write counters', 'Error'], siteRows)}

The seven-case harness exercises delayed loading-dialog ownership, explicit search, drawing, keyboard edit/Undo, remove/clear Undo, map attribution, offline source labels/three areas, survey traverse and print lifecycle at both sizes. Actual provider responses are not substituted. The production-negative guard is a labelled healthcheck simulation, not a production-deployment test. User-drawn plots are not verified parcels. See [all case details](site/preview-smoke.json); coverage names do not imply a failing row passed.

The deferred plan adapter has separate [concave placement and held-hydration observations](site/plan-projection.json) plus [completed visual review](site/plan-visual-review.json). Native plan result${status(sitePlan.passed)}, visual result${status(sitePlanReview.visualPassed)}, visible north arrow${status(sitePlanReview.northArrowVisible)}, pending quantity withheld${status(sitePlanReview.pendingQuantityAbsent)}. All raw attempts and errors remain separate from the seven-case campaign.

Dedicated same-head PDFs: automated ${status(print.automatedPassed)}, visual ${status(print.visualPassed)}. ${print.inspectedPages.length} rendered pages were individually inspected; minimum reported body/footer gap ${n(print.minimumBodyFooterGapMm, 3)} mm. Complete disclaimer every page: ${status(print.disclaimerEveryPage)}; overlap/clipping observed: ${String(print.overlapOrClipping)}; screen unchanged: ${status(print.screenUnchanged)}. [Completed visual review](site/print/visual-review.json) and [notes](site/print/VISUAL-REVIEW.md) resolve the raw export's initial pending-review label. Render warnings and earlier failures remain, with no edited or substituted PDF pixels.

${table(['Inspected page', 'Image'], print.inspectedPages.map(file => [file, `[view](site/print/${file})`]))}

[Laptop PDF](site/print/report-laptop-a4.pdf), [phone PDF](site/print/report-phone-a4.pdf). Phone means a 390×844 touch viewport on a laptop; no physical-phone/human study is claimed. Existing Stage2 calculation/provider/licence coverage is historical supporting evidence, not a newly rerun R3 scenario.

## CI, Lighthouse and immutable rules

Normal-source automated theme result: Walk${status(values.themeWalk.passed)}, Site${status(values.themeSite.passed)}. Visual screenshot result: Walk${status(values.themeWalkReview.visualPassed)}, Site${status(values.themeSiteReview.visualPassed)}. The final theme gate requires both kinds of evidence to pass. Automated reports retain four distinct tests, exact before/after heads, non-injected styles, every minimum ratio and check count. [Walk contrast](contrast/walk-verified.json), [Site contrast](contrast/site-verified.json), [Walk visual review](contrast/walk-visual-review.json) and [Site visual review](contrast/site-visual-review.json) retain current-source scope/findings. Every final extracted image is explicitly covered; any representative/member equivalence is checked against actual SHA256s. Earlier numerical passes with visual failures remain failures of the combined gate, with their original labels. All contrast/footer/theme/Lighthouse directories are represented in the source manifest. Full Playwright test records retain statuses, timing, errors, stdout and attachment metadata; only embedded binary bodies are replaced with external references in clearly named sanitized derivatives. Text/JSON attachments and extracted contrast/health records remain fully packaged. Original results and surplus screenshots/artifacts remain outside the package with hashes.

${table(['Branch', 'Check', 'Status', 'Conclusion', 'Run'], ciRows)}

${table(['Branch', 'Baseline errors', 'Removed', 'Remaining', 'New error IDs', 'Warnings'], Object.entries(lighthouse.branches).map(([branch, row]) => [branch, lighthouse.baseline.errorCount, row.removedErrorCount, row.remainingErrorCount, JSON.stringify(row.newErrors), row.warnings?.count ?? 'unreported']))}

Full Lighthouse audit records remain packaged in clearly named screenshots-externalized derivatives when embedded images are present. Only the verified filmstrip, final-screenshot and root full-page screenshot data URLs change into external references; scores, every audit, warnings/errors, timings, category/configuration metadata, dimensions and the full-page nodes map remain unchanged. Exact originals are externally hashed, and full-record reconstruction is checked before writing. Unknown screenshot schema variants remain untouched.

H permits specifically documented inherited assertions that cannot be safely repaired under unchanged rules; it does not demand a fabricated all-green Lighthouse result. It also requires every safe fix, so inherited status alone is not a waiver. Each remaining cause and actual value follows, without altering thresholds:

${table(['Branch', 'Route', 'Assertion', 'Actual', 'Expected', 'Reason'], lhRows)}

[Static rules](rules-static.json), [eight visible screens](rules-visible.json), and [publication/ancestry](source-publication.json) retain exact source identities. No new environment, account, key, migration, production merge or manual deploy is authorized by this evidence. Local verification logs retain their original tested heads; do not replace exact-head CI with a historical local pass or describe inherited lint failures as clean.

## Preservation and budget

[FAILURES.json](FAILURES.json) lists observed failed flags/errors/write attempts with original paths; every source remains immutable. Complete Round3 load/input/functional/frame samples are gzip copies with original hashes. [Binary attachment derivations](BINARY-ATTACHMENT-DERIVATIONS.json) identify every replaced base64 body/data URL by its JSON pointer in the preserved original result, original file hash/size, exact encoding/MIME prefix where applicable and decoded binary hash/size; all other test/audit information remains in the derivative. Large traces/profiles, complete originals of those Playwright/Lighthouse results and surplus diagnostic images remain outside this compact package with their absolute/original paths, bytes and SHA-256 in [SOURCE-MANIFEST.json](SOURCE-MANIFEST.json). No slow run or failed attempt is deleted to obtain a passing result.

[PACKAGE-MANIFEST.json](PACKAGE-MANIFEST.json) gives every packaged file and byte count. Strong target: under3 MB; soft budget:3.8 MB. Package plus configured retained docs must be under5,000,000bytes in each PR. Retained-doc inputs are Walk${retainedDocsBytes.walk}bytes and Site${retainedDocsBytes.site}bytes; the coordinator must recheck the combined directory before installation. All final PDF pages/PDFs and complete raw loads/Walk samples are retained; surplus pitch/screenshots stay in scratch with hashes. This packager writes only this fresh chat output directory, never either repository or Round2 evidence.
`;
await write('REPORT.md', report);
await writeJSON('FAILURES.json', {
  note: 'Failed flags/errors/writes are retained evidence, not waived. Original raw files contain full context. Human-evidence gaps and exception decisions are separately documented.',
  observations: failures,
  walkGates: walk.gates,
  currentTimingGates: timingRows.map(row => ({ branch: row.branch, device: row.device, gates: row.gates })),
  lighthouse: Object.fromEntries(Object.entries(lighthouse.branches).map(([branch, row]) => [branch, { remaining: row.remaining, newErrors: row.newErrors, warnings: row.warnings }])),
});
await writeJSON('BINARY-ATTACHMENT-DERIVATIONS.json', {
  note: 'Original results are immutable external evidence. Only known Playwright binary bodies or verified Lighthouse screenshot data URLs differ in derivatives; all other test/audit data remains. JSON pointers recover exact original values, MIME/prefix is retained where applicable, and decoded bytes have separate SHA256s. Each derivative has a full-record reconstruction proof.',
  derivations,
});
await writeJSON('SOURCE-MANIFEST.json', {
  createdAt: new Date().toISOString(), root, expectedHeads: heads, inputs, walkProofs, walkHarnesses,
  preservation: 'All original source files remain unchanged. Large traces/profiles and binary-bearing original Playwright/Lighthouse results are hashed but not included in the compact package. derivedPackagedAs identifies an explicitly transformed derivative rather than a byte-identical copy.',
  sources: [...sources.values()].sort((a, b) => a.path.localeCompare(b.path)),
});
await writeJSON('PACKAGE-MANIFEST.json', {
  createdAt: new Date().toISOString(), expectedHeads: heads, output,
  bytesExcludingThisManifest: packaged.reduce((total, row) => total + row.bytes, 0),
  preferredBudgetBytes: preferredBudget, softBudgetBytes: softBudget, hardCombinedBudgetBytes: hardBudget, retainedDocsBytes,
  note: 'Manifest excludes its own bytes/hash to avoid recursion; final stdout includes them. Parent checks combined repository docs.',
  files: [...packaged].sort((a, b) => a.path.localeCompare(b.path)),
});
// Validate every generated report target against the staged plan before writing.
for (const match of report.matchAll(/\]\(([^)]+)\)/g)) {
  if (/^https?:\/\//.test(match[1])) continue;
  assert(pendingWrites.has(destination(match[1])), `Broken report link: ${match[1]}`);
}
const total = packaged.reduce((sum, row) => sum + row.bytes, 0);
const combinedBytes = Object.fromEntries(Object.entries(retainedDocsBytes).map(([branch, bytes]) => [branch, bytes + total]));
assert(total < hardBudget && Object.values(combinedBytes).every(bytes => bytes < hardBudget), `Combined docs exceed5MB: ${JSON.stringify(combinedBytes)}. No package written; preserve all original evidence and revise packaging, never delete failed samples.`);
// All source/schema/identity/coverage/link/budget work has finished. The final
// mkdir is exclusive; a competing/previous output cannot be overwritten.
await fs.mkdir(output, { recursive: false });
for (const [file, data] of pendingWrites) { await fs.mkdir(path.dirname(file), { recursive: true }); await fs.writeFile(file, data, { flag: 'wx' }); }
console.log(JSON.stringify({ output, files: packaged.length, totalBytes: total, combinedBytes, preferredBudgetPassed: total < preferredBudget, softBudgetPassed: total < softBudget, hardBudgetPassed: true }, null, 2));
if (total >= softBudget) process.exitCode = 2;
