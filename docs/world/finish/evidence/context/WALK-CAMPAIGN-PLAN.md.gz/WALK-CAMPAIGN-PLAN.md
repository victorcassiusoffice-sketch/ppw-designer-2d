# Round 3 Walk campaign: predeclared before execution

Prepared 29 October 2026. The previously published candidate bf249b542152eb72870fdfa76426a03152c069c7 is being repaired for the strict semantic early-code gate. Substitute the final published full SHA below only after root coordinates source publication and grants the exclusive browser/CPU lease. No formal browser run has been made by this plan.

Run serially from the chat workspace, using the flat round3/harness directory. Do not run the accidentally nested harness/harness copy. Every command verifies the exact deployment head before opening Chromium and after closing it, pins the hosts to216.198.79.3, blocks network writes, acquires the shared performance lock, and writes to its own new results directory.

1. `node work/world-finish/round3/harness/walk-performance.mjs walk --expected=<final-full-SHA> --label=r3-walk-input-v3`
2. `node work/world-finish/round3/harness/walk-framerate.mjs walk 40000 --expected=<final-full-SHA> --label=r3-walk-frames-v2`
3. `node work/world-finish/round3/harness/walk-background.mjs walk <final-full-SHA> --label=r3-walk-background-v1`
4. `node work/world-finish/round3/harness/walk-functional-lock.mjs walk --expected=<final-full-SHA> --label=r3-walk-functional-desktop-v2`
5. `node work/world-finish/round3/harness/walk-functional-phone-current.mjs walk --expected=<final-full-SHA> --label=r3-walk-functional-phone-v6`

Input v3 retains zero explicit settling after readiness and view switches. Report all five desktop/phone keyboard samples in both views, plus all five native phone-touch samples per view; those touch samples occur after keyboard samples and are not the first post-ready input. The laptop hard target is under50ms; phone samples are reported independently. Keep native event-to-handler and handler-to-moved-render intervals separate. Chooser event/render and wall metrics stay separate. Compare entryMs explicitly against Round2 desktop2836.9ms and phone2977.1ms, and retain every outlier. The real compileAsync preparation remains a hypothesis: no GPU/shader-cause claim, averaging away stalls, or post-ready waiting. If entry worsens without demonstrated input benefit, recommend reverting the experiment under Finish step5.

FPS v2 preserves the established3s initial warm-up and1s view-switch wait. Each measured window has40000ms active time, includes all stalls and tails, reports full precision FPS and1% lows, and keeps independent rAF cadence and historical HUD values separate. No screenshots occur during measured windows. Background snapshots must prove the original designer stops through chooser/loading/visit and resumes after exit, with saved property and both cameras exactly restored.

Desktop v2 retains native pointer lock, actual doors in both views, five Escape cycles and exact property/camera restoration. Its functional waits are not input timing evidence.

Phone v6 is selected before execution as the single qualifying current-head campaign, not chosen from reruns. It uses native one-contact touch and locator.tap only; no keyboard or pose injection. Passive capture and window-bubble listeners record trusted pointer/touch/click delivery, target identity/connected state, defaultPrevented and the published status timeline. No preventDefault monkeypatch. Door bounds and elementFromPoint are checked before the actual tap. Missing click/no state change stops without retry. Only an observed trusted click with an explicit safety rejection allows at most two native0.20m retreats and retries; the initial rejection stays in the report. Every failed attempt is retained.

The phone run observation requires at least0.4m movement and a pair of published run-animation statuses resolving more than2m/s while the same native contact is still held, within a finite3s deadline. This avoids treating an animation sampled after touch release/collision as the whole movement. The previous final-only assertion remains recorded separately as legacyFinalOnlyRunAssertion; all prior v1/v2/v3/v4 failures and instrumented v5 pass remain unchanged. The new observation is functional evidence in emulated390x844 Chromium, not human comprehension or physical one-hand comfort evidence.

After the last command exits, verify every owned browser is closed and the shared lock is absent. Emit the compact JSON/MD using the prior schema plus explicit new protocol and previous-failure limitations. Do not discard a failed row or silently rerun a campaign; any necessary bounded diagnostic gets a new label and does not replace it.
