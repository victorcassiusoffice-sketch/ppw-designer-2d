# Read-only schema preflight

Exact sources: Walk `52fa4088e99eafaaaea33e5ad8feb0cbc617fd9e`, Site `7a73b25a2a32556d9d5cf5381d72e7c7bf611447`. This is a bounded inspection of the existing JSON fields, script expectations and image filenames. It is not a package execution, aggregation, new measurement, hash validation or budget check.

## Existing formal proofs

- All five original Walk proofs identify the exact Walk head, successful before/after preview health, `healthStable:true` and a completed timestamp. Versions are input3, frames2, background1, desktop2 and phone6, matching both scripts.
- Input retains both devices, both views, exactly five uniquely numbered keyboard samples per view and five native-touch samples per phone view. Entry and timestamp fields match the aggregator's expected names.
- Frames retain all four device/view rows, full intervals and unfinished tails. Desktop third-person remains `strictFpsPass:false`; the other three rows are true. A finished 40-second window does not override its failed FPS result.
- Background has both devices, all seven exact snapshot phase names, before/after saved-property and both camera fields, error arrays and browser closure. Desktop functional has all three named checks, two door views, five Escape cycles and before/final restoration fields.
- Phone functional has all four required named checks and native one-pointer/key records. The failed door check records `failure` rather than a `passed` field, and only one door view reached a result. The aggregator already treats the explicit failure as false, and the package correctly requires four checks without requiring a passing second door view. This is retained failed evidence, not a missing-file/schema defect.
- No missing-key or coverage blocker was found for the five original proofs. The compact is still absent by design until the coordinator supplies and authorizes the preparation decision.

## Site evidence

- UI: `site-g-7a73b25-20261029/preview-smoke.json` has seven distinct cases and the exact head. Its derived `visual-review.json` matches the automated true result, explicitly records visual false, and covers all six UI screenshots plus all eight generated page images. The new derived review gate accepts this as a complete failed combined result.
- Plan: select `results/r3-site-plan-7a73b25-v2`, preserving v1 separately. V2 has the exact four case/device rows, exact health bodies, all eight actual image filenames, automated true and visual false. The original pending visual label remains unchanged; the separate review supplies the completed result.
- Dedicated print: both device exports and their exact eight rendered page filenames exist; the review covers every page once and records automated/visual true. Two supplementary screen JPGs are present; the print gate deliberately requires every rendered PDF page, not those two screen images. All artifacts are retained by the copy loop.
- These schema checks do not convert either Site visual failure to a pass. No new browser inspection was performed.

## Draft and remaining work

`package-inputs-draft-52fa408-7a73b25.json` uses all known final identities, actual Site-v2 paths, the seven identities from the pre-campaign harness receipt, and the fixed future Walk compact paths. Only pending load/startup/rule inputs and retained-doc byte counts are placeholders. The null retained sizes intentionally fail the package configuration guard. Do not execute this draft.

The known controlled base audit is `builds/r3-final-v5/base/audit.json`. Existing `rules-audit-final-v5.json` is available but the draft leaves rule selection pending the coordinator's final audit choice. The current formal run label is `r3-candidate`; its output must complete and be reviewed before replacing the load placeholders.

Two source/documentation follow-ups remain before final execution:

1. The configuration guide should describe the new derived Site UI `visual-review.json`, its 14-image coverage and separate automated/visual gate; it is not a new config key.
2. The package currently copies selected formal harnesses and old `walk-functional-phone-door*.mjs` probes. The newly executed `walk-functional-phone-tap-diagnostic.mjs` does not match that pattern and is outside evidence roots, so its raw outcomes are retained but its source is not yet inventoried. Add that source explicitly before execution. The unexecuted future v7 source should remain clearly labelled preparation if included.

Before aggregation, update the prepared compact's diagnostic wording to acknowledge the completed phone pair and separately labelled injected compile-duration diagnostic after the coordinator supplies their final proof paths and decision. Neither replaces an original formal result.
