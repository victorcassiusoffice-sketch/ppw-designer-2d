import { readFileSync, writeFileSync, mkdirSync, existsSync, copyFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const label = process.argv[2], branch = process.argv[3];
if (!/^r3-theme-(?:final-v\d+|batch-candidate-v\d+)$/.test(label ?? '') || !['walk', 'site'].includes(branch)) throw Error('Pass explicit label and branch');
const root = resolve(dirname(fileURLToPath(import.meta.url)), 'theme-tests', label, branch);
const output = resolve(root, 'extracted');
if (existsSync(output)) throw Error('Refusing to overwrite extracted evidence');
const result = JSON.parse(readFileSync(resolve(root, 'results.json'), 'utf8'));
mkdirSync(output);
const manifest = [];
function collect(suite, parents = []) {
  const path = [...parents, suite.title].filter(Boolean);
  for (const spec of suite.specs ?? []) for (const test of spec.tests) for (const attempt of test.results) {
    const viewport = path.join(' ').match(/\b(1280|390)px\b/)?.[1];
    const brand = spec.title.match(/^(olb|ppw):/)?.[1];
    if (!viewport || !brand) throw Error('Unknown test context: ' + path.join(' > ') + ' > ' + spec.title);
    for (const attachment of attempt.attachments ?? []) {
      if (!/^[a-zA-Z0-9._-]+$/.test(attachment.name)) throw Error('Unsafe attachment name');
      const file = `${viewport}px-${brand}-${attachment.name}`;
      const destination = resolve(output, file);
      if (existsSync(destination)) throw Error('Duplicate evidence name: ' + file);
      if (attachment.path) copyFileSync(attachment.path, destination);
      else if (attachment.body) writeFileSync(destination, Buffer.from(attachment.body, 'base64'));
      else throw Error('Missing attachment bytes: ' + file);
      manifest.push({ file, sourceName: attachment.name, contentType: attachment.contentType, status: attempt.status, test: [...path, spec.title] });
    }
  }
  for (const child of suite.suites ?? []) collect(child, path);
}
result.suites.forEach(suite => collect(suite));
writeFileSync(resolve(root, 'extraction-manifest.json'), JSON.stringify({ branch, label, originalPreserved: true, entries: manifest }, null, 2) + '\n');
console.log(JSON.stringify({ branch, label, attachments: manifest.length, images: manifest.filter(a => /^image\//.test(a.contentType)).length }));
