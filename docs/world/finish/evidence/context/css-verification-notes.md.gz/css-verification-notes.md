# Isolated plumbing CSS — Round 3

Applied after root completed all three `r3-before-css` controlled builds. Exactly three files per branch: new `src/pages/sales/plumbingBase.css`, new `plumbingBase.test.ts`, and the isolated import in `plumbingMain.tsx`. The primary entry, global stylesheet, build configuration, dependency/lock files, full preferences/brand/sales/form cascade and generated theme sources are unchanged.

The new base keeps complete Tailwind preflight, three local Inter faces/ranges, root typography, empty-icon normalization, document size reset and actual shell body utilities. It omits Designer-only rules and the global utility expansion from the isolated pitch only.

New compatibility tests compile both old/global and new/isolated CSS through the installed PostCSS/Tailwind/autoprefixer pipeline. They compare full preflight semantics, every font descriptor, document/root defaults and all actual body classes read from both HTML shells. They also verify Designer-specific selectors remain in the primary owner. Test content comes from existing HTML rather than artificial utility fixtures that could enlarge primary output.

Initial meaningful failure: `css-walk-focused-v1.log` has42/43 passing; the new body utility test detects the draft missing Tailwind's `var(--tw-bg-opacity, 1)` fallback (and the matching text fallback). Both CSS files were corrected to the actual emitted values; no assertion was relaxed. Subsequent focused suites pass43/43 each: `css-walk-focused-v2.log`, `css-site-focused-v1.log`.

Initial new-test type failure is retained in `css-walk-types.log` and `css-site-types.log`: TypeScript correctly narrowed the unreachable CSS-node diagnostic branch to never. The diagnostic now uses a constant message, with no compiler setting change. Final new compatibility tests pass5/5 each; scoped eslint and application tsc exit0 in `css-{walk,site}-{compat-final,lint-v2,types-v2}.log`.

All test processes ended; CPU lease released to root for the controlled after-build. No builds, browsers or Git mutations were performed by this agent for this CSS concern. Hash identity, final bytes, full suites, exact-head browser matrix and unchanged LHCI are pending. Do not claim the inherited unused-CSS assertion fixed from a smaller stylesheet alone: it requires zero flagged items.

Prepared scratch browser successor `plumbing-browser.mjs` covers72 chapter/theme/brand/device states per branch, four locales and persistence, intercepted enquiry states, real download text and iframe controls/styles. It has not yet been syntax-checked or executed; the controlled source/build window takes precedence. Every fixture response and unexpected error is retained. No real form POST is allowed.
